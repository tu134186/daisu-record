#!/bin/bash
set -euo pipefail
IPA="${1:-}"
if [ -z "$IPA" ] || [ ! -f "$IPA" ]; then
  echo "用法: bash tools/check-built-ipa.sh path/to/app.ipa"
  exit 1
fi
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
unzip -q "$IPA" -d "$TMP"
APP="$(find "$TMP/Payload" -maxdepth 1 -name '*.app' -type d | head -1)"
[ -n "$APP" ] || { echo "ERROR: Payload 内没有 .app"; exit 2; }
APPEX="$(find "$APP/PlugIns" -maxdepth 1 -name '*.appex' -type d 2>/dev/null | head -1 || true)"
echo "APP=$APP"
if [ -z "$APPEX" ]; then echo "ERROR: IPA 内没有 PlugIns/*.appex"; exit 3; fi
echo "APPEX=$APPEX"
/usr/libexec/PlistBuddy -c 'Print :CFBundleIdentifier' "$APPEX/Info.plist"
/usr/libexec/PlistBuddy -c 'Print :NSExtension:NSExtensionPointIdentifier' "$APPEX/Info.plist"
EXE=$(/usr/libexec/PlistBuddy -c 'Print :CFBundleExecutable' "$APPEX/Info.plist")
if [ ! -x "$APPEX/$EXE" ]; then echo "ERROR: Widget 可执行文件不存在/不可执行: $APPEX/$EXE"; exit 4; fi
file "$APPEX/$EXE"
if command -v vtool >/dev/null 2>&1; then
  echo "--- Widget Mach-O build version ---"
  vtool -show-build "$APPEX/$EXE" || true
fi
if command -v codesign >/dev/null 2>&1; then
  echo "--- Widget signature ---"
  codesign -dvvv "$APPEX" 2>&1 || true
  echo "--- Widget entitlements ---"
  codesign -d --entitlements :- "$APPEX" 2>/dev/null || true
fi
echo "OK: Widget .appex 结构存在；请重点确认最低系统 <= 真机系统，且扩展有有效/可被 TrollStore 重签的签名。"
