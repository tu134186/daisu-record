#!/bin/bash
set -euo pipefail
IPA="${1:-}"
EXPECTED_VERSION="${2:-2.2.23}"
EXPECTED_BUILD="${3:-53}"
if [ -z "$IPA" ] || [ ! -f "$IPA" ]; then
  echo "用法: bash tools/check-built-ipa.sh path/to/app.ipa [版本] [build]"
  exit 1
fi
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
unzip -q "$IPA" -d "$TMP"
APP="$(find "$TMP/Payload" -maxdepth 1 -name '*.app' -type d | head -1)"
[ -n "$APP" ] || { echo "ERROR: Payload 内没有 .app"; exit 2; }
APPEX="$(find "$APP/PlugIns" -maxdepth 1 -name '*.appex' -type d 2>/dev/null | head -1 || true)"
[ -n "$APPEX" ] || { echo "ERROR: IPA 内没有 PlugIns/*.appex"; exit 3; }
PB=/usr/libexec/PlistBuddy
read_plist(){ "$PB" -c "Print :$2" "$1/Info.plist" 2>/dev/null || true; }
APP_ID=$(read_plist "$APP" CFBundleIdentifier)
APP_VER=$(read_plist "$APP" CFBundleShortVersionString)
APP_BUILD=$(read_plist "$APP" CFBundleVersion)
WIDGET_ID=$(read_plist "$APPEX" CFBundleIdentifier)
WIDGET_VER=$(read_plist "$APPEX" CFBundleShortVersionString)
WIDGET_BUILD=$(read_plist "$APPEX" CFBundleVersion)
EXT_POINT=$("$PB" -c 'Print :NSExtension:NSExtensionPointIdentifier' "$APPEX/Info.plist" 2>/dev/null || true)
EXE=$(read_plist "$APPEX" CFBundleExecutable)
printf '%s\n' "=== 最终 IPA 结构审计 ===" \
  "APP=$APP" \
  "APP_ID=$APP_ID" \
  "APP_VERSION=$APP_VER ($APP_BUILD)" \
  "APPEX=$APPEX" \
  "WIDGET_ID=$WIDGET_ID" \
  "WIDGET_VERSION=$WIDGET_VER ($WIDGET_BUILD)" \
  "EXTENSION_POINT=$EXT_POINT"
[ "$APP_VER" = "$EXPECTED_VERSION" ] || { echo "ERROR: 主 App 版本不是 $EXPECTED_VERSION"; exit 10; }
[ "$APP_BUILD" = "$EXPECTED_BUILD" ] || { echo "ERROR: 主 App build 不是 $EXPECTED_BUILD"; exit 11; }
[ "$WIDGET_VER" = "$EXPECTED_VERSION" ] || { echo "ERROR: Widget 版本不是 $EXPECTED_VERSION；说明源码/Target 版本没同步"; exit 12; }
[ "$WIDGET_BUILD" = "$EXPECTED_BUILD" ] || { echo "ERROR: Widget build 不是 $EXPECTED_BUILD"; exit 13; }
[ "$WIDGET_ID" = "com.trollbox.caridle.widget" ] || { echo "ERROR: Widget Bundle ID 异常: $WIDGET_ID"; exit 14; }
[ "$EXT_POINT" = "com.apple.widgetkit-extension" ] || { echo "ERROR: NSExtensionPointIdentifier 异常: $EXT_POINT"; exit 15; }
[ -n "$EXE" ] && [ -f "$APPEX/$EXE" ] || { echo "ERROR: Widget 可执行文件不存在: $EXE"; exit 16; }
file "$APPEX/$EXE" || true
if command -v vtool >/dev/null 2>&1; then
  echo "--- Widget Mach-O build version ---"
  vtool -show-build "$APPEX/$EXE" || true
fi
if command -v codesign >/dev/null 2>&1; then
  echo "--- App signature ---"
  codesign -dvvv "$APP" 2>&1 || true
  echo "--- Widget signature ---"
  codesign -dvvv "$APPEX" 2>&1 || true
  echo "--- App entitlements ---"
  codesign -d --entitlements :- "$APP" 2>/dev/null || true
  echo "--- Widget entitlements ---"
  codesign -d --entitlements :- "$APPEX" 2>/dev/null || true
fi
echo "OK: 最终 IPA 内主 App 与 Widget 都是 $EXPECTED_VERSION ($EXPECTED_BUILD)，且标准 Widget Extension 结构存在。"
echo "如果 TrollStore 覆盖安装后桌面仍显示旧版本，而注销/重启 SpringBoard 后才切换，则重点是系统/TrollStore Extension 注册缓存，不应继续改 SwiftUI Timeline。"
