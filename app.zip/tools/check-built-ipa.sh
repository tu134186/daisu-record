#!/bin/bash
set -euo pipefail
IPA="${1:-}"
if [ -z "$IPA" ] || [ ! -f "$IPA" ]; then
  echo "用法: bash tools/check-built-ipa.sh path/to/app.ipa"
  exit 1
fi
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
unzip -q "$IPA" -d "$TMP"
APP="$(find "$TMP/Payload" -maxdepth 1 -name '*.app' -type d | head -1)"
APPEX="$(find "$APP/PlugIns" -maxdepth 1 -name '*.appex' -type d 2>/dev/null | head -1 || true)"
echo "APP=$APP"
if [ -z "$APPEX" ]; then echo "ERROR: IPA 内没有 Widget .appex"; exit 2; fi
echo "APPEX=$APPEX"
/usr/libexec/PlistBuddy -c 'Print :CFBundleIdentifier' "$APPEX/Info.plist" || true
/usr/libexec/PlistBuddy -c 'Print :NSExtension:NSExtensionPointIdentifier' "$APPEX/Info.plist" || true
EXE=$(/usr/libexec/PlistBuddy -c 'Print :CFBundleExecutable' "$APPEX/Info.plist")
if [ ! -x "$APPEX/$EXE" ]; then echo "ERROR: Widget 可执行文件不存在/不可执行: $APPEX/$EXE"; exit 3; fi
file "$APPEX/$EXE"
echo "OK: Widget .appex 结构存在"
