# CarIdle 开发规范

## V2 开发原则
- 保留现有 UserDefaults 键：idleRecords、currentIdleRecord、maintenanceRecords、vehicleRegistrationDate 等，禁止无迁移方案直接改名。
- iOS 16.0 为最低目标，新增 SwiftUI API 必须确认 iOS 16 可用。
- 页面拆分维护：主页、历史、报表、保养、设置、详情尽量独立文件，避免再次堆回一个超大 ContentView.swift。
- 版本号发布时同步 project.yml、App 内更新日志、源码更新日志；设置页版本号优先读取 Bundle。
- 不重新加入已知在巨魔环境出现空白问题的小组件，除非单独验证。
- 年检政策属于可变规则，后续应独立成规则模块，不要继续把政策散落到 UI。
- 每次发布前至少检查：Swift 语法、重复类型、版本号、Info.plist、历史数据兼容、ZIP 根目录。

## 数据安全
V2.0.0 沿用旧版 UserDefaults 数据结构和 history_records.json，不进行破坏性迁移。任何结构升级必须先支持旧数据解码。


## GitHub Actions 构建规则（V2.0.1 起）
不要在构建开始时检查 `app.zip`。`app.zip` 是 xcodebuild 成功后才生成的最终产物。正确顺序必须是：xcodegen → xcodebuild → 查找 Release-iphoneos 下的 `.app` → 组装 Payload → zip → 上传。GitHub Actions 才是真实编译环境。


## V2.0.2 固定发布规则
- 对外 App 名称：怠速记录。
- Bundle ID 继续保持 `com.trollbox.caridle`，非必要不要修改。
- 用户 GitHub 仓库采用固定工作流读取根目录 `app.zip`。
- 后续交付优先只给新的 `app.zip`，用户上传覆盖即可，不要求手机解压源码。
