# CarIdle 开发规范

## V2 开发原则
- 保留现有 UserDefaults 键：idleRecords、currentIdleRecord、maintenanceRecords、vehicleRegistrationDate 等，禁止无迁移方案直接改名。
- iOS 16.0 为最低目标，新增 SwiftUI API 必须确认 iOS 16 可用。
- 页面拆分维护：主页、历史、报表、保养、设置、详情尽量独立文件，避免再次堆回一个超大 ContentView.swift。
- 版本号发布时同步 project.yml、App 内更新日志、源码更新日志；设置页版本号优先读取 Bundle。
- 不重新加入已知在巨魔环境出现空白问题的小组件，除非单独验证。
- 年检政策属于可变规则，后续应独立成规则模块，不要继续把政策散落到 UI。
- 每次发布前至少检查：Swift 语法、重复类型、版本号、Info.plist、历史数据兼容、ZIP 根目录。

## 数据安全
V2.0.0 沿用旧版 UserDefaults 数据结构和 history_records.json，不进行破坏性迁移。任何结构升级必须先支持旧数据解码。


## V2.0.2 补充规范
- 随包历史快照基线：135 条；最新记录应为 2026-09-01 21:30–22:10。
- 发布前必须校验 2026-08-25、2026-09-01 两条补录仍存在。
- 首页不要恢复“常用功能”中的重复设置按钮；顶部齿轮为设置主入口。


## V2.0.4 / Build 30
- 移除 iCloud 自动备份与相关 entitlement。
- 修复本地完整备份可能导出 0 KB：先编码真实 JSON，再原子写入临时目录并读取文件属性校验 size > 0，校验失败则不打开分享。
- 设置页导出后显示记录条数、文件大小、备份时间。
- 保留 135 条历史基线与导入去重逻辑。

## V2.0.5 / Build 31
- 修复 iOS 16.5“导入完整备份”时 JSON 文件变灰、无法点击的问题。
- 文件选择器允许通用数据文件，选择后再由 App 校验 JSON/CSV 内容。
- 修复部分文件位置安全访问返回 false 时被错误中止的问题。
- 保留非空备份校验、135 条历史基线和导入去重。

## V2.0.6 / Build 32
- 不再使用 SwiftUI fileImporter 的 UTType 过滤。
- 改为 UIDocumentPickerViewController + public.item，允许在 iOS 16.5“文件”App 中直接选择 JSON 等任意普通文件。
- 选中文件后再由 App 自己读取并判断 JSON/CSV，保留完整备份解析和去重逻辑。
- 保留 135 条历史基线与 V2.0.4 非空备份写入校验。
