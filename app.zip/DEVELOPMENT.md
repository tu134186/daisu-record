# 怠速记录 CarIdle — 开发规范与长期维护说明

> 当前稳定源码版本：V2.2.11（build 41）  
> 最低系统：iOS 16.0；主要真机环境：iOS 16.5 / TrollStore 类安装环境。  
> 本文件必须随每一版源码一起维护。AI/开发者接手后应先阅读本文件和 CHANGELOG.md，再修改代码。

## 1. 项目目标
“怠速记录”用于记录车辆启动/熄火、怠速时长、启动提醒、保养、年检、报表和历史数据。当前重点故障是桌面中号 Widget 在真机出现“占位区域存在、切换/点击有阴影，但内容整块空白”。

## 2. 当前稳定基线
- 主 App Bundle ID：`com.trollbox.caridle`，非必要禁止修改。
- Widget Extension：只允许 `CarIdleWidget` 一个 target。
- 当前唯一 Widget kind：`CarIdleMediumWidgetV2210Single`。
- iOS Deployment Target：16.0。
- 主 App 原历史数据继续使用现有 UserDefaults 键和 JSON 结构。
- V2.2.10 起 Widget 为静态诊断实现；V2.2.11 只调整开发文档、版本历史展示和版本号，不改变该诊断架构。

## 3. 已知问题
### Widget 空白
真机表现：桌面 Widget 内容完全空白，但长按、切换或点击时能看到 Widget 区域阴影，说明系统至少识别到了占位区域。V2.2.8 已断开 App Group/业务数据，V2.2.9 已缩为固定白底黑字，V2.2.10 已清理为单 Widget Extension，仍需通过“最终编译 IPA”继续确认 appex 是否真正注册/签名/启动。

## 4. 已验证不能乱动的高风险区域
- 不要为了修 Widget 随意更换主 App Bundle ID。
- 不要同时保留第二个 Widget target、第二份 @main Widget、旧 kind 刷新路径。
- 不要重新加入跨沙盒扫描、私有 AppDataContainers entitlement、额外 Widget 重签等已回退方案。
- 不要无迁移方案修改 `idleRecords`、`currentIdleRecord`、`maintenanceRecords`、`vehicleRegistrationDate` 等已有数据键。
- 不要使用仅 iOS 17 可用的 API 而不做 iOS 16 兼容。
- 当前 Widget 故障未定位前，不要把业务数据、复杂布局、动画重新塞回诊断 Widget。

## 5. 最小改动原则
每版只解决明确问题。能改一处就不重构整套工程；先保证编译、安装和旧数据，再处理视觉优化。Widget 排查必须“一次只改变一个变量”，否则无法判断是哪项修改生效。

## 6. Widget 排查顺序
1. 先确认最终 IPA 内存在 `Payload/*.app/PlugIns/CarIdleWidget.appex`。
2. 检查 appex 内 `Info.plist`、可执行文件、NSExtension 配置和最低系统版本。
3. 检查最终安装包的签名/entitlements，而不是只看源码。
4. 删除桌面旧 Widget 后重新添加，避免旧快照干扰。
5. 静态诊断文字能显示后，才逐步恢复 App Group、共享摘要和正式 UI。
6. 如果静态文字仍不显示，不要继续修改业务 SwiftUI 页面。

## 7. 版本号同步清单
发布新版本必须同时检查：
- `project.yml` 主 App 的 `MARKETING_VERSION` / `CURRENT_PROJECT_VERSION`；
- `project.yml` Widget target 的相同版本；
- Widget 可见诊断版本文字/配置名称（诊断阶段）；
- `CHANGELOG.md`；
- `DEVELOPMENT.md`；
- `AI接手开发说明.md`；
- App 内 `VersionHistoryView.swift`；
- 设置 → 关于页的历史版本摘要；
- 对外交付 ZIP 文件名。

## 8. 源码 ZIP / 编译产物规范
- 源码 ZIP 解压后根目录直接看到 `project.yml`、`CarIdle/`、`CarIdleWidget/`、`Shared/`、开发文档；禁止额外套一层无意义目录。
- 工程中只保留当前有效源码，历史实现写进日志，不保留第二套会参与编译的旧 target/旧 Widget。
- GitHub Actions 正确顺序：xcodegen → xcodebuild → 找到 Release-iphoneos `.app` → 组装 Payload → zip → 上传。
- 不要在编译前检查“最终 app.zip 是否已经存在”。

## 9. 每版测试最低要求
- Swift/Xcode 编译通过。
- App 能启动，旧记录仍可读取。
- 设置 → 关于显示正确版本。
- App 内完整更新日志包含当前版本且倒序排列。
- 若改 Widget：确认最终 IPA 确实嵌入 appex；真机删除旧 Widget 后重新添加测试。
- 记录“成功/失败/未解决”，失败方案也必须写进 CHANGELOG，避免下一位 AI 重复踩坑。

## 10. 当前下一步建议
如果 V2.2.11 编译安装后 Widget 仍然只有阴影而无 `WIDGET V2.2.11`，下一步不要继续改 Widget View。应拿 GitHub 实际编译出来的 IPA/ZIP，直接检查 `CarIdleWidget.appex` 的结构、Mach-O、Info.plist、签名和安装注册情况。
