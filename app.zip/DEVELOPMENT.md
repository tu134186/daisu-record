# CarIdle 开发规范

## V2 开发原则
- 保留现有 UserDefaults 键：idleRecords、currentIdleRecord、maintenanceRecords、vehicleRegistrationDate 等，禁止无迁移方案直接改名。
- iOS 16.0 为最低目标，新增 SwiftUI API 必须确认 iOS 16 可用。
- 页面拆分维护：主页、历史、报表、保养、设置、详情尽量独立文件，避免再次堆回一个超大 ContentView.swift。
- 版本号发布时同步 project.yml、App 内更新日志、源码更新日志；设置页版本号优先读取 Bundle。
- 不重新加入已知在巨魔环境出现空白问题的小组件，除非单独验证。
- 年检政策属于可变规则，后续应独立成规则模块，不要继续把政策散落到 UI。
- 每次发布前至少检查：Swift 语法、重复类型、版本号、Info.plist、历史数据兼容、ZIP 根目录。

## 数据安全
V2.0.0 沿用旧版 UserDefaults 数据结构和 history_records.json，不进行破坏性迁移。任何结构升级必须先支持旧数据解码。


## GitHub Actions 构建规则（V2.0.1 起）
不要在构建开始时检查 `app.zip`。`app.zip` 是 xcodebuild 成功后才生成的最终产物。正确顺序必须是：xcodegen → xcodebuild → 查找 Release-iphoneos 下的 `.app` → 组装 Payload → zip → 上传。GitHub Actions 才是真实编译环境。


## V2.0.2 固定发布规则
- 对外 App 名称：怠速记录。
- Bundle ID 继续保持 `com.trollbox.caridle`，非必要不要修改。
- 用户 GitHub 仓库采用固定工作流读取根目录 `app.zip`。
- 后续交付优先只给新的 `app.zip`，用户上传覆盖即可，不要求手机解压源码。


## V2.1 首页原则
- 首页优先解决“多久没开、何时建议启动、上次运行多久、保养是否到期”四件事。
- 首页设置入口只保留右上角齿轮，避免同一功能重复占位。
- 小于 1 天的闲置时间禁止显示 `0.0天`，使用自然语言。
- 长期超期项目不在首页展示夸张红色天数，具体天数留给保养详情。
- V2.1 仅精修 UI/展示逻辑，不修改已验证的数据键与解码格式。


## V2.2.0 小组件开发约束
- 只做中号 Widget；不要自行增加小号/大号，除非用户明确要求。
- App Group 固定为 `group.com.trollbox.caridle`，主 App 与 Widget entitlement 必须完全一致。
- 旧数据源 `UserDefaults.standard` 不迁移。Widget 只读取 `CarIdleWidgetSnapshot` 摘要，避免破坏已有历史记录。
- 每次改变怠速核心数据后调用 `syncWidgetSnapshot()` + `WidgetCenter.reloadTimelines`。
- 巨魔安装时必须确认 IPA 内存在 `PlugIns/CarIdleWidget.appex`；如果小组件列表不出现，优先检查扩展是否被嵌入、entitlements 和签名，而不是重写 UI。
- iOS 最低版本保持 16.0，不使用 iOS 17 专属 Widget API（例如 `containerBackground(for:)`）。

## V2.2.1 小组件同步兼容
- 不要只依赖 App Group：TrollStore + iOS 16 的 Widget Extension 存在容器/沙盒异常案例。
- 正常环境优先 `group.com.trollbox.caridle`；读取为空时才启用 TrollStore fallback。
- fallback 文件仅保存小组件摘要，路径为主 App `Library/Application Support/CarIdleWidgetSnapshot.json`。
- Widget 只读主 App 摘要，不直接修改主 App 历史数据。
- 保留 Bundle ID `com.trollbox.caridle` 与 Widget `com.trollbox.caridle.widget`。

## V2.2.2 Widget 规则
- V2.2.1 的跨沙盒读取方案已撤回：不要给 Widget 随意增加私有 entitlement，也不要扫描 `/var/mobile/Containers/Data/Application`。
- TrollStore 下小组件共享优先坚持标准 App Group。
- GitHub 构建是 unsigned xcodebuild；仅在源码里写 entitlements 不足以保证最终 Mach-O 带 entitlement。
- 打包前必须使用 `ldid -S<entitlements.plist>`：先签 `CarIdleWidget.appex`，再签 `CarIdle.app`。
- TrollStore 会读取并保留 IPA 内二进制已有 entitlement，因此 App Group 同步依赖这一步。
