## V2.2.28 / Build 58（2026-09-02）
- 用户决定停止继续投入 TrollStore Widget 安装后即时刷新问题。
- 本版以主 App 完整功能恢复为第一优先级：首页恢复 6 个快捷入口（历史/报表/保养/导出/导入/设置）。
- 数据导入导出、保养、保险、年检、启动提醒、历史记录、报表等功能全部保留。
- 工程停止编译 Widget Extension；历史 Widget 排查记录保留在文档中，仅供以后参考，不再作为当前开发目标。
- 主 App：2.2.28 / build 58。

## V2.2.27 / Build 57（2026-09-02）
- 用户真机再次确认：安装后小组件异常时，注销 SpringBoard 后能够正常显示；继续按 TrollStore/iOS 16.5 Extension 注册/缓存问题记录，不再重复堆 reload 补丁。
- 恢复此前完整业务小组件：当前运行/熄火状态、距上次启动、上次时长、总次数、下次启动建议；不再只显示诊断版本文字。
- 主 App 原有完整功能全部保留：启动/熄火计时、历史记录、报表、保养、年检、提醒、JSON/CSV 导入导出、清空数据、设置和完整历史更新。
- 保留已验证的固定 kind `CarIdleMediumWidget`、单一 Extension、App Group 权限、Extension 运行心跳诊断，以及主 App 零主动 WidgetCenter reload 路径。
- 主 App / Widget / 工程 / 校验脚本统一为 2.2.27 / build 57。

## V2.2.26 / Build 56（2026-09-02）
- 修复 V2.2.25 编译失败：心跳方法 `markWidgetHeartbeat/widgetHeartbeatDate/sharedDataIsConnected` 被误写进 `CarIdleWidgetSnapshot`，但调用处使用的是 `CarIdleWidgetShared`，导致 Widget target CompileSwift 失败。
- 本版把三项共享诊断方法移回 `CarIdleWidgetShared`，保持 Widget 与主 App 调用一致。
- 不改变 V2.2.25 的诊断方案与 Widget 行为，仅做编译修复和版本同步。
- 真机测试仍按固定顺序：安装后先看负一屏，再打开 App，再点重新检测，以区分“安装即显示/打开 App 后显示/检测后显示”。


## V2.2.26 / Build 56（2026-09-02）
- 实测发现：TrollStore 安装后，`WidgetCenter.getCurrentConfigurations` 可能返回空数组，但负一屏小组件实际上已经能够显示。
- 因此“系统列表为空 = 未登记”的诊断结论是错误的，V2.2.26 废除这一单一判断。
- Widget Extension 在 `getSnapshot/getTimeline` 真正执行时向 App Group 写入运行心跳；设置页优先以该心跳确认 Extension 已实际运行。
- 若系统配置列表为空但存在心跳，显示“已运行”，明确提示 WidgetCenter 列表结果不可靠。
- 不新增 reloadTimelines 强刷补丁。

# V2.2.26 最新验证补充

- 根据 V2.2.23 真机截图，设置页明确返回“未登记”，与安装后 Widget 空白一致。
- 代码审查发现主 App 已声明 `group.com.trollbox.caridle`，但 Widget Extension 的 entitlements 是空字典，而且 project.yml 没有给 Extension 配置 `CODE_SIGN_ENTITLEMENTS`。这是打包配置缺口。
- V2.2.26 为 Widget Extension 补齐同一个 App Group entitlement，并把 Shared 源码同时编入 Extension，保证后续恢复真实共享数据时主 App/Widget 权限与共享模型一致。
- “重新检测”改为整行可点，并在点击后立即显示“检测中…”，避免看起来像没反应。
- 保持固定 kind `CarIdleMediumWidget`，不新增 reloadTimelines/reloadAllTimelines，不更换 Bundle ID。
- 当前版本：V2.2.26 / build 56。

# V2.2.23 最新验证补充

- 真机确认 V2.2.22：安装后 Widget 空白；点击空白 Widget 可以拉起主 App，但打开 App 后 Widget 依旧空白；注销 SpringBoard 后立即显示。
- 这已经把“必须先打开一次 App”排除掉，也再次排除静态 Widget View 本身永久崩溃。
- Apple 的 `WidgetCenter.reloadTimelines` / `reloadAllTimelines` 是“重新加载已配置 Widget 的时间线”，不是“注册/重注册 Extension”的 API；因此此前继续强刷没有理论依据。
- TrollStore 2.1 起官方提供 **Refresh App Registrations**。下一步优先验证该安装侧注册刷新能否代替注销，而不是继续堆 WidgetKit reload 补丁。
- V2.2.23 设置页新增只读“小组件诊断”：调用 `getCurrentConfigurations` 查看系统当前是否能返回固定 kind `CarIdleMediumWidget`，不触发 reload，不修改桌面快照。
- 当前版本：V2.2.23 / build 53。

# V2.2.22 最新验证补充

- 真机现象：安装后空白，注销 SpringBoard 后正常。
- V2.2.21 复查发现 `Store.swift` 仍残留 `WidgetCenter.shared.reloadTimelines(ofKind:)`，且 `IdleStore.init()` 会触发它；所以此前所谓“被动注册”并不彻底。
- V2.2.22 已删除主 App 中最后一条 WidgetCenter 刷新路径以及 Store.swift 的 WidgetKit import，仅保留共享摘要写入。
- 本版是“真正零 WidgetCenter”A/B 测试。若仍只有注销后恢复，下一步不再重复 reload/换 kind，而转向 TrollStore 安装后的 Extension 注册缓存结论与安装侧处理。
- 当前版本：V2.2.22 / build 52。

# CarIdle 开发规范与长期记录

> 当前验证源码版本：V2.2.21（build 51，被动注册回退测试）  
> 日期：2026-09-02

## 当前稳定原则
- iOS 16.x / TrollStore 场景下，Widget 使用单一 Extension `com.trollbox.caridle.widget`。
- Widget kind 固定为 `CarIdleMediumWidget`，版本升级禁止改 kind。
- 当前 Widget 排障阶段保持最小静态 SwiftUI 内容，不接业务数据，先只验证 Extension 注册/显示。
- 主 App 当前禁止在启动或回前台主动 `reloadAllTimelines`。V2.2.20 真机已证明这种做法会在安装完成后马上把 Widget 变成空白。
- Timeline 当前恢复 `.never`，与 V2.2.14/V2.2.19 基线一致。

## 已验证真机历史
- V2.2.14：曾出现覆盖安装后无需注销、秒级切换到新 Widget 的成功案例，证明固定 kind + 最小 Extension 在该环境下存在免注销成功路径。
- V2.2.18：覆盖安装后仍显示旧 V2.2.12；注销后立即正确显示 V2.2.18，证明包内新 Widget Extension 实际存在且可运行。
- V2.2.19：安装后空白；注销后显示。
- V2.2.20：安装后主动 WidgetCenter 刷新导致 Widget 马上变空白，判定该方案失败并永久记录，禁止原样重复。

## V2.2.21 测试目标
恢复完全被动的系统注册路径，只改变版本文字和版本号。安装后先不打开 App、不注销，观察系统是否自行切换。如果仍需注销，再把该现象作为 TrollStore/系统 Extension 重载限制处理，而不是继续无限堆 reload 补丁。

## 最小改动原则
1. 不改主 App Bundle ID。
2. 不改 Widget Bundle ID。
3. 不改 Widget kind。
4. 不增加第二 Extension。
5. 不用私有 entitlement / 私有注册 API。
6. 每版只改变一个可验证变量。
7. 真机失败方案必须写入 CHANGELOG 和验证记录，下一版不得无理由重复。

## 版本同步清单
每次升级同步：`project.yml` 主 App + Widget、`tools/check-built-ipa.sh` 默认版本、Widget 可见诊断文字、设置页兜底版本、App 内历史版本、CHANGELOG、DEVELOPMENT、AI接手开发说明、验证记录、BUILD-PROVENANCE。

## 编译/打包要求
源码 ZIP 根目录必须直接包含 `project.yml`、`CarIdle/`、`CarIdleWidget/`、`Shared/`、`tools/` 等，不允许再套一层版本文件夹。GitHub Actions 解压 `app.zip` 后应可直接看到 `project.yml`。
