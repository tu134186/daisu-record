# V2.2.22 最新验证补充

- 真机现象：安装后空白，注销 SpringBoard 后正常。
- V2.2.21 复查发现 `Store.swift` 仍残留 `WidgetCenter.shared.reloadTimelines(ofKind:)`，且 `IdleStore.init()` 会触发它；所以此前所谓“被动注册”并不彻底。
- V2.2.22 已删除主 App 中最后一条 WidgetCenter 刷新路径以及 Store.swift 的 WidgetKit import，仅保留共享摘要写入。
- 本版是“真正零 WidgetCenter”A/B 测试。若仍只有注销后恢复，下一步不再重复 reload/换 kind，而转向 TrollStore 安装后的 Extension 注册缓存结论与安装侧处理。
- 当前版本：V2.2.22 / build 52。

# CarIdle 开发规范与长期记录

> 当前验证源码版本：V2.2.21（build 51，被动注册回退测试）  
> 日期：2026-09-02

## 当前稳定原则
- iOS 16.x / TrollStore 场景下，Widget 使用单一 Extension `com.trollbox.caridle.widget`。
- Widget kind 固定为 `CarIdleMediumWidget`，版本升级禁止改 kind。
- 当前 Widget 排障阶段保持最小静态 SwiftUI 内容，不接业务数据，先只验证 Extension 注册/显示。
- 主 App 当前禁止在启动或回前台主动 `reloadAllTimelines`。V2.2.20 真机已证明这种做法会在安装完成后马上把 Widget 变成空白。
- Timeline 当前恢复 `.never`，与 V2.2.14/V2.2.19 基线一致。

## 已验证真机历史
- V2.2.14：曾出现覆盖安装后无需注销、秒级切换到新 Widget 的成功案例，证明固定 kind + 最小 Extension 在该环境下存在免注销成功路径。
- V2.2.18：覆盖安装后仍显示旧 V2.2.12；注销后立即正确显示 V2.2.18，证明包内新 Widget Extension 实际存在且可运行。
- V2.2.19：安装后空白；注销后显示。
- V2.2.20：安装后主动 WidgetCenter 刷新导致 Widget 马上变空白，判定该方案失败并永久记录，禁止原样重复。

## V2.2.21 测试目标
恢复完全被动的系统注册路径，只改变版本文字和版本号。安装后先不打开 App、不注销，观察系统是否自行切换。如果仍需注销，再把该现象作为 TrollStore/系统 Extension 重载限制处理，而不是继续无限堆 reload 补丁。

## 最小改动原则
1. 不改主 App Bundle ID。
2. 不改 Widget Bundle ID。
3. 不改 Widget kind。
4. 不增加第二 Extension。
5. 不用私有 entitlement / 私有注册 API。
6. 每版只改变一个可验证变量。
7. 真机失败方案必须写入 CHANGELOG 和验证记录，下一版不得无理由重复。

## 版本同步清单
每次升级同步：`project.yml` 主 App + Widget、`tools/check-built-ipa.sh` 默认版本、Widget 可见诊断文字、设置页兜底版本、App 内历史版本、CHANGELOG、DEVELOPMENT、AI接手开发说明、验证记录、BUILD-PROVENANCE。

## 编译/打包要求
源码 ZIP 根目录必须直接包含 `project.yml`、`CarIdle/`、`CarIdleWidget/`、`Shared/`、`tools/` 等，不允许再套一层版本文件夹。GitHub Actions 解压 `app.zip` 后应可直接看到 `project.yml`。
