# V2.2.14 已验证成功案例
- Widget kind：`CarIdleMediumWidget`（永久固定）。
- 主 App 不再使用 0.8 秒/2.5 秒延迟强制刷新。
- 用户真机实测：从旧版覆盖安装到 V2.2.14，**未注销 SpringBoard，桌面 Widget 秒级变为 V2.2.14**。
- 这是当前成功基线；以后不得为了清缓存再次更换 kind。

# AI 接手开发说明

当前测试版本：V2.2.15 / build 45；稳定基线：V2.2.14 / build 44。接手后必须先阅读 `DEVELOPMENT.md` 和 `CHANGELOG.md`。

## 当前最重要结论
历史上桌面 Widget 曾出现“内容空白/覆盖安装后仍显示旧版 V2.2.12，注销 SpringBoard 后才更新”。V2.2.14 将 Widget kind 永久固定为 `CarIdleMediumWidget`，删除 0.8 秒/2.5 秒延迟 `reloadTimelines` 补丁并保持单一 Widget Extension。用户真机已经确认：**不注销 SpringBoard，覆盖安装 V2.2.14 后桌面 Widget 秒级更新为 `WIDGET V2.2.14`。** 这是真机成功案例，V2.2.14 结构必须作为后续基线。关于页保持“当前版本 + 历史更新入口”，完整历史在独立全屏页面查看。

## 禁止重复尝试
- 不要新增第二个 Widget target 或第二份 @main Widget。
- 不要更换 kind。当前唯一且永久固定的 kind：`CarIdleMediumWidget`。
- 不要用跨沙盒扫描、私有 entitlement、额外重签来“碰运气”。
- 静态 Widget 尚未显示前，不要恢复复杂业务 UI。

## 下一步
V2.2.14 已验证覆盖安装无需注销即可秒级切换 Widget。后续不要再修“首次注册”旧问题，直接以本版结构为稳定基线；恢复正式 Widget 数据/UI 时一次只改一个变量，并持续验证覆盖安装实时更新。

## 发布要求
每版同步 project.yml、Widget 诊断文字、CHANGELOG、DEVELOPMENT、AI接手开发说明、App 内完整更新日志、关于页历史摘要和交付 ZIP 文件名。源码 ZIP 根目录直接放工程文件。


## V2.2.14 新增硬规则：Widget kind 永久稳定
- WidgetKit 的 `kind` 是桌面已添加小组件的配置身份，不是版本号。
- 禁止以后为了“清缓存”把 `kind` 改成 `...V2215`、`...V2216`。
- 当前唯一 kind 固定为 `CarIdleMediumWidget`。
- 覆盖安装测试必须先检查最终 IPA 内 `PlugIns/*.appex` 的版本是否已经跟主 App 同步，再判断 TrollStore/系统注册缓存。


## V2.2.15 连续升级验证
本版只把 Widget 可见文字更新为 `WIDGET V2.2.15` / “连续升级稳定性验证”，版本同步到 2.2.15 / build 45。固定 kind、Bundle ID、entitlements、App Group、Extension target 均继承 V2.2.14，不得添加刷新补丁。测试目标：覆盖安装后不注销，桌面现有 Widget 应直接切换到 V2.2.15。
