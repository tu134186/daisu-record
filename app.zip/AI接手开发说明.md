# AI 接手开发说明

当前版本：2.0.0，基于用户提供的 v1.10.4 源码升级。

重点：
1. V2 没有重写 Store/Models 数据结构，目的是保留旧数据兼容。
2. 首页已重做；历史、报表、保养、设置主要保留旧功能并拆分文件，后续可逐页继续做 V2 视觉统一。
3. 不要为了“重构漂亮”随意改 UserDefaults key，否则旧记录会像丢失一样。
4. `Store.swift` 年检规则目前仍是旧版硬编码逻辑，这是待重构项，不应在没有明确规则来源时自行改政策。
5. 最低系统 iOS 16.0。
6. 设置页版本号已经改成 Bundle 动态读取；发布仍需同步 project.yml 与更新日志。


## GitHub Actions 构建规则（V2.0.1 起）
不要在构建开始时检查 `app.zip`。`app.zip` 是 xcodebuild 成功后才生成的最终产物。正确顺序必须是：xcodegen → xcodebuild → 查找 Release-iphoneos 下的 `.app` → 组装 Payload → zip → 上传。GitHub Actions 才是真实编译环境。


## V2.0.2 固定发布规则
- 对外 App 名称：怠速记录。
- Bundle ID 继续保持 `com.trollbox.caridle`，非必要不要修改。
- 用户 GitHub 仓库采用固定工作流读取根目录 `app.zip`。
- 后续交付优先只给新的 `app.zip`，用户上传覆盖即可，不要求手机解压源码。


## 当前版本 V2.1.0
首页已经完成第一轮精修：压缩顶部空间、自然化闲置时间、弱化长期超期提醒、移除首页重复设置入口、压缩最近一次卡片。下一步优先根据真机截图继续微调，不要破坏 V2.0.x 已验证的数据兼容和 GitHub app.zip 编译流程。


## V2.2.0 小组件开发约束
- 只做中号 Widget；不要自行增加小号/大号，除非用户明确要求。
- App Group 固定为 `group.com.trollbox.caridle`，主 App 与 Widget entitlement 必须完全一致。
- 旧数据源 `UserDefaults.standard` 不迁移。Widget 只读取 `CarIdleWidgetSnapshot` 摘要，避免破坏已有历史记录。
- 每次改变怠速核心数据后调用 `syncWidgetSnapshot()` + `WidgetCenter.reloadTimelines`。
- 巨魔安装时必须确认 IPA 内存在 `PlugIns/CarIdleWidget.appex`；如果小组件列表不出现，优先检查扩展是否被嵌入、entitlements 和签名，而不是重写 UI。
- iOS 最低版本保持 16.0，不使用 iOS 17 专属 Widget API（例如 `containerBackground(for:)`）。

## V2.2.1 小组件同步兼容
- 不要只依赖 App Group：TrollStore + iOS 16 的 Widget Extension 存在容器/沙盒异常案例。
- 正常环境优先 `group.com.trollbox.caridle`；读取为空时才启用 TrollStore fallback。
- fallback 文件仅保存小组件摘要，路径为主 App `Library/Application Support/CarIdleWidgetSnapshot.json`。
- Widget 只读主 App 摘要，不直接修改主 App 历史数据。
- 保留 Bundle ID `com.trollbox.caridle` 与 Widget `com.trollbox.caridle.widget`。
