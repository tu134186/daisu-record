# AI 接手开发说明

当前版本：V2.2.11 / build 41。接手后必须先阅读 `DEVELOPMENT.md` 和 `CHANGELOG.md`。

## 当前最重要结论
桌面 Widget 真机表现为“内容空白，但切换/点击存在阴影”。V2.2.8 已排除业务数据/App Group 依赖，V2.2.9 已使用固定白底黑字，V2.2.10 已清理为单 Widget Extension。V2.2.11 不改变该诊断架构，只重新整理开发说明并在 App 关于页加入历史版本更新记录。

## 禁止重复尝试
- 不要新增第二个 Widget target 或第二份 @main Widget。
- 不要恢复旧 kind。当前唯一 kind：`CarIdleMediumWidgetV2210Single`。
- 不要用跨沙盒扫描、私有 entitlement、额外重签来“碰运气”。
- 静态 Widget 尚未显示前，不要恢复复杂业务 UI。

## 下一步
若静态 Widget 仍空白，必须优先检查最终编译 IPA 中 `PlugIns/CarIdleWidget.appex` 的实际结构、Info.plist、Mach-O 最低系统版本、签名/entitlements 与系统注册情况。

## 发布要求
每版同步 project.yml、Widget 诊断文字、CHANGELOG、DEVELOPMENT、AI接手开发说明、App 内完整更新日志、关于页历史摘要和交付 ZIP 文件名。源码 ZIP 根目录直接放工程文件。
