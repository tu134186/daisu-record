# AI 接手开发说明

当前版本：2.0.0，基于用户提供的 v1.10.4 源码升级。

重点：
1. V2 没有重写 Store/Models 数据结构，目的是保留旧数据兼容。
2. 首页已重做；历史、报表、保养、设置主要保留旧功能并拆分文件，后续可逐页继续做 V2 视觉统一。
3. 不要为了“重构漂亮”随意改 UserDefaults key，否则旧记录会像丢失一样。
4. `Store.swift` 年检规则目前仍是旧版硬编码逻辑，这是待重构项，不应在没有明确规则来源时自行改政策。
5. 最低系统 iOS 16.0。
6. 设置页版本号已经改成 Bundle 动态读取；发布仍需同步 project.yml 与更新日志。


## GitHub Actions 构建规则（V2.0.1 起）
不要在构建开始时检查 `app.zip`。`app.zip` 是 xcodebuild 成功后才生成的最终产物。正确顺序必须是：xcodegen → xcodebuild → 查找 Release-iphoneos 下的 `.app` → 组装 Payload → zip → 上传。GitHub Actions 才是真实编译环境。


## V2.0.2 固定发布规则
- 对外 App 名称：怠速记录。
- Bundle ID 继续保持 `com.trollbox.caridle`，非必要不要修改。
- 用户 GitHub 仓库采用固定工作流读取根目录 `app.zip`。
- 后续交付优先只给新的 `app.zip`，用户上传覆盖即可，不要求手机解压源码。


## 当前版本 V2.1.0
首页已经完成第一轮精修：压缩顶部空间、自然化闲置时间、弱化长期超期提醒、移除首页重复设置入口、压缩最近一次卡片。下一步优先根据真机截图继续微调，不要破坏 V2.0.x 已验证的数据兼容和 GitHub app.zip 编译流程。
