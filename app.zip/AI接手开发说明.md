# AI接手开发说明.md

## V2.2.3 Widget 稳定基线
- 以 V2.2.0 真机可显示为基线。
- 不加入跨沙盒扫描、私有 AppDataContainers entitlement、额外 Widget 重签。
- 空白表示 Extension 渲染失败；出现诊断文字表示 Extension 正常但 App Group 未连通。


## V2.2.4 编译修复记录
- `CarIdleWidgetEntry` 结构包含 `sharedDataConnected: Bool`，所有初始化位置必须同步传入该参数。
- V2.2.3 的 `placeholder` 与 `getTimeline` 漏传参数，会导致 Swift 编译阶段报 Missing argument for parameter `sharedDataConnected`。
- 修复仅补齐构造参数，不改 V2.2.3 已确定的 Widget 稳定架构。

## V2.2.6 当前测试点
- 用户在 iOS 16.5 / TrollStore 环境看到 Widget 系统骨架阴影但无内容。
- 本版 Widget 已缩为完全静态、无 App Group 访问的最小 Extension，用于把“渲染代码问题”和“appex 启动/签名问题”彻底分开。
- 不要在确认 V2.2.6 真机结果前继续增加 Widget 业务逻辑。
