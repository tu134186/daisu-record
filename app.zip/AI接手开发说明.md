# V2.2.23 最新验证补充

- 真机确认 V2.2.22：安装后 Widget 空白；点击空白 Widget 可以拉起主 App，但打开 App 后 Widget 依旧空白；注销 SpringBoard 后立即显示。
- 这已经把“必须先打开一次 App”排除掉，也再次排除静态 Widget View 本身永久崩溃。
- Apple 的 `WidgetCenter.reloadTimelines` / `reloadAllTimelines` 是“重新加载已配置 Widget 的时间线”，不是“注册/重注册 Extension”的 API；因此此前继续强刷没有理论依据。
- TrollStore 2.1 起官方提供 **Refresh App Registrations**。下一步优先验证该安装侧注册刷新能否代替注销，而不是继续堆 WidgetKit reload 补丁。
- V2.2.23 设置页新增只读“小组件诊断”：调用 `getCurrentConfigurations` 查看系统当前是否能返回固定 kind `CarIdleMediumWidget`，不触发 reload，不修改桌面快照。
- 当前版本：V2.2.23 / build 53。

# V2.2.22 最新验证补充

- 真机现象：安装后空白，注销 SpringBoard 后正常。
- V2.2.21 复查发现 `Store.swift` 仍残留 `WidgetCenter.shared.reloadTimelines(ofKind:)`，且 `IdleStore.init()` 会触发它；所以此前所谓“被动注册”并不彻底。
- V2.2.22 已删除主 App 中最后一条 WidgetCenter 刷新路径以及 Store.swift 的 WidgetKit import，仅保留共享摘要写入。
- 本版是“真正零 WidgetCenter”A/B 测试。若仍只有注销后恢复，下一步不再重复 reload/换 kind，而转向 TrollStore 安装后的 Extension 注册缓存结论与安装侧处理。
- 当前版本：V2.2.22 / build 52。

# V2.2.21 最新接手重点

当前版本：V2.2.21 / build 51。

## 当前最重要的真机结论
- V2.2.19：安装后空白，注销后可显示。
- V2.2.20：新增 App 启动/回前台 WidgetCenter 主动刷新后，覆盖安装完成会**马上把 Widget 变为空白**。因此该主动刷新方案已经真机判定失败。
- V2.2.21 必须保持被动注册最小路径：主 App 不操作 WidgetCenter，Widget 使用 `.never`，固定 kind `CarIdleMediumWidget`。

## 高风险/禁止重复
不要再次加入 `reloadAllTimelines()`、`getCurrentConfigurations` + `reloadTimelines` 的启动强刷组合；不要加入 0.8s/2.5s 延迟循环；不要换 kind；不要增加第二 Extension；不要改 Bundle ID。

## 判断原则
如果 V2.2.21 仍然只有注销后才能显示，则优先判定为 TrollStore 覆盖安装后系统没有立即重载 Widget Extension，而不是继续修改 SwiftUI Widget View。注销后能显示本身已经证明新 appex 可以运行。

接手时先读 `DEVELOPMENT.md`、`CHANGELOG.md`、`WIDGET-TROLLSTORE-验证记录.md`，所有版本号位置必须同步。
