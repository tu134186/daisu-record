# V2.2.20 最新接手重点

- 最新真机：V2.2.19 安装后 Widget 空白，注销后显示。
- V2.2.20 采用“首次启动/回前台 -> WidgetCenter.getCurrentConfigurations -> 固定 kind 刷新”方案，并把 Timeline 改为 5 分钟 `.after`。
- 禁止改 Bundle ID、禁止换 kind、禁止第二 Widget target、禁止再加 0.8s/2.5s 延迟循环。
- 测试必须分别记录：安装后未开 App、打开 App 后、5 分钟后、注销后的显示结果。

# 怠速记录（CarIdle）AI 接手开发说明

当前版本：V2.2.20 / build 50。接手本项目时，必须先阅读本文件、`DEVELOPMENT.md`、`CHANGELOG.md` 和 `WIDGET-TROLLSTORE-验证记录.md`，再修改任何 Widget 相关代码。

## 当前已经确定的结论

项目运行在 iOS 16.x / TrollStore 类安装环境。Widget Extension 本身可以安装并工作，但 TrollStore 覆盖安装后的 Widget 重新加载行为不能当作 App Store 更新流程的 100% 等价实现。

V2.2.18 真机已经完成关键验证：覆盖安装新版本后，桌面原有 Widget 一度仍显示 V2.2.12；注销 SpringBoard 后，同一个 Widget 立即正确显示 V2.2.18。这个结果说明新包里的 Widget Extension 与版本号已经更新成功，问题不是“源码里还藏着 2212”，而是覆盖安装后系统仍在使用旧的 Extension/Widget 状态。

## V2.2.20 的维护原则

V2.2.20 继续保留单一 `CarIdleWidget` Extension、固定 Bundle ID、固定 `kind = CarIdleMediumWidget` 和最小可验证 Widget 结构；只增加公开 WidgetCenter 的首次启动/回前台配置查询刷新，并将 Timeline 改为 5 分钟后再次请求。

正常升级测试流程：覆盖安装新版 → 观察桌面 Widget；如果仍显示旧版 → 注销 SpringBoard 一次 → 再观察。注销后能显示新版本，视为 TrollStore 环境下升级成功。只有注销后仍然错误，才继续查最终 IPA 中的 `.appex`、Info.plist、版本号、签名和注册。

## 已验证成功

- TrollStore 可以安装本项目的 Widget Extension。
- 注销 SpringBoard 后，V2.2.18 Widget 能从旧显示切换到 V2.2.18。
- 主 App 与 Widget 使用相同营销版本/build 可以正常打包。
- Widget kind 固定为 `CarIdleMediumWidget` 的结构可继续使用。

## 已验证无效/禁止重复

- 为“清缓存”每版更换 Widget kind：会让桌面已有配置绑定旧身份，禁止。
- 主 App 启动后叠加 0.8 秒/2.5 秒延迟 `reloadTimelines`：没有形成稳定保证，禁止作为默认方案重新加入。
- 不断增加 Timeline 定时刷新来解决 Extension 覆盖安装注册问题：方向错误。
- 增加第二 Widget target、第二个 `@main Widget`、旧源码并存：会增加注册冲突风险。
- 跨沙盒扫描、私有 entitlement、额外重签：此前已回退，禁止无明确证据重新加入。

## 高风险区域

不要随意修改主 App Bundle ID `com.trollbox.caridle`、Widget Bundle ID `com.trollbox.caridle.widget`、App 历史数据键、Widget target 数量、Widget kind、deployment target。任何高风险改动必须有明确原因，并遵守“一版只改变一个变量”。

## 版本同步

每次发版必须同时更新 `project.yml` 中主 App/Widget 的 MARKETING_VERSION 和 CURRENT_PROJECT_VERSION、Widget 可见版本文字、App 内 VersionHistoryView、CHANGELOG、DEVELOPMENT、BUILD-PROVENANCE、检查脚本默认版本及本说明。

## 打包要求

源码 ZIP 解压后根目录必须直接看到 `project.yml`、`CarIdle/`、`CarIdleWidget/`、`Shared/`、`tools/` 和开发说明，禁止额外套一层目录。不要把旧 Widget target 或第二套会参与编译的历史源码塞进包里。
