# V2.2.13 当前验证重点
- 关于页已恢复为“当前版本 + 历史更新入口”，完整日志放在独立页面。
- Widget 使用全新 kind `CarIdleMediumWidgetV2213Fresh`，主 App 在启动后 0.8 秒和 2.5 秒请求刷新。
- 本版目的：排除上一版注销后缓存影响，验证首次安装/添加能否无需注销直接显示。
- 仍禁止恢复 App Group、复杂业务 Widget UI 或高风险签名方案，先只验证系统注册/刷新。

# AI 接手开发说明

当前版本：V2.2.13 / build 43。接手后必须先阅读 `DEVELOPMENT.md` 和 `CHANGELOG.md`。

## 当前最重要结论
桌面 Widget 真机表现为“内容空白，但切换/点击存在阴影”。V2.2.8 已排除业务数据/App Group 依赖，V2.2.9 已使用固定白底黑字，V2.2.10 已清理为单 Widget Extension。V2.2.12 真机确认：Widget 安装并添加后曾出现不会马上显示，但注销 SpringBoard 后能正常出现；之后再次安装又能直接显示，因此仍无法确定是注销后的缓存/注册状态还是代码本身生效。V2.2.13 专门使用新 kind 和轻量刷新重新验证首次显示。关于页已恢复为“当前版本 + 历史更新入口”，完整历史在独立全屏页面查看。

## 禁止重复尝试
- 不要新增第二个 Widget target 或第二份 @main Widget。
- 不要恢复旧 kind。当前唯一 kind：`CarIdleMediumWidgetV2213Fresh`。
- 不要用跨沙盒扫描、私有 entitlement、额外重签来“碰运气”。
- 静态 Widget 尚未显示前，不要恢复复杂业务 UI。

## 下一步
当前已知注销 SpringBoard 后 Widget 可以显示。下一步优先修“安装/添加后立即显示”，检查 WidgetCenter 刷新、系统注册与快照生命周期；禁止为了这个问题重写已经可显示的 Widget View。

## 发布要求
每版同步 project.yml、Widget 诊断文字、CHANGELOG、DEVELOPMENT、AI接手开发说明、App 内完整更新日志、关于页历史摘要和交付 ZIP 文件名。源码 ZIP 根目录直接放工程文件。
