# V2.2.21 最新接手重点

当前版本：V2.2.21 / build 51。

## 当前最重要的真机结论
- V2.2.19：安装后空白，注销后可显示。
- V2.2.20：新增 App 启动/回前台 WidgetCenter 主动刷新后，覆盖安装完成会**马上把 Widget 变为空白**。因此该主动刷新方案已经真机判定失败。
- V2.2.21 必须保持被动注册最小路径：主 App 不操作 WidgetCenter，Widget 使用 `.never`，固定 kind `CarIdleMediumWidget`。

## 高风险/禁止重复
不要再次加入 `reloadAllTimelines()`、`getCurrentConfigurations` + `reloadTimelines` 的启动强刷组合；不要加入 0.8s/2.5s 延迟循环；不要换 kind；不要增加第二 Extension；不要改 Bundle ID。

## 判断原则
如果 V2.2.21 仍然只有注销后才能显示，则优先判定为 TrollStore 覆盖安装后系统没有立即重载 Widget Extension，而不是继续修改 SwiftUI Widget View。注销后能显示本身已经证明新 appex 可以运行。

接手时先读 `DEVELOPMENT.md`、`CHANGELOG.md`、`WIDGET-TROLLSTORE-验证记录.md`，所有版本号位置必须同步。
