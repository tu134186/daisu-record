# AI接手开发说明.md

## V2.2.3 Widget 稳定基线
- 以 V2.2.0 真机可显示为基线。
- 不加入跨沙盒扫描、私有 AppDataContainers entitlement、额外 Widget 重签。
- 空白表示 Extension 渲染失败；出现诊断文字表示 Extension 正常但 App Group 未连通。


## V2.2.4 编译修复记录
- `CarIdleWidgetEntry` 结构包含 `sharedDataConnected: Bool`，所有初始化位置必须同步传入该参数。
- V2.2.3 的 `placeholder` 与 `getTimeline` 漏传参数，会导致 Swift 编译阶段报 Missing argument for parameter `sharedDataConnected`。
- 修复仅补齐构造参数，不改 V2.2.3 已确定的 Widget 稳定架构。


## V2.2.8 Widget 最小隔离基线
- Widget target 已完全断开 Shared/App Group，仅保留 SwiftUI + WidgetKit。
- 使用新 kind `CarIdleMediumWidgetV228Diagnostic` 强制避开旧 WidgetKit 配置缓存。
- 若仍空白，不要继续改 Widget View；应检查最终 IPA 的 PlugIns/CarIdleWidget.appex、可执行文件、Info.plist 和安装后扩展注册状态。
