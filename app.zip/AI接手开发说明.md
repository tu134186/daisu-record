## V2.0.2 恢复包（2026-09-02）

- 按源码内 V2.0.2 稳定基线恢复：版本 2.0.2 / build 28，Bundle ID 保持 `com.trollbox.caridle`。
- 保留完整主 App 功能：首页车辆状态、启动/熄火、历史、报表、保养、年检、提醒、JSON/CSV 导入导出、设置。
- 去除 V2.2.x 后续桌面小组件/App Group 同步依赖，避免继续干扰主 App。
- 源码包内 `CarIdle/history_records.json` 共 133 条旧怠速记录仍完整保留。
- 新增安全恢复：仅当本机 `idleRecords` 完全为空时，首次启动自动导入内置历史；已有数据时绝不覆盖或重复导入。

## V2.2.28 / Build 58（2026-09-02）
- 用户决定停止继续投入 TrollStore Widget 安装后即时刷新问题。
- 本版以主 App 完整功能恢复为第一优先级：首页恢复 6 个快捷入口（历史/报表/保养/导出/导入/设置）。
- 数据导入导出、保养、保险、年检、启动提醒、历史记录、报表等功能全部保留。
- 工程停止编译 Widget Extension；历史 Widget 排查记录保留在文档中，仅供以后参考，不再作为当前开发目标。
- 主 App：2.2.28 / build 58。

## V2.2.27 / Build 57（2026-09-02）
- 用户真机再次确认：安装后小组件异常时，注销 SpringBoard 后能够正常显示；继续按 TrollStore/iOS 16.5 Extension 注册/缓存问题记录，不再重复堆 reload 补丁。
- 恢复此前完整业务小组件：当前运行/熄火状态、距上次启动、上次时长、总次数、下次启动建议；不再只显示诊断版本文字。
- 主 App 原有完整功能全部保留：启动/熄火计时、历史记录、报表、保养、年检、提醒、JSON/CSV 导入导出、清空数据、设置和完整历史更新。
- 保留已验证的固定 kind `CarIdleMediumWidget`、单一 Extension、App Group 权限、Extension 运行心跳诊断，以及主 App 零主动 WidgetCenter reload 路径。
- 主 App / Widget / 工程 / 校验脚本统一为 2.2.27 / build 57。

## V2.2.26 / Build 56（2026-09-02）
- 修复 V2.2.25 编译失败：心跳方法 `markWidgetHeartbeat/widgetHeartbeatDate/sharedDataIsConnected` 被误写进 `CarIdleWidgetSnapshot`，但调用处使用的是 `CarIdleWidgetShared`，导致 Widget target CompileSwift 失败。
- 本版把三项共享诊断方法移回 `CarIdleWidgetShared`，保持 Widget 与主 App 调用一致。
- 不改变 V2.2.25 的诊断方案与 Widget 行为，仅做编译修复和版本同步。
- 真机测试仍按固定顺序：安装后先看负一屏，再打开 App，再点重新检测，以区分“安装即显示/打开 App 后显示/检测后显示”。


## V2.2.26 / Build 56（2026-09-02）
- 实测发现：TrollStore 安装后，`WidgetCenter.getCurrentConfigurations` 可能返回空数组，但负一屏小组件实际上已经能够显示。
- 因此“系统列表为空 = 未登记”的诊断结论是错误的，V2.2.26 废除这一单一判断。
- Widget Extension 在 `getSnapshot/getTimeline` 真正执行时向 App Group 写入运行心跳；设置页优先以该心跳确认 Extension 已实际运行。
- 若系统配置列表为空但存在心跳，显示“已运行”，明确提示 WidgetCenter 列表结果不可靠。
- 不新增 reloadTimelines 强刷补丁。

# V2.2.26 最新验证补充

- 根据 V2.2.23 真机截图，设置页明确返回“未登记”，与安装后 Widget 空白一致。
- 代码审查发现主 App 已声明 `group.com.trollbox.caridle`，但 Widget Extension 的 entitlements 是空字典，而且 project.yml 没有给 Extension 配置 `CODE_SIGN_ENTITLEMENTS`。这是打包配置缺口。
- V2.2.26 为 Widget Extension 补齐同一个 App Group entitlement，并把 Shared 源码同时编入 Extension，保证后续恢复真实共享数据时主 App/Widget 权限与共享模型一致。
- “重新检测”改为整行可点，并在点击后立即显示“检测中…”，避免看起来像没反应。
- 保持固定 kind `CarIdleMediumWidget`，不新增 reloadTimelines/reloadAllTimelines，不更换 Bundle ID。
- 当前版本：V2.2.26 / build 56。

# V2.2.23 最新验证补充

- 真机确认 V2.2.22：安装后 Widget 空白；点击空白 Widget 可以拉起主 App，但打开 App 后 Widget 依旧空白；注销 SpringBoard 后立即显示。
- 这已经把“必须先打开一次 App”排除掉，也再次排除静态 Widget View 本身永久崩溃。
- Apple 的 `WidgetCenter.reloadTimelines` / `reloadAllTimelines` 是“重新加载已配置 Widget 的时间线”，不是“注册/重注册 Extension”的 API；因此此前继续强刷没有理论依据。
- TrollStore 2.1 起官方提供 **Refresh App Registrations**。下一步优先验证该安装侧注册刷新能否代替注销，而不是继续堆 WidgetKit reload 补丁。
- V2.2.23 设置页新增只读“小组件诊断”：调用 `getCurrentConfigurations` 查看系统当前是否能返回固定 kind `CarIdleMediumWidget`，不触发 reload，不修改桌面快照。
- 当前版本：V2.2.23 / build 53。

# V2.2.22 最新验证补充

- 真机现象：安装后空白，注销 SpringBoard 后正常。
- V2.2.21 复查发现 `Store.swift` 仍残留 `WidgetCenter.shared.reloadTimelines(ofKind:)`，且 `IdleStore.init()` 会触发它；所以此前所谓“被动注册”并不彻底。
- V2.2.22 已删除主 App 中最后一条 WidgetCenter 刷新路径以及 Store.swift 的 WidgetKit import，仅保留共享摘要写入。
- 本版是“真正零 WidgetCenter”A/B 测试。若仍只有注销后恢复，下一步不再重复 reload/换 kind，而转向 TrollStore 安装后的 Extension 注册缓存结论与安装侧处理。
- 当前版本：V2.2.22 / build 52。

# V2.2.21 最新接手重点

当前版本：V2.2.21 / build 51。

## 当前最重要的真机结论
- V2.2.19：安装后空白，注销后可显示。
- V2.2.20：新增 App 启动/回前台 WidgetCenter 主动刷新后，覆盖安装完成会**马上把 Widget 变为空白**。因此该主动刷新方案已经真机判定失败。
- V2.2.21 必须保持被动注册最小路径：主 App 不操作 WidgetCenter，Widget 使用 `.never`，固定 kind `CarIdleMediumWidget`。

## 高风险/禁止重复
不要再次加入 `reloadAllTimelines()`、`getCurrentConfigurations` + `reloadTimelines` 的启动强刷组合；不要加入 0.8s/2.5s 延迟循环；不要换 kind；不要增加第二 Extension；不要改 Bundle ID。

## 判断原则
如果 V2.2.21 仍然只有注销后才能显示，则优先判定为 TrollStore 覆盖安装后系统没有立即重载 Widget Extension，而不是继续修改 SwiftUI Widget View。注销后能显示本身已经证明新 appex 可以运行。

接手时先读 `DEVELOPMENT.md`、`CHANGELOG.md`、`WIDGET-TROLLSTORE-验证记录.md`，所有版本号位置必须同步。
