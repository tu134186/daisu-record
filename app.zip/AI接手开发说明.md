# AI 接手开发说明

当前版本：V2.2.12 / build 42。接手后必须先阅读 `DEVELOPMENT.md` 和 `CHANGELOG.md`。

## 当前最重要结论
桌面 Widget 真机表现为“内容空白，但切换/点击存在阴影”。V2.2.8 已排除业务数据/App Group 依赖，V2.2.9 已使用固定白底黑字，V2.2.10 已清理为单 Widget Extension。V2.2.12 真机确认：Widget 安装并添加后可能不会马上显示，但注销 SpringBoard 后能正常出现。说明当前静态 Widget 基线可以工作，剩余重点是首次注册/刷新时机。本版同时把 App 关于页改为“当前版本 + 连续完整历史更新”。

## 禁止重复尝试
- 不要新增第二个 Widget target 或第二份 @main Widget。
- 不要恢复旧 kind。当前唯一 kind：`CarIdleMediumWidgetV2210Single`。
- 不要用跨沙盒扫描、私有 entitlement、额外重签来“碰运气”。
- 静态 Widget 尚未显示前，不要恢复复杂业务 UI。

## 下一步
当前已知注销 SpringBoard 后 Widget 可以显示。下一步优先修“安装/添加后立即显示”，检查 WidgetCenter 刷新、系统注册与快照生命周期；禁止为了这个问题重写已经可显示的 Widget View。

## 发布要求
每版同步 project.yml、Widget 诊断文字、CHANGELOG、DEVELOPMENT、AI接手开发说明、App 内完整更新日志、关于页历史摘要和交付 ZIP 文件名。源码 ZIP 根目录直接放工程文件。
