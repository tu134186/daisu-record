V2.3.6 Fix4 / Build 41
Only CarIdleWidget/IdleWidget.swift changed from Fix3.
Lock Screen: opaque dark background, explicit foregroundColor on every Text.
Expanded Island: center and bottom regions, away from camera cutout.
Compact trailing: 2pt right content margin.
Not compiled on Xcode / not device verified. End old Live Activity before retesting.
