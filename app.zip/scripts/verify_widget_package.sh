#!/bin/sh
set -eu
APP_PATH="${1:-}"
if [ -z "$APP_PATH" ] || [ ! -d "$APP_PATH" ]; then
  echo "usage: $0 /path/to/CarIdle.app" >&2
  exit 2
fi
APPEX="$APP_PATH/PlugIns/CarIdleWidget.appex"
[ -d "$APPEX" ] || { echo "ERROR: missing $APPEX"; exit 3; }
[ -f "$APPEX/Info.plist" ] || { echo "ERROR: missing Widget Info.plist"; exit 4; }
EXE=$(/usr/libexec/PlistBuddy -c 'Print :CFBundleExecutable' "$APPEX/Info.plist")
[ -x "$APPEX/$EXE" ] || { echo "ERROR: missing Widget executable: $EXE"; exit 5; }
echo "OK: Widget appex embedded: $APPEX"
echo "Widget bundle id: $(/usr/libexec/PlistBuddy -c 'Print :CFBundleIdentifier' "$APPEX/Info.plist")"
echo "Widget executable: $EXE"
if command -v codesign >/dev/null 2>&1; then
  echo "--- codesign ---"
  codesign -dvv "$APPEX" 2>&1 || true
  echo "--- entitlements ---"
  codesign -d --entitlements :- "$APPEX" 2>/dev/null || true
fi
