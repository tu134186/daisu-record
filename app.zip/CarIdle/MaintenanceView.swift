import SwiftUI
import UIKit
import Charts
import UniformTypeIdentifiers

struct MaintenanceView: View {
    @ObservedObject var store: IdleStore
    @Environment(\.dismiss) private var dismiss
    @State private var showAdd = false
    @State private var selectedRecord: MaintenanceRecord?
    @State private var selectedType: MaintenanceType?

    private func statusColor(for type: MaintenanceType) -> Color {
        if type == .inspection {
            guard store.vehicleRegistrationDate != nil else { return .gray }
            switch store.inspectionStatusLevel {
            case 2: return .red
            case 1: return .orange
            default: return .green
            }
        }
        guard let latest = store.latestMaintenance(for: type) else { return .gray }
        switch latest.statusLevel {
        case 2: return .red
        case 1: return .orange
        default: return .green
        }
    }

    private func statusText(for type: MaintenanceType) -> String {
        if type == .inspection {
            guard store.vehicleRegistrationDate != nil else { return "未设置" }
            guard let days = store.daysUntilInspection else { return "—" }
            if days <= 0 { return "超期\(-days)天" }
            return "还有\(days)天"
        }
        guard let latest = store.latestMaintenance(for: type) else { return "未记录" }
        return "已过去\(latest.daysSince)天"
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("保养项目").font(.subheadline.bold()).foregroundStyle(.secondary).padding(.horizontal, 4)
                        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
                            ForEach(MaintenanceType.allCases) { type in
                                Button {
                                    selectedType = type
                                } label: {
                                    VStack(spacing: 6) {
                                        ZStack {
                                            Circle().fill(statusColor(for: type).opacity(0.15)).frame(width: 36, height: 36)
                                            Image(systemName: type.icon).font(.system(size: 16)).foregroundStyle(statusColor(for: type))
                                        }
                                        Text(type.rawValue).font(.caption2).foregroundStyle(.primary)
                                        Text(statusText(for: type))
                                            .font(.caption2).foregroundStyle(statusColor(for: type)).monospacedDigit()
                                    }
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 10)
                                    .background(Color(.tertiarySystemGroupedBackground))
                                    .clipShape(RoundedRectangle(cornerRadius: 10))
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }
                    .padding(16)
                    .background(Color(.secondarySystemGroupedBackground))
                    .clipShape(RoundedRectangle(cornerRadius: 16))

                    // 添加按钮
                    Button { showAdd = true } label: {
                        HStack {
                            Image(systemName: "plus.circle.fill").font(.title3)
                            Text("记录保养").font(.headline.bold())
                        }
                        .frame(maxWidth: .infinity).padding()
                        .background(Color.green).foregroundStyle(.white)
                        .clipShape(RoundedRectangle(cornerRadius: 14))
                    }
                    .buttonStyle(.plain)

                    // 全部历史
                    if !store.maintenanceRecords.isEmpty {
                        VStack(alignment: .leading, spacing: 10) {
                            Text("全部记录").font(.subheadline.bold()).foregroundStyle(.secondary).padding(.horizontal, 4)
                            VStack(spacing: 8) {
                                ForEach(store.maintenanceRecords) { record in
                                    Button { selectedRecord = record } label: {
                                        HStack(spacing: 12) {
                                            ZStack {
                                                Circle().fill(Color.green.opacity(0.12)).frame(width: 36, height: 36)
                                                Image(systemName: record.type.icon).font(.system(size: 16)).foregroundStyle(.green)
                                            }
                                            VStack(alignment: .leading, spacing: 3) {
                                                HStack {
                                                    Text(record.displayName).font(.subheadline.bold())
                                                    Spacer()
                                                    Text(record.shortDateText).font(.caption).foregroundStyle(.secondary)
                                                }
                                                HStack(spacing: 6) {
                                                    Text("已过去\(record.daysSince)天").font(.caption2).foregroundStyle(.secondary).monospacedDigit()
                                                    if !record.note.isEmpty {
                                                        Text("·").font(.caption2).foregroundStyle(.tertiary)
                                                        Text(record.note).font(.caption2).foregroundStyle(.secondary).lineLimit(1)
                                                    }
                                                }
                                            }
                                        }
                                        .padding(12)
                                        .background(Color(.tertiarySystemGroupedBackground))
                                        .clipShape(RoundedRectangle(cornerRadius: 10))
                                    }
                                    .buttonStyle(.plain)
                                }
                            }
                        }
                        .padding(16)
                        .background(Color(.secondarySystemGroupedBackground))
                        .clipShape(RoundedRectangle(cornerRadius: 16))
                    }
                }
                .padding(.horizontal, 16).padding(.top, 8).padding(.bottom, 20)
            }
            .background(Color(.systemGroupedBackground))
            .navigationTitle("保养提醒").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItemGroup(placement: .topBarLeading) { Button("返回") { dismiss() } } }
            .sheet(isPresented: $showAdd) {
                AddMaintenanceView(store: store)
            }
            .sheet(item: $selectedRecord) { record in
                MaintenanceDetailView(store: store, record: record) {
                    store.deleteMaintenanceRecord(record)
                    selectedRecord = nil
                }
            }
            .sheet(item: $selectedType) { type in
                MaintenanceTypeHistoryView(store: store, type: type)
            }
        }
    }
}

// MARK: - 某类型历史
