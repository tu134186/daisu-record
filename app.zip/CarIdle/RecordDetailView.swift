import SwiftUI
import UIKit
import Charts
import UniformTypeIdentifiers

struct RecordDetailView: View {
    @ObservedObject var store: IdleStore
    let record: IdleRecord
    let onDelete: () -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var noteText: String

    init(store: IdleStore, record: IdleRecord, onDelete: @escaping () -> Void) {
        self.store = store; self.record = record; self.onDelete = onDelete
        _noteText = State(initialValue: record.note)
    }

    var body: some View {
        NavigationStack {
            List {
                Section {
                    HStack { Text("日期"); Spacer(); Text(record.dateText).foregroundStyle(.secondary) }
                    HStack { Text("启动时间"); Spacer(); Text(record.startTimeText).foregroundStyle(.secondary) }
                    HStack { Text("熄火时间"); Spacer(); Text(record.endTimeText).foregroundStyle(.secondary) }
                    HStack { Text("运行时长"); Spacer(); Text(record.durationText).foregroundStyle(.green).bold() }
                    if let interval = store.intervalDays(for: record) {
                        HStack { Text("距上次启动"); Spacer(); Text("\(interval) 天").foregroundStyle(.secondary) }
                    }
                }
                Section("备注") {
                    TextField("添加备注，如：电瓶指示灯亮了", text: $noteText, axis: .vertical).lineLimit(2...4)
                }
                Section {
                    Button(role: .destructive) { onDelete(); dismiss() } label: {
                        HStack { Image(systemName: "trash"); Text("删除此记录") }
                    }
                }
            }
            .navigationTitle("记录详情").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItemGroup(placement: .topBarLeading) { Button("返回") { dismiss() } }
                ToolbarItemGroup(placement: .topBarTrailing) {
                    Button("保存") { store.updateNote(record, note: noteText); dismiss() }
                }
            }
        }
    }
}

// MARK: - 导出页
