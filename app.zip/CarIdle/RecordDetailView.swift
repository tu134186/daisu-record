import SwiftUI

struct RecordDetailView: View {
    @ObservedObject var store: IdleStore
    let record: IdleRecord
    let onDelete: () -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var start: Date
    @State private var end: Date
    @State private var noteText: String
    @State private var showError = false

    init(store: IdleStore, record: IdleRecord, onDelete: @escaping () -> Void) {
        self.store = store
        self.record = record
        self.onDelete = onDelete
        _start = State(initialValue: record.startTime)
        _end = State(initialValue: record.endTime ?? record.startTime)
        _noteText = State(initialValue: record.note)
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("记录时间") {
                    DatePicker("启动时间", selection: $start, in: ...Date())
                    DatePicker("熄火时间", selection: $end, in: ...Date())
                    if end > start {
                        HStack {
                            Text("运行时长")
                            Spacer()
                            Text(durationText).foregroundStyle(AppleDesign.positive).bold()
                        }
                    } else {
                        Text("熄火时间必须晚于启动时间").foregroundStyle(.red)
                    }
                }
                Section("备注") {
                    TextField("添加备注", text: $noteText, axis: .vertical).lineLimit(2...4)
                }
                Section {
                    Button(role: .destructive) { onDelete(); dismiss() } label: {
                        Label("删除此记录", systemImage: "trash")
                    }
                }
            }.proGroupedRows()
            .navigationTitle("记录详情").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) { Button("返回") { dismiss() } }
                ToolbarItem(placement: .topBarTrailing) {
                    Button("保存") {
                        if store.updateRecord(record, start: start, end: end, note: noteText) {
                            dismiss()
                        } else { showError = true }
                    }.disabled(end <= start || end > Date() || start > Date())
                }
            }
            .alert("保存失败", isPresented: $showError) {
                Button("确定", role: .cancel) { }
            } message: { Text("请检查时间是否正确，或确认本机存储可用。") }
        }
    }

    private var durationText: String {
        let seconds = Int(end.timeIntervalSince(start))
        return "\(seconds / 3600)小时\((seconds % 3600) / 60)分"
    }
}
