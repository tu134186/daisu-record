import SwiftUI
import WidgetKit

@main
struct CarIdleApp: App {
    private static let currentWidgetKind = "CarIdleMediumWidgetV2213Fresh"

    init() {
        // 只请求当前诊断 Widget 刷新，不访问共享数据、不触碰业务存储。
        // 两个时间点用于覆盖安装后 Extension 注册稍慢的情况；系统仍会自行节流。
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) {
            WidgetCenter.shared.reloadTimelines(ofKind: Self.currentWidgetKind)
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
            WidgetCenter.shared.reloadTimelines(ofKind: Self.currentWidgetKind)
        }
    }

    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
