import SwiftUI

@main
struct CarIdleApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
