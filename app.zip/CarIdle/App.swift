import SwiftUI
import WidgetKit

@main
struct CarIdleApp: App {
    init() {
        // 只触发系统刷新，不访问 Widget 数据。用于覆盖安装后尽快丢弃旧快照。
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            WidgetCenter.shared.reloadAllTimelines()
        }
    }

    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
