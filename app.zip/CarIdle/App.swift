import SwiftUI
import WidgetKit

@main
struct CarIdleApp: App {
    @Environment(\.scenePhase) private var scenePhase

    var body: some Scene {
        WindowGroup {
            ContentView()
                .task {
                    WidgetBootstrap.requestRegistrationAwareRefresh()
                }
        }
        .onChange(of: scenePhase) { newPhase in
            if newPhase == .active {
                WidgetBootstrap.requestRegistrationAwareRefresh()
            }
        }
    }
}

/// V2.2.20：只使用 Apple 公开 WidgetKit API 做“安装后首次启动”唤醒。
///
/// 这里故意不再使用历史版本试过的 0.8s / 2.5s 延迟循环，也不改 kind。
/// 先让 WidgetCenter 查询系统当前已经登记的桌面组件，再针对实际存在的 kind
/// 请求一次刷新，同时补一个 reloadAllTimelines。这样可以在 App 首次启动/重新回到前台时
/// 主动建立一次 WidgetKit 连接；若 TrollStore 层面的 Extension 注册本身尚未完成，
/// 公共 API 仍无法保证替代 Respring，因此本方案属于低风险“尽最大可能免注销”方案。
private enum WidgetBootstrap {
    static func requestRegistrationAwareRefresh() {
        let center = WidgetCenter.shared

        // 先发一次全量请求：如果系统已经完成 Extension 注册，可直接触发当前桌面 Widget 重取时间线。
        center.reloadAllTimelines()

        // 再读取当前配置。相比盲目定时 reload，这一步会真实连接 WidgetCenter 并确认桌面配置。
        center.getCurrentConfigurations { result in
            guard case .success(let widgets) = result else { return }

            let kinds = Set(widgets.map(\.kind))
            if kinds.contains("CarIdleMediumWidget") {
                center.reloadTimelines(ofKind: "CarIdleMediumWidget")
            }
        }
    }
}
