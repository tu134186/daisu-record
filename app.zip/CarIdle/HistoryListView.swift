import SwiftUI
import UIKit
import Charts
import UniformTypeIdentifiers

struct HistoryListView: View {
    @ObservedObject var store: IdleStore
    @Environment(\.dismiss) private var dismiss
    @State private var selectedRecord: IdleRecord?
    @State private var showClearConfirm = false

    var groupedRecords: [(year: String, records: [IdleRecord])] {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy"
        let grouped = Dictionary(grouping: store.records) { formatter.string(from: $0.startTime) }
        return grouped.sorted { $0.key > $1.key }.map { (year: $0.key, records: $0.value) }
    }

    func yearStats(_ records: [IdleRecord]) -> (count: Int, minutes: Int) {
        (records.count, records.reduce(0) { $0 + Int(($1.duration ?? 0) / 60) })
    }

    var body: some View {
        NavigationStack {
            List {
                if store.records.isEmpty {
                    Section {
                        VStack(spacing: 12) {
                            Image(systemName: "clock.arrow.circlepath").font(.system(size: 40)).foregroundStyle(.secondary)
                            Text("暂无记录").font(.headline).foregroundStyle(.secondary)
                        }.frame(maxWidth: .infinity).padding(.vertical, 60).listRowBackground(Color.clear)
                    }
                } else {
                    ForEach(groupedRecords, id: \.year) { group in
                        let stats = yearStats(group.records)
                        Section(header: HStack {
                            Text("\(group.year)年").font(.headline)
                            Spacer()
                            Text("\(stats.count)次 · \(stats.minutes)分").font(.caption).foregroundStyle(.secondary)
                        }) {
                            ForEach(group.records) { record in
                                Button { selectedRecord = record } label: {
                                    VStack(alignment: .leading, spacing: 4) {
                                        HStack {
                                            Text(record.shortDateText).font(.subheadline.bold())
                                            if let interval = store.intervalDays(for: record) {
                                                Text("间隔\(interval)天").font(.caption2).foregroundStyle(.secondary)
                                                    .padding(.horizontal, 6).padding(.vertical, 2)
                                                    .background(Color.secondary.opacity(0.15)).clipShape(Capsule())
                                            }
                                            Spacer()
                                            Text(record.durationText).font(.subheadline.bold()).foregroundStyle(.green)
                                        }
                                        Text("\(record.startTimeText) → \(record.endTimeText)").font(.caption).foregroundStyle(.secondary)
                                        if !record.note.isEmpty {
                                            Text(record.note).font(.caption).foregroundStyle(.orange).lineLimit(2)
                                        }
                                    }.padding(.vertical, 2)
                                }
                                .buttonStyle(.plain)
                                .swipeActions(edge: .trailing) {
                                    Button(role: .destructive) { store.delete(record) } label: { Label("删除", systemImage: "trash") }
                                }
                            }
                        }
                    }
                }
            }
            .navigationTitle("历史记录").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItemGroup(placement: .topBarLeading) { Button("返回") { dismiss() } }
                ToolbarItemGroup(placement: .topBarTrailing) {
                    if !store.records.isEmpty {
                        Button { showClearConfirm = true } label: { Image(systemName: "trash") }
                    }
                }
            }
            .alert("确认清空", isPresented: $showClearConfirm) {
                Button("取消", role: .cancel) {}
                Button("清空全部", role: .destructive) {
                    store.clearAll()
                }
            } message: {
                Text("将删除全部\(store.records.count)条怠速记录，此操作不可恢复。")
            }
            .sheet(item: $selectedRecord) { record in
                RecordDetailView(store: store, record: record) {
                    store.delete(record); selectedRecord = nil
                }
            }
        }
    }
}

// MARK: - 设置页
