import SwiftUI
import UIKit
import Charts
import UniformTypeIdentifiers

struct HistoryListView: View {
    @ObservedObject var store: IdleStore
    @Environment(\.dismiss) private var dismiss
    @State private var selectedRecord: IdleRecord?
    @State private var showClearConfirm = false
    @State private var showAdd = false
    @State private var searchText = ""
    @State private var minMinutes = 0
    @State private var selectionMode = false
    @State private var selectedIDs: Set<UUID> = []
    @State private var showDeleteSelected = false
    @State private var showRanking = false
    @State private var range: HistoryRange = .all

    private var filteredRecords: [IdleRecord] {
        let cal = Calendar.current
        let now = Date()
        return store.records.filter { record in
            let matchesSearch = searchText.isEmpty || record.note.localizedCaseInsensitiveContains(searchText) || record.dateText.contains(searchText) || record.shortDateText.contains(searchText)
            let matchesDuration = (record.duration ?? 0) >= Double(minMinutes * 60)
            let matchesDate: Bool
            switch range {
            case .all: matchesDate = true
            case .week: matchesDate = record.startTime >= (cal.date(byAdding: .day, value: -7, to: now) ?? now)
            case .month: matchesDate = record.startTime >= (cal.date(byAdding: .month, value: -1, to: now) ?? now)
            case .year: matchesDate = record.startTime >= (cal.date(byAdding: .year, value: -1, to: now) ?? now)
            }
            return matchesSearch && matchesDuration && matchesDate
        }
    }

    var groupedRecords: [(year: String, records: [IdleRecord])] {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy"
        let grouped = Dictionary(grouping: filteredRecords) { formatter.string(from: $0.startTime) }
        return grouped.sorted { $0.key > $1.key }.map { (year: $0.key, records: $0.value) }
    }

    func yearStats(_ records: [IdleRecord]) -> (count: Int, minutes: Int) {
        (records.count, records.reduce(0) { $0 + Int(($1.duration ?? 0) / 60) })
    }

    @ViewBuilder private func recordContent(_ record: IdleRecord) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack {
                Text(record.shortDateText).font(.subheadline.bold())
                Spacer()
                Text(record.durationText).font(.subheadline.bold()).foregroundStyle(AppleDesign.positive)
            }
            Text("\(record.startTimeText) → \(record.endTimeText)").font(.caption).foregroundStyle(.secondary)
            if !record.note.isEmpty { Text(record.note).font(.caption).foregroundStyle(.orange).lineLimit(2) }
        }.padding(.vertical, 2)
    }

    var body: some View {
        NavigationStack {
            List {
                Section {
                    Picker("日期范围", selection: $range) {
                        ForEach(HistoryRange.allCases) { option in Text(option.rawValue).tag(option) }
                    }.pickerStyle(.segmented)
                    Picker("最短时长", selection: $minMinutes) {
                        Text("不限").tag(0)
                        Text("10分钟").tag(10)
                        Text("30分钟").tag(30)
                        Text("1小时").tag(60)
                        Text("2小时").tag(120)
                    }
                    HStack {
                        Text("筛选结果：\(filteredRecords.count)条").foregroundStyle(.secondary)
                        Spacer()
                        Button("时长排行") { showRanking = true }
                    }.font(.subheadline)
                }
                if selectionMode {
                    Section {
                        HStack {
                            Button("全选结果") { selectedIDs = Set(filteredRecords.map(\.id)) }
                            Spacer()
                            Button("取消选择") { selectedIDs.removeAll() }
                            Spacer()
                            Button("删除\(selectedIDs.count)条", role: .destructive) { showDeleteSelected = true }.disabled(selectedIDs.isEmpty)
                        }.font(.subheadline)
                    }
                }
                if store.records.isEmpty {
                    Section {
                        VStack(spacing: 12) {
                            Image(systemName: "clock.arrow.circlepath").font(.system(size: 40)).foregroundStyle(.secondary)
                            Text("暂无记录").font(.headline).foregroundStyle(.secondary)
                        }.frame(maxWidth: .infinity).padding(.vertical, 60).listRowBackground(Color.clear)
                    }
                } else {
                    ForEach(groupedRecords, id: \.year) { group in
                        let stats = yearStats(group.records)
                        Section(header: HStack {
                            Text("\(group.year)年").font(.headline)
                            Spacer()
                            Text("\(stats.count)次 · \(stats.minutes)分").font(.caption).foregroundStyle(.secondary)
                        }) {
                            ForEach(group.records) { record in
                                Button {
                                    if selectionMode {
                                        if selectedIDs.contains(record.id) { selectedIDs.remove(record.id) }
                                        else { selectedIDs.insert(record.id) }
                                    } else { selectedRecord = record }
                                } label: {
                                    HStack {
                                        if selectionMode {
                                            Image(systemName: selectedIDs.contains(record.id) ? "checkmark.circle.fill" : "circle")
                                                .foregroundStyle(.blue)
                                        }
                                        recordContent(record)
                                    }
                                }
                                .buttonStyle(.plain)
                                .swipeActions(edge: .trailing, allowsFullSwipe: !selectionMode) {
                                    if !selectionMode {
                                        Button(role: .destructive) { store.delete(record) } label: { Label("删除", systemImage: "trash") }
                                    }
                                }

                            }
                        }
                    }
                }
            }.proGroupedRows()
            .searchable(text: $searchText, prompt: "搜索日期或备注")
            .navigationTitle("历史记录").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItemGroup(placement: .topBarLeading) { Button("返回") { dismiss() } }
                ToolbarItemGroup(placement: .topBarTrailing) {
                    if !store.records.isEmpty {
                        Button { showAdd = true } label: { Image(systemName: "plus") }
                        Button(selectionMode ? "完成" : "多选") {
                            selectionMode.toggle()
                            if !selectionMode { selectedIDs.removeAll() }
                        }
                        Button { showClearConfirm = true } label: { Image(systemName: "trash") }
                    }
                }
            }
.sheet(isPresented: $showRanking) {
                NavigationStack {
                    List(Array(store.records.sorted { ($0.duration ?? 0) > ($1.duration ?? 0) }.prefix(10).enumerated()), id: \.element.id) { index, record in
                        HStack {
                            Text("\(index + 1)").font(.headline).frame(width: 30)
                            VStack(alignment: .leading) {
                                Text(record.dateText)
                                Text(record.note.isEmpty ? "无备注" : record.note).font(.caption).foregroundStyle(.secondary)
                            }
                            Spacer()
                            Text(record.durationText).foregroundStyle(.blue)
                        }
                    }.navigationTitle("最长10次记录")
                        .toolbar { Button("关闭") { showRanking = false } }
                }
            }
            .alert("删除选中记录？", isPresented: $showDeleteSelected) {
                Button("取消", role: .cancel) {}
                Button("确认删除", role: .destructive) {
                    store.deleteRecords(ids: selectedIDs)
                    selectedIDs.removeAll()
                    selectionMode = false
                }
            } message: { Text("将永久删除选中的\(selectedIDs.count)条记录，请先确认已备份。") }
.sheet(isPresented: $showAdd) {
                AddHistoryRecordView(store: store)
            }
            .alert("确认清空", isPresented: $showClearConfirm) {
                Button("取消", role: .cancel) {}
                Button("清空全部", role: .destructive) {
                    store.clearAll()
                }
            } message: {
                Text("将删除全部\(store.records.count)条怠速记录，此操作不可恢复。")
            }
            .sheet(item: $selectedRecord) { record in
                RecordDetailView(store: store, record: record) {
                    store.delete(record); selectedRecord = nil
                }
            }
        }
    }
}

// MARK: - 设置页

private enum HistoryRange: String, CaseIterable, Identifiable {
    case all = "全部", week = "近7天", month = "近1月", year = "近1年"
    var id: String { rawValue }
}
