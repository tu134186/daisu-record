import Foundation
import UserNotifications

private struct CarIdleBackup: Codable {
    let version: Int
    let savedAt: Date
    let records: [IdleRecord]
    let currentRecord: IdleRecord?
    let maintenanceRecords: [MaintenanceRecord]
    let vehicleRegistrationDate: Date?
    let countdownMinutes: Int
    let reminderEnabled: Bool
    let reminderIntervalDays: Int
}


struct BackupImportResult {
    let valid: Bool
    let backupCount: Int
    let addedCount: Int
    let skippedCount: Int
    let totalCount: Int
    let persisted: Bool
}

class IdleStore: ObservableObject {
    @Published var records: [IdleRecord] = []
    @Published var currentRecord: IdleRecord?
    @Published var maintenanceRecords: [MaintenanceRecord] = []
    @Published var vehicleRegistrationDate: Date? {
        didSet {
            if let date = vehicleRegistrationDate {
                defaults.set(date, forKey: vehicleKey)
            } else {
                defaults.removeObject(forKey: vehicleKey)
            }
        }
    }

    @Published var countdownMinutes: Int {
        didSet { defaults.set(countdownMinutes, forKey: "countdownMinutes") }
    }
    @Published var reminderEnabled: Bool {
        didSet {
            defaults.set(reminderEnabled, forKey: "reminderEnabled")
            if reminderEnabled { scheduleReminder() } else { cancelReminder() }
        }
    }
    @Published var reminderIntervalDays: Int {
        didSet {
            defaults.set(reminderIntervalDays, forKey: "reminderIntervalDays")
            if reminderEnabled { scheduleReminder() }
        }
    }

    private let defaults = UserDefaults.standard
    private let recordsKey = "idleRecords"
    private let currentKey = "currentIdleRecord"
    private let maintenanceKey = "maintenanceRecords"
    private let oldBatteryKey = "batteryRecords"
    private let vehicleKey = "vehicleRegistrationDate"

    var isRunning: Bool { currentRecord != nil }

    init() {
        self.countdownMinutes = defaults.object(forKey: "countdownMinutes") as? Int ?? 30
        self.reminderEnabled = defaults.bool(forKey: "reminderEnabled")
        self.reminderIntervalDays = defaults.object(forKey: "reminderIntervalDays") as? Int ?? 7
        load()
        // V2.0.2 数据修复：随包历史快照现为 135 条（补回 2026-08-25、2026-09-01）。
        // 升级用户即使已有 133 条，也执行一次“去重合并”，只补缺失记录；
        // 之后不再反复导入，避免用户手动删除记录后又被自动加回来。
        let bundledHistoryMergeKey = "bundledHistoryMerged_v2_0_2"
        if !defaults.bool(forKey: bundledHistoryMergeKey) {
            _ = importHistory()
            defaults.set(true, forKey: bundledHistoryMergeKey)
        }
        migrateBatteryToMaintenance()
        requestNotificationPermission()
    }


    func load() {
        if let data = defaults.data(forKey: recordsKey),
           let decoded = try? JSONDecoder().decode([IdleRecord].self, from: data) {
            records = decoded
        }
        if let data = defaults.data(forKey: currentKey),
           let decoded = try? JSONDecoder().decode(IdleRecord.self, from: data) {
            currentRecord = decoded
        }
        if let data = defaults.data(forKey: maintenanceKey),
           let decoded = try? JSONDecoder().decode([MaintenanceRecord].self, from: data) {
            maintenanceRecords = decoded
        }
        vehicleRegistrationDate = defaults.object(forKey: vehicleKey) as? Date
    }

    func save() {
        if let data = try? JSONEncoder().encode(records) {
            defaults.set(data, forKey: recordsKey)
        }
        if let current = currentRecord,
           let data = try? JSONEncoder().encode(current) {
            defaults.set(data, forKey: currentKey)
        } else {
            defaults.removeObject(forKey: currentKey)
        }
        saveMaintenance()
    }

    private func saveMaintenance() {
        if let data = try? JSONEncoder().encode(maintenanceRecords) {
            defaults.set(data, forKey: maintenanceKey)
        }
    }

    /// 从旧版电池记录迁移到通用保养记录
    private func migrateBatteryToMaintenance() {
        guard let data = defaults.data(forKey: oldBatteryKey),
              let oldRecords = try? JSONDecoder().decode([BatteryRecordLegacy].self, from: data),
              !oldRecords.isEmpty else { return }
        for old in oldRecords {
            let record = MaintenanceRecord(
                type: .battery,
                date: old.changeDate,
                intervalDays: MaintenanceType.battery.defaultIntervalDays,
                note: old.note
            )
            if !maintenanceRecords.contains(where: { $0.date == record.date && $0.type == .battery }) {
                maintenanceRecords.append(record)
            }
        }
        maintenanceRecords.sort { $0.date > $1.date }
        saveMaintenance()
        defaults.removeObject(forKey: oldBatteryKey)
    }

    func start() {
        currentRecord = IdleRecord(startTime: Date(), endTime: nil)
        cancelReminder()
        save()
    }

    func stop() {
        guard var record = currentRecord else { return }
        record.endTime = Date()
        records.insert(record, at: 0)
        currentRecord = nil
        save()
        if reminderEnabled { scheduleReminder() }
    }

    func cancelCurrent() {
        currentRecord = nil
        save()
    }

    func updateNote(_ record: IdleRecord, note: String) {
        if let index = records.firstIndex(where: { $0.id == record.id }) {
            records[index].note = note
            save()
        }
    }

    func delete(at offsets: IndexSet) {
        records.remove(atOffsets: offsets)
        save()
    }

    func delete(_ record: IdleRecord) {
        records.removeAll { $0.id == record.id }
        save()
    }

    func clearAll() {
        records.removeAll()
        save()
    }

    func importHistory() -> Int {
        guard let url = Bundle.main.url(forResource: "history_records", withExtension: "json"),
              let data = try? Data(contentsOf: url),
              let jsonArray = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]] else {
            return 0
        }
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.calendar = Calendar(identifier: .gregorian)
        formatter.dateFormat = "yyyy-MM-dd HH:mm"
        var imported = 0
        for item in jsonArray {
            guard let startStr = item["startTime"] as? String,
                  let endStr = item["endTime"] as? String,
                  let start = formatter.date(from: startStr),
                  let end = formatter.date(from: endStr) else { continue }
            let note = item["note"] as? String ?? ""
            let record = IdleRecord(startTime: start, endTime: end, note: note)
            if !records.contains(where: {
                $0.startTime == record.startTime && $0.endTime == record.endTime
            }) {
                records.append(record)
                imported += 1
            }
        }
        records.sort { $0.startTime > $1.startTime }
        save()
        return imported
    }

    // MARK: - 怠速统计
    var totalCount: Int { records.count }

    var totalDuration: TimeInterval {
        records.reduce(0) { $0 + ($1.duration ?? 0) }
    }

    var totalDurationText: String {
        let total = Int(totalDuration)
        let hours = total / 3600
        let minutes = (total % 3600) / 60
        if hours == 0 { return "\(minutes)分钟" }
        return "\(hours)小时\(minutes)分"
    }

    var avgDurationText: String {
        guard records.count > 0 else { return "0分钟" }
        let avg = Int(totalDuration) / records.count
        let minutes = avg / 60
        let seconds = avg % 60
        if minutes == 0 { return "\(seconds)秒" }
        return "\(minutes)分\(seconds)秒"
    }

    var daysSinceLast: Double {
        guard let last = records.first else { return 0 }
        return Date().timeIntervalSince(last.startTime) / 86400
    }

    var avgIntervalDays: Double {
        guard records.count >= 2 else { return 0 }
        var intervals: [Double] = []
        for i in 0..<(records.count - 1) {
            let interval = records[i].startTime.timeIntervalSince(records[i + 1].startTime) / 86400
            intervals.append(interval)
        }
        return intervals.reduce(0, +) / Double(intervals.count)
    }

    func intervalDays(for record: IdleRecord) -> Int? {
        guard let index = records.firstIndex(where: { $0.id == record.id }),
              index + 1 < records.count else { return nil }
        let next = records[index + 1]
        return Int(record.startTime.timeIntervalSince(next.startTime) / 86400)
    }

    // MARK: - 保养管理
    /// 获取某类型最新一条保养记录
    func latestMaintenance(for type: MaintenanceType) -> MaintenanceRecord? {
        maintenanceRecords.filter { $0.type == type }.max(by: { $0.date < $1.date })
    }

    /// 所有需要关注的保养项目（即将到期+已超期），按紧急程度排序
    var upcomingMaintenance: [MaintenanceRecord] {
        let latest = Dictionary(grouping: maintenanceRecords, by: { $0.type })
            .compactMap { $0.value.max(by: { $0.date < $1.date }) }
        return latest
            .filter { $0.statusLevel >= 1 }
            .sorted { $0.daysRemaining < $1.daysRemaining }
    }

    /// 所有保养类型的最新状态
    var allMaintenanceStatus: [MaintenanceRecord] {
        Dictionary(grouping: maintenanceRecords, by: { $0.type })
            .compactMap { $0.value.max(by: { $0.date < $1.date }) }
            .sorted { $0.type.rawValue < $1.type.rawValue }
    }

    func addMaintenanceRecord(type: MaintenanceType, customName: String = "", date: Date, intervalDays: Int, note: String = "") {
        let record = MaintenanceRecord(type: type, customName: customName, date: date, intervalDays: intervalDays, note: note)
        maintenanceRecords.append(record)
        maintenanceRecords.sort { $0.date > $1.date }
        save()
    }

    func updateMaintenanceNote(_ record: MaintenanceRecord, note: String) {
        if let index = maintenanceRecords.firstIndex(where: { $0.id == record.id }) {
            maintenanceRecords[index].note = note
            save()
        }
    }

    func updateMaintenanceInterval(_ record: MaintenanceRecord, intervalDays: Int) {
        if let index = maintenanceRecords.firstIndex(where: { $0.id == record.id }) {
            maintenanceRecords[index].intervalDays = intervalDays
            save()
        }
    }

    func deleteMaintenanceRecord(_ record: MaintenanceRecord) {
        maintenanceRecords.removeAll { $0.id == record.id }
        save()
    }

    /// 某类型的历史记录
    func maintenanceHistory(for type: MaintenanceType) -> [MaintenanceRecord] {
        maintenanceRecords.filter { $0.type == type }.sorted { $0.date > $1.date }
    }

    // MARK: - 年检计算
    /// 计算下次年检时间和类型
    var nextInspection: InspectionResult? {
        guard let regDate = vehicleRegistrationDate else { return nil }
        let calendar = Calendar.current
        let now = Date()

        // 第2、4、8年：手机申领；第6、10年：上线检测
        let mobileYears: Set<Int> = [2, 4, 8]
        let onlineYears: Set<Int> = [6, 10]

        // 检查2-10年的固定年检点
        for year in 2...10 {
            if let date = calendar.date(byAdding: .year, value: year, to: regDate) {
                if date > now {
                    let type: InspectionType = mobileYears.contains(year) ? .mobile : .online
                    return InspectionResult(date: date, type: type, yearsSinceRegistration: year)
                }
            }
        }

        // 超过10年，每年上线检测
        let yearsSince = calendar.dateComponents([.year], from: regDate, to: now).year ?? 10
        let nextYear = max(11, yearsSince + 1)
        if let date = calendar.date(byAdding: .year, value: nextYear, to: regDate) {
            return InspectionResult(date: date, type: .online, yearsSinceRegistration: nextYear)
        }

        return nil
    }

    /// 距下次年检天数
    var daysUntilInspection: Int? {
        guard let next = nextInspection else { return nil }
        return Int(next.date.timeIntervalSinceNow / 86400)
    }

    /// 年检是否即将到期（90天内）或已超期
    var inspectionStatusLevel: Int {
        guard let days = daysUntilInspection else { return 0 }
        if days <= 0 { return 2 }
        if days <= 90 { return 1 }
        return 0
    }

    /// 标记本次年检已完成，自动记录
    func markInspectionDone() {
        guard let next = nextInspection else { return }
        addMaintenanceRecord(
            type: .inspection,
            date: Date(),
            intervalDays: next.yearsSinceRegistration * 365,
            note: next.type.title
        )
    }

    // MARK: - 报表查询
    func dateRange(for period: ReportPeriod, anchor date: Date) -> (start: Date, end: Date) {
        let calendar = Calendar.current
        switch period {
        case .week:
            var components = calendar.dateComponents([.yearForWeekOfYear, .weekOfYear], from: date)
            components.weekday = 2
            let start = calendar.date(from: components) ?? date
            let end = calendar.date(byAdding: .day, value: 7, to: start) ?? date
            return (start, end)
        case .month:
            let start = calendar.date(from: calendar.dateComponents([.year, .month], from: date)) ?? date
            let end = calendar.date(byAdding: .month, value: 1, to: start) ?? date
            return (start, end)
        case .year:
            let start = calendar.date(from: calendar.dateComponents([.year], from: date)) ?? date
            let end = calendar.date(byAdding: .year, value: 1, to: start) ?? date
            return (start, end)
        }
    }

    func records(in period: ReportPeriod, anchor date: Date) -> [IdleRecord] {
        let range = dateRange(for: period, anchor: date)
        return records.filter {
            $0.startTime >= range.start && $0.startTime < range.end
        }.sorted { $0.startTime > $1.startTime }
    }

    func periodTitle(for period: ReportPeriod, anchor date: Date) -> String {
        let formatter = DateFormatter()
        switch period {
        case .week:
            let range = dateRange(for: period, anchor: date)
            formatter.dateFormat = "M月d日"
            return "\(formatter.string(from: range.start)) - \(formatter.string(from: range.end.addingTimeInterval(-86400)))"
        case .month:
            formatter.dateFormat = "yyyy年M月"
            return formatter.string(from: date)
        case .year:
            formatter.dateFormat = "yyyy年"
            return formatter.string(from: date)
        }
    }

    func shiftPeriod(_ period: ReportPeriod, anchor date: Date, by value: Int) -> Date {
        let calendar = Calendar.current
        return calendar.date(byAdding: period.calendarComponent, value: value, to: date) ?? date
    }

    // MARK: - 数据防丢 / iCloud 完整备份
    private func makeBackup() -> CarIdleBackup {
        CarIdleBackup(
            version: 1,
            savedAt: Date(),
            records: records,
            currentRecord: currentRecord,
            maintenanceRecords: maintenanceRecords,
            vehicleRegistrationDate: vehicleRegistrationDate,
            countdownMinutes: countdownMinutes,
            reminderEnabled: reminderEnabled,
            reminderIntervalDays: reminderIntervalDays
        )
    }

    func fullBackupJSON() -> String? {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        encoder.dateEncodingStrategy = .iso8601
        guard let data = try? encoder.encode(makeBackup()) else { return nil }
        return String(data: data, encoding: .utf8)
    }

    func fullBackupFileURL() -> URL? {
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        encoder.dateEncodingStrategy = .iso8601
        guard let data = try? encoder.encode(makeBackup()), !data.isEmpty else { return nil }

        let fm = FileManager.default
        let folder = fm.temporaryDirectory.appendingPathComponent("CarIdleBackups", isDirectory: true)
        do {
            try fm.createDirectory(at: folder, withIntermediateDirectories: true)
            let f = DateFormatter()
            f.locale = Locale(identifier: "en_US_POSIX")
            f.dateFormat = "yyyyMMdd-HHmmss"
            let url = folder.appendingPathComponent("怠速记录完整备份-\(f.string(from: Date())).json")
            try data.write(to: url, options: .atomic)
            let attrs = try fm.attributesOfItem(atPath: url.path)
            let size = (attrs[.size] as? NSNumber)?.intValue ?? 0
            guard size > 0 else {
                try? fm.removeItem(at: url)
                return nil
            }
            return url
        } catch {
            return nil
        }
    }

    func backupFileInfo(_ url: URL) -> String {
        let attrs = try? FileManager.default.attributesOfItem(atPath: url.path)
        let size = (attrs?[.size] as? NSNumber)?.intValue ?? 0
        let kb = max(1, Int(ceil(Double(size) / 1024.0)))
        let f = DateFormatter()
        f.dateFormat = "M月d日 HH:mm"
        return "\(records.count)条记录 · \(kb) KB · \(f.string(from: Date()))"
    }

    @discardableResult
    func importFullBackup(_ text: String) -> Int {
        importFullBackupDetailed(text).addedCount
    }

    func importFullBackupDetailed(_ text: String) -> BackupImportResult {
        guard let data = text.data(using: .utf8), !data.isEmpty else {
            return BackupImportResult(valid: false, backupCount: 0, addedCount: 0, skippedCount: 0, totalCount: records.count, persisted: false)
        }
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        guard let backup = try? decoder.decode(CarIdleBackup.self, from: data) else {
            return BackupImportResult(valid: false, backupCount: 0, addedCount: 0, skippedCount: 0, totalCount: records.count, persisted: false)
        }

        let backupCount = backup.records.count
        var added = 0
        for r in backup.records where !records.contains(where: { $0.startTime == r.startTime && $0.endTime == r.endTime }) {
            records.append(r)
            added += 1
        }
        for m in backup.maintenanceRecords where !maintenanceRecords.contains(where: { $0.id == m.id }) {
            maintenanceRecords.append(m)
        }
        if vehicleRegistrationDate == nil { vehicleRegistrationDate = backup.vehicleRegistrationDate }
        records.sort { $0.startTime > $1.startTime }
        maintenanceRecords.sort { $0.date > $1.date }
        save()

        let persistedCount: Int
        if let savedData = defaults.data(forKey: recordsKey),
           let savedRecords = try? JSONDecoder().decode([IdleRecord].self, from: savedData) {
            persistedCount = savedRecords.count
        } else {
            persistedCount = -1
        }
        let skipped = max(0, backupCount - added)
        return BackupImportResult(
            valid: true,
            backupCount: backupCount,
            addedCount: added,
            skippedCount: skipped,
            totalCount: records.count,
            persisted: persistedCount == records.count
        )
    }

    // MARK: - Export
    func exportJSON() -> String? {
        let exportData: [String: Any] = [
            "exportDate": ISO8601DateFormatter().string(from: Date()),
            "totalCount": totalCount,
            "totalDuration": totalDurationText,
            "records": records.map { record -> [String: Any] in
                var dict: [String: Any] = [
                    "date": record.dateText,
                    "startTime": record.startTimeText,
                    "endTime": record.endTimeText,
                    "duration": record.durationText
                ]
                if !record.note.isEmpty { dict["note"] = record.note }
                if let interval = intervalDays(for: record) { dict["intervalDays"] = interval }
                return dict
            }
        ]
        if let jsonData = try? JSONSerialization.data(withJSONObject: exportData, options: .prettyPrinted),
           let jsonString = String(data: jsonData, encoding: .utf8) {
            return jsonString
        }
        return nil
    }

    // MARK: - CSV 导出
    func exportCSV() -> String? {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd HH:mm"
        var csv = "日期,启动时间,熄火时间,时长,备注\n"
        for record in records {
            let date = record.dateText
            let start = formatter.string(from: record.startTime)
            let end = record.endTime.map { formatter.string(from: $0) } ?? ""
            let duration = record.durationText
            let note = record.note.replacingOccurrences(of: ",", with: "，")
            csv += "\(date),\(start),\(end),\(duration),\(note)\n"
        }
        return csv
    }

    // MARK: - 从 JSON 字符串导入（自动去重）
    func importRecords(fromJSON jsonString: String) -> Int {
        guard let data = jsonString.data(using: .utf8),
              let jsonObject = try? JSONSerialization.jsonObject(with: data) else { return 0 }
        let recordsArray: [[String: Any]]
        if let dict = jsonObject as? [String: Any], let arr = dict["records"] as? [[String: Any]] {
            recordsArray = arr
        } else if let arr = jsonObject as? [[String: Any]] {
            recordsArray = arr
        } else {
            return 0
        }
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd HH:mm"
        var imported = 0
        for item in recordsArray {
            guard let startStr = (item["startTime"] as? String) ?? (item["start"] as? String),
                  let start = formatter.date(from: startStr) else { continue }
            let endStr = (item["endTime"] as? String) ?? (item["end"] as? String)
            let end = endStr.flatMap { formatter.date(from: $0) }
            let note = item["note"] as? String ?? ""
            let record = IdleRecord(startTime: start, endTime: end, note: note)
            if !records.contains(where: { $0.startTime == record.startTime && $0.endTime == record.endTime }) {
                records.append(record)
                imported += 1
            }
        }
        records.sort { $0.startTime > $1.startTime }
        save()
        return imported
    }

    // MARK: - 从 CSV 字符串导入（自动去重）
    func importRecords(fromCSV csvString: String) -> Int {
        let lines = csvString.components(separatedBy: .newlines).filter { !$0.isEmpty }
        guard lines.count > 1 else { return 0 }
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd HH:mm"
        var imported = 0
        for line in lines.dropFirst() {
            let columns = line.components(separatedBy: ",")
            guard columns.count > 1, let start = formatter.date(from: columns[1]) else { continue }
            let end = columns.count > 2 ? formatter.date(from: columns[2]) : nil
            let note = columns.count > 4 ? columns[4] : ""
            let record = IdleRecord(startTime: start, endTime: end, note: note)
            if !records.contains(where: { $0.startTime == record.startTime && $0.endTime == record.endTime }) {
                records.append(record)
                imported += 1
            }
        }
        records.sort { $0.startTime > $1.startTime }
        save()
        return imported
    }

    // MARK: - Notifications
    private func requestNotificationPermission() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { _, _ in }
    }

    private func scheduleReminder() {
        cancelReminder()
        guard reminderEnabled else { return }
        let content = UNMutableNotificationContent()
        content.title = "该启动车了"
        content.body = "车辆已闲置\(reminderIntervalDays)天，建议启动发动机充电"
        content.sound = .default
        let triggerDate = Date().addingTimeInterval(TimeInterval(reminderIntervalDays) * 86400)
        let components = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute], from: triggerDate)
        let trigger = UNCalendarNotificationTrigger(dateMatching: components, repeats: false)
        let request = UNNotificationRequest(identifier: "carIdleReminder", content: content, trigger: trigger)
        UNUserNotificationCenter.current().add(request)
    }

    private func cancelReminder() {
        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: ["carIdleReminder"])
    }
}

// MARK: - 旧版电池记录（用于迁移）
private struct BatteryRecordLegacy: Identifiable, Codable {
    var id = UUID()
    var changeDate: Date
    var note: String = ""
}
