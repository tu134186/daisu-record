import SwiftUI
import UIKit
import Charts
import UniformTypeIdentifiers

struct VersionHistoryView: View {
    @Environment(\.dismiss) private var dismiss

    struct VersionLog: Identifiable {
        let id = UUID()
        let version: String
        let date: String
        let changes: [String]
    }

    private let logs: [VersionLog] = [
        VersionLog(version: "v2.2.22", date: "2026年9月2日", changes: [
            "根据真机结果继续追查：安装后 Widget 空白，但注销 SpringBoard 后立即正常显示",
            "发现 V2.2.21 虽然 App.swift 已撤销 WidgetCenter 操作，但 Store.swift 的 syncWidgetSnapshot() 末尾仍残留 reloadTimelines(ofKind:)；而 IdleStore 初始化时必定调用 syncWidgetSnapshot()，所以打开 App 仍会主动刷新 Widget",
            "本版删除 Store.swift 对 WidgetKit 的导入和残留 reloadTimelines 调用；共享摘要仍可写入，但主 App 不再主动要求 WidgetKit 丢弃/重取时间线",
            "因此 V2.2.22 才是真正的零 WidgetCenter 被动注册 A/B 测试版；固定 kind、单 Extension、静态 Widget、Bundle ID 均保持不变",
            "主 App 与 Widget 同步为 2.2.22 / build 52，并把本次漏查原因、成功/失败验证和下一步判断写入源码包文档"
        ]),
        VersionLog(version: "v2.2.21", date: "2026年9月2日", changes: [
            "真机确认 v2.2.20 覆盖安装后会立刻把桌面 Widget 变为空白，说明主动 reload 在 Extension 尚未重新注册完成时反而会清掉原可见快照",
            "撤销主 App 启动/回前台的 WidgetCenter.reloadAllTimelines、getCurrentConfigurations 和 reloadTimelines 调用",
            "Widget Timeline 恢复已验证基线的 .never，避免安装阶段额外触发时间线重取",
            "继续固定 kind = CarIdleMediumWidget、单一 Widget Extension、Bundle ID 和最小静态 Widget 结构，不更换身份、不加第二 Extension",
            "本版目标是回到 v2.2.14/v2.2.19 的被动注册路径，验证覆盖安装时是否能由系统自行切换；若仍需注销，则把它归为 TrollStore/系统扩展重载限制，不再用主动 reload 硬顶",
            "主 App 与 Widget 同步为 2.2.21 / build 51，并同步开发日志、失败方案和下一版建议"
        ]),
        VersionLog(version: "v2.2.20", date: "2026年9月2日", changes: [
            "针对真机最新结果继续处理：V2.2.19 安装后 Widget 首次空白，但注销 SpringBoard 后能够正常显示，说明 Extension 和静态界面本身可运行，问题集中在安装后的首次登记/唤醒阶段",
            "主 App 首次启动以及重新回到前台时，使用 Apple 公开 WidgetCenter API 主动连接当前 Widget 配置，并对固定 kind CarIdleMediumWidget 请求刷新；不再使用历史失败的 0.8 秒/2.5 秒延迟循环",
            "Widget Timeline 从永久 .never 调整为 5 分钟后的 .after，给系统在首次安装注册稍慢时一次后续重取时间线机会，同时保持静态诊断界面不引入业务数据变量",
            "继续保持单一 Widget Extension、固定 kind、Bundle ID 和现有数据结构不变；本版目标是尽量实现安装后打开一次 App 即可唤醒 Widget，但不把公开 WidgetKit API 描述成能够强制替代 TrollStore/系统的 Extension 注册",
            "主 App 与 Widget 同步为 2.2.20 / build 50，并同步源码开发日志、真机验证记录和关于页历史更新"
        ]),
        VersionLog(version: "v2.2.19", date: "2026年9月2日", changes: [
            "将 V2.2.18 真机结果正式固化为 TrollStore Widget 更新基线：覆盖安装后旧组件可能暂时仍显示旧版本，注销 SpringBoard 后会切换到新版本",
            "停止继续尝试用 reloadTimelines、延迟刷新、修改 Widget kind 或增加第二 Extension 强行模拟 App Store 的更新生命周期，避免重复无效补丁",
            "主 App、Widget Extension、工程版本和可见测试文字统一同步为 2.2.19 / build 49，Widget kind 继续永久固定为 CarIdleMediumWidget",
            "源码包新增/整理 AI 接手开发说明与 TrollStore Widget 验证记录，明确成功案例、失败方案、高风险区域和以后测试标准",
            "设置 → 关于继续保持简洁，只显示当前版本和历史更新入口；完整历史在本页面统一查看"
        ]),
        VersionLog(version: "v2.2.18", date: "2026年9月2日", changes: [
            "真机关键验证：覆盖安装 V2.2.18 后，桌面 Widget 起初仍显示 V2.2.12；注销 SpringBoard 后立即正确显示 V2.2.18",
            "该结果证明 V2.2.18 包内 Widget Extension 和版本号已经更新成功，旧版本显示并非源码仍是 2212，而是系统仍在使用旧 Extension/快照状态",
            "由此确定 TrollStore 覆盖安装后的 Widget 重新加载行为不能按 App Store 更新流程做 100% 等价保证",
            "后续不再把“必须无需注销立即刷新”作为强制修复目标；稳定方案为覆盖安装后如组件仍停留旧版，注销 SpringBoard 一次",
            "保留固定 Widget kind、单一 Extension 和最小静态 Widget 基线，不再为了清缓存随版本更换 kind"
        ]),
        VersionLog(version: "v2.2.17", date: "2026年9月2日", changes: [
            "直接从真机成功的 V2.2.14 源码包完整克隆，不继承 V2.2.15/V2.2.16 的任何 Widget 修改",
            "只把主 App 与 Widget 版本同步为 2.2.17 / build 47，并把 Widget 可见文字改为 WIDGET V2.2.17",
            "Widget Provider、StaticConfiguration、固定 kind、Extension 结构全部保持 V2.2.14 成功基线不变，用于排除后续版本包本身的回归",
            "本版特意不修 Shared/WidgetSnapshot.swift 中 V2.2.14 已存在但当前未使用的旧 widgetKind 常量，避免额外变量干扰 A/B 验证",
            "关于页仍只显示当前版本和历史更新入口，完整版本记录继续在独立页面查看"
        ]),
        VersionLog(version: "v2.2.14", date: "2026年9月2日", changes: [
            "停止继续给 WidgetKit 加延迟刷新、定时刷新等补丁，改为检查标准 Widget Extension 打包/注册结构",
            "修正前几版诊断中的关键问题：Widget kind 不再跟版本号变化，固定为 CarIdleMediumWidget；以后升级禁止更换 kind，避免桌面上已添加的小组件继续绑定旧配置",
            "主 App 删除启动后 0.8 秒/2.5 秒强制 reloadTimelines 代码，恢复标准 App 启动流程，排除无效刷新干扰",
            "Widget 保持最小静态白底黑字，只用于验证 TrollStore 覆盖安装后 Extension 是否真正切换到 V2.2.14",
            "加强最终 IPA 检查脚本：同时核对主 App/Widget 的版本、Bundle ID、NSExtension、可执行文件、签名和 entitlements，避免只看源码判断"
        ]),
        VersionLog(version: "v2.2.13", date: "2026年9月2日", changes: [
            "关于页恢复简洁布局：只显示当前版本和“历史更新”入口，不再把所有版本直接展开占满设置页",
            "点击“历史更新”弹出独立全屏更新日志，所有版本继续按新到旧排列，并保留每版详细更新内容",
            "Widget 进行下一轮首次显示验证：使用新的唯一 kind，避免上一轮注销后留下的旧快照/缓存影响测试结论",
            "主 App 启动后对当前 Widget kind 做两次轻量刷新请求；Widget 时间线改为定时刷新，不重新加入 App Group 或业务数据，继续保持静态诊断基线"
        ]),
        VersionLog(version: "v2.2.12", date: "2026年9月2日", changes: [
            "设置 → 关于重新整合版本展示：顶部只显示当前版本，下面直接连续显示历史更新记录",
            "补齐 V2.2.x 后续迭代记录并与旧版本历史按新到旧排列，不再只显示少量摘要",
            "真机确认 Widget 安装并添加后首次可能不立即显示，但注销 SpringBoard 后可以正常出现；该现象记录为后续首次刷新问题",
            "本版只整理关于页、版本历史和版本同步，不改已能在注销后显示的 Widget 核心渲染架构"
        ]),
        VersionLog(version: "v2.2.11", date: "2026年9月2日", changes: [
            "重新整理源码包开发说明，明确稳定基线、高风险区域、版本同步、打包和 Widget 排查规则",
            "设置 → 关于的版本号下方直接加入历史版本更新记录，不再必须进入二级页面才能看到",
            "完整更新日志继续保留独立页面，补齐 V2.1.0 至 V2.2.10 的迭代历史",
            "不改当前 Widget 单 Extension 诊断架构，避免为了文档/UI调整引入新的小组件变量"
        ]),
        VersionLog(version: "v2.2.10", date: "2026年9月2日", changes: [
            "工程只保留一个 CarIdleWidget Extension 和一份 Widget 源码",
            "唯一 Widget kind 统一为 CarIdleMediumWidgetV2210Single，主 App 刷新路径同步",
            "Widget 保持静态白底黑字诊断，排除旧版本残留冲突"
        ]),
        VersionLog(version: "v2.2.9", date: "2026年9月2日", changes: [
            "Widget 缩为固定白底黑字三行文字，不依赖 App Group、UserDefaults、SF Symbol 或动态日期",
            "使用全新 kind 规避旧 WidgetKit 快照缓存",
            "若仍空白，排查重点转向最终 IPA 的 appex 注册、签名和最低系统版本"
        ]),
        VersionLog(version: "v2.2.8", date: "2026年9月2日", changes: [
            "Widget Extension 完全断开 Shared 与 App Group，只保留 SwiftUI + WidgetKit",
            "改为单 @main Widget 和全新 kind，隔离扩展进程启动问题"
        ]),
        VersionLog(version: "v2.2.5", date: "2026年9月2日", changes: [
            "针对小组件有占位阴影但内容空白进行专项诊断",
            "预览不访问共享容器，共享数据未连接时也强制绘制固定提示",
            "降低 iOS 16 WidgetKit 渲染变量"
        ]),
        VersionLog(version: "v2.2.4", date: "2026年9月2日", changes: [
            "修复 CarIdleWidgetEntry 初始化漏传 sharedDataConnected 导致的编译失败",
            "仅补齐构造参数，不改变 Widget 稳定架构"
        ]),
        VersionLog(version: "v2.2.3", date: "2026年9月2日", changes: [
            "回退到 V2.2.0 可显示架构，移除跨沙盒扫描、私有权限和额外重签方案",
            "共享数据不可用时显示明确诊断文字"
        ]),
        VersionLog(version: "v2.2.0", date: "2026年9月2日", changes: [
            "新增唯一中号桌面小组件",
            "主 App 与 Widget 使用 group.com.trollbox.caridle 共享摘要数据",
            "历史记录继续保留在原 UserDefaults.standard，不进行破坏性迁移"
        ]),
        VersionLog(version: "v2.1.0", date: "2026年9月1日", changes: [
            "精修首页车辆状态、闲置时长、启动建议和保养提醒的信息层级",
            "移除重复设置入口并压缩首屏间距",
            "不修改已有数据键和解码格式"
        ]),
        VersionLog(version: "v2.0.0", date: "2026年9月1日", changes: [
            "首页重新设计为车辆状态中心，突出启动/熄火核心操作",
            "重新整理统计、启动建议、保养提醒、常用功能和最近记录的信息层级",
            "将原本集中在单个 ContentView.swift 的页面拆分为独立 Swift 文件，降低后续修改互相影响的风险",
            "保留现有 UserDefaults 数据键和历史 JSON 格式，升级不主动清空旧数据",
            "版本显示改为读取 App Bundle，减少版本号不同步"
        ]),
        VersionLog(version: "v1.10.4", date: "2026年8月24日", changes: [
            "设置页数据管理移除导入内置历史数据按钮（数据已存在，保留history_records.json文件）"
        ]),
        VersionLog(version: "v1.10.3", date: "2026年8月24日", changes: [
            "快捷功能移除导出备份和导入数据按钮，统一整合到设置页数据管理"
        ]),
        VersionLog(version: "v1.10.2", date: "2026年8月24日", changes: [
            "设置页数据管理新增导出备份入口，导出/导入/清空功能整合到一处"
        ]),
        VersionLog(version: "v1.10.1", date: "2026年8月24日", changes: [
            "导出备份不再弹出文本页面，点按钮直接选择格式后调起系统分享面板"
        ]),
        VersionLog(version: "v1.10.0", date: "2026年8月24日", changes: [
            "导出备份支持JSON和CSV表格两种格式，顶部切换",
            "新增从文件导入功能，支持JSON和CSV格式，自动去重（相同启动+熄火时间不重复导入）",
            "历史记录页右上角新增清空全部按钮（带确认弹窗）",
            "设置页数据管理新增清空全部怠速记录功能"
        ]),
        VersionLog(version: "v1.9.1", date: "2026年8月24日", changes: [
            "更新日志页面改为全屏显示，左上角返回按钮"
        ]),
        VersionLog(version: "v1.9.0", date: "2026年8月24日", changes: [
            "彻底移除桌面小组件功能（巨魔环境下Widget扩展进程无法自动启动，导致空白）",
            "移除App Group数据同步、Widget点击跳转、URL Scheme等全部相关代码",
            "设置页移除小组件显示内容选项"
        ]),
        VersionLog(version: "v1.8.0", date: "2026年8月24日", changes: [
            "重写桌面小组件渲染逻辑，修复空白不显示问题",
            "小组件支持点击跳转：点保养项目直接打开App并跳到对应类型",
            "新增URL Scheme支持（caridle://），可从外部跳转App指定页面",
            "保养页面支持initialType参数，从Widget跳转自动打开对应类型"
        ]),
        VersionLog(version: "v1.7.1", date: "2026年8月24日", changes: [
            "修复桌面小组件空白不显示的问题",
            "小组件改用if-else渲染，添加系统背景色确保正常显示"
        ]),
        VersionLog(version: "v1.7.0", date: "2026年8月24日", changes: [
            "桌面小组件支持4种显示模式切换：综合、启动倒计时、保养提醒、年检提醒",
            "设置页新增小组件显示内容选择，切换后立即刷新",
            "App启动时自动同步数据到小组件，解决Widget无数据问题",
            "快捷功能页面改为全屏显示，左上角返回按钮",
            "保养类型卡片数字改为显示已过去天数，与历史记录一致"
        ]),
        VersionLog(version: "v1.6.0", date: "2026年8月24日", changes: [
            "新增年检提醒功能，根据车辆注册日期自动计算",
            "设置页新增车辆注册日期选择",
            "年检类型卡片动态显示倒计时（上线检测/手机申领）",
            "年检详情页显示下次年检时间，一键标记已完成",
            "年检规则：第6/10年上线检测，第2/4/8年手机申领，满10年后每年检测"
        ]),
        VersionLog(version: "v1.5.4", date: "2026年8月24日", changes: [
            "更新日志去掉「推测」「已知最早源码」等提示文字",
            "更新日志文件随源码包一起发布，避免不同步"
        ]),
        VersionLog(version: "v1.5.3", date: "2026年8月24日", changes: [
            "设置页「关于」新增「更新日志」入口",
            "APP内可直接查看完整版本历史，按倒序排列",
            "每个版本显示版本号、更新日期、更新内容列表",
            "最新版本高亮显示"
        ]),
        VersionLog(version: "v1.5.2", date: "2026年8月24日", changes: [
            "删掉主页保养提醒横向滚动卡片",
            "快捷功能去掉副标题，图标文字居中布局",
            "修复保养类型网格第一个按钮点不了的问题",
            "修复类型历史页记录点不开详情的问题",
            "保养详情页新增周期编辑功能",
            "历史记录显示「已过去X天」"
        ]),
        VersionLog(version: "v1.5.1", date: "2026年8月24日", changes: [
            "简化图表API，修复iOS 16构建兼容性问题"
        ]),
        VersionLog(version: "v1.5.0", date: "2026年8月24日", changes: [
            "电池管理升级为通用保养提醒（电瓶/机油/轮胎/保险/年检/自定义）",
            "报表新增怠速时长趋势柱状图",
            "新增桌面Widget小组件（小号+中号）",
            "App Group数据共享，主App与Widget实时同步"
        ]),
        VersionLog(version: "v1.4.1", date: "2026年8月24日", changes: [
            "删掉主页独立电池状态卡片",
            "新增下次启动倒计时卡片（带进度条）"
        ]),
        VersionLog(version: "v1.4.0", date: "2026年8月24日", changes: [
            "新增电池管理功能（记录换电池日期+距今天数）",
            "新增生成报表功能（周报/月报/年报）",
            "快捷功能扩展到6个",
            "所有数字使用等宽字体对齐"
        ]),
        VersionLog(version: "v1.3.1", date: "2026年8月23日", changes: [
            "启动/熄火计时，倒计时目标时长提醒",
            "历史记录按年份分组，支持备注删除",
            "导出JSON备份 / 导入133条历史数据",
            "启动提醒（间隔天数+推送通知）",
            "统计：总次数、总时长、距上次启动天数"
        ]),
        VersionLog(version: "v1.3.0", date: "2026年8月22日", changes: [
            "新增启动提醒功能（间隔天数+推送通知）",
            "新增导出JSON备份",
            "导入133条历史怠速记录",
            "新增距上次启动天数统计"
        ]),
        VersionLog(version: "v1.2", date: "2026年8月21日", changes: [
            "新增统计卡片（总次数、总时长）",
            "倒计时目标时长设置（10~60分钟可选）",
            "记录备注功能"
        ]),
        VersionLog(version: "v1.1", date: "2026年8月20日", changes: [
            "新增历史记录列表，按时间排序",
            "记录详情页（日期、启动/熄火时间、时长）"
        ]),
        VersionLog(version: "v1.0", date: "2026年8月19日", changes: [
            "最初版本：启动/熄火按钮 + 基础计时功能",
            "单条记录保存"
        ])
    ]

    var body: some View {
        NavigationStack {
            ScrollView {
                LazyVStack(spacing: 16) {
                    ForEach(Array(logs.enumerated()), id: \.element.id) { index, log in
                        let isLatest = index == 0
                        VStack(alignment: .leading, spacing: 10) {
                            HStack(alignment: .firstTextBaseline, spacing: 8) {
                                Text(log.version)
                                    .font(.headline.bold())
                                    .foregroundStyle(isLatest ? .blue : .primary)
                                if isLatest {
                                    Text("最新")
                                        .font(.caption2.bold())
                                        .foregroundStyle(.white)
                                        .padding(.horizontal, 6).padding(.vertical, 2)
                                        .background(Color.blue)
                                        .clipShape(Capsule())
                                }
                                Spacer()
                                Text(log.date)
                                    .font(.caption)
                                    .foregroundStyle(.tertiary)
                            }
                            Divider()
                            VStack(alignment: .leading, spacing: 6) {
                                ForEach(log.changes, id: \.self) { change in
                                    HStack(alignment: .top, spacing: 6) {
                                        Image(systemName: "circle.fill")
                                            .font(.system(size: 5))
                                            .foregroundStyle(isLatest ? .blue : .secondary)
                                            .padding(.top, 6)
                                        Text(change)
                                            .font(.subheadline)
                                            .foregroundStyle(.primary)
                                            .fixedSize(horizontal: false, vertical: true)
                                    }
                                }
                            }
                        }
                        .padding(14)
                        .background(isLatest ? Color.blue.opacity(0.06) : Color(.secondarySystemGroupedBackground))
                        .clipShape(RoundedRectangle(cornerRadius: 14))
                        .overlay(
                            RoundedRectangle(cornerRadius: 14)
                                .stroke(isLatest ? Color.blue.opacity(0.3) : Color.clear, lineWidth: 1)
                        )
                    }
                }
                .padding(.horizontal, 16)
                .padding(.top, 8)
                .padding(.bottom, 20)
            }
            .background(Color(.systemGroupedBackground))
            .navigationTitle("更新日志").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItemGroup(placement: .topBarLeading) { Button("返回") { dismiss() } } }
        }
    }
}

// MARK: - 记录详情页
