import SwiftUI
import UIKit
import Charts
import UniformTypeIdentifiers

struct MaintenanceDetailView: View {
    @ObservedObject var store: IdleStore
    let record: MaintenanceRecord
    let onDelete: () -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var noteText: String
    @State private var intervalDays: Int

    init(store: IdleStore, record: MaintenanceRecord, onDelete: @escaping () -> Void) {
        self.store = store
        self.record = record
        self.onDelete = onDelete
        _noteText = State(initialValue: record.note)
        _intervalDays = State(initialValue: record.intervalDays)
    }

    var body: some View {
        NavigationStack {
            List {
                Section {
                    HStack { Text("项目"); Spacer(); Text(record.displayName).foregroundStyle(.secondary) }
                    HStack { Text("更换日期"); Spacer(); Text(record.dateText).foregroundStyle(.secondary) }
                    HStack {
                        Text("已过去"); Spacer()
                        Text("\(record.daysSince) 天").foregroundStyle(.secondary).monospacedDigit()
                    }
                    HStack {
                        Text("状态")
                        Spacer()
                        let color: Color = record.statusLevel == 2 ? .red : (record.statusLevel == 1 ? .orange : .green)
                        Text(record.isOverdue ? "已超期\(-record.daysRemaining)天" : "还有\(record.daysRemaining)天")
                            .foregroundStyle(color).bold()
                    }
                }
                Section("保养周期") {
                    Stepper(value: $intervalDays, in: 7...3650, step: 30) {
                        HStack {
                            Text("周期")
                            Spacer()
                            Text("\(intervalDays) 天（约\(intervalDays / 30)个月）")
                                .foregroundStyle(.secondary).monospacedDigit()
                        }
                    }
                    Text("轮胎、机油等周期可根据实际情况自行调整")
                        .font(.caption).foregroundStyle(.secondary)
                }
                Section("备注") {
                    TextField("添加备注，如：银美孚5W-30", text: $noteText, axis: .vertical).lineLimit(2...4)
                }
                Section {
                    Button(role: .destructive) { onDelete(); dismiss() } label: {
                        HStack { Image(systemName: "trash"); Text("删除此记录") }
                    }
                }
            }
            .navigationTitle("保养详情").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItemGroup(placement: .topBarTrailing) {
                Button("保存") {
                    store.updateMaintenanceNote(record, note: noteText)
                    store.updateMaintenanceInterval(record, intervalDays: intervalDays)
                    dismiss()
                }
            } }
        }
    }
}

// MARK: - 报表页
