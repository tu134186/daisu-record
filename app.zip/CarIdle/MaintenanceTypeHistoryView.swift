import SwiftUI
import UIKit
import Charts
import UniformTypeIdentifiers

struct MaintenanceTypeHistoryView: View {
    @ObservedObject var store: IdleStore
    let type: MaintenanceType
    @Environment(\.dismiss) private var dismiss
    @State private var showAdd = false
    @State private var selectedRecord: MaintenanceRecord?

    var records: [MaintenanceRecord] { store.maintenanceHistory(for: type) }

    var body: some View {
        NavigationStack {
            List {
                if type == .inspection {
                    Section {
                        if store.vehicleRegistrationDate == nil {
                            VStack(spacing: 8) {
                                Image(systemName: "calendar.badge.exclamationmark")
                                    .font(.system(size: 32)).foregroundStyle(.orange)
                                Text("请先在设置页填写车辆注册日期")
                                    .font(.subheadline).foregroundStyle(.secondary)
                            }
                            .frame(maxWidth: .infinity).padding(.vertical, 20)
                        } else if let next = store.nextInspection {
                            VStack(spacing: 10) {
                                HStack(spacing: 8) {
                                    Image(systemName: next.type.icon)
                                        .font(.system(size: 20))
                                        .foregroundStyle(next.type == .online ? .red : .blue)
                                    Text("下次年检")
                                        .font(.subheadline).foregroundStyle(.secondary)
                                    Spacer()
                                    Text(next.type.title)
                                        .font(.caption.bold())
                                        .foregroundStyle(.white)
                                        .padding(.horizontal, 8).padding(.vertical, 3)
                                        .background(next.type == .online ? Color.red : Color.blue)
                                        .clipShape(Capsule())
                                }
                                HStack(alignment: .firstTextBaseline, spacing: 4) {
                                    let days = store.daysUntilInspection ?? 0
                                    let color: Color = days <= 0 ? .red : (days <= 90 ? .orange : .green)
                                    Text(days <= 0 ? "已超期" : "还有")
                                        .font(.subheadline).foregroundStyle(.secondary)
                                    Text("\(abs(days))")
                                        .font(.system(size: 36, weight: .bold, design: .rounded))
                                        .foregroundStyle(color).monospacedDigit()
                                    Text("天")
                                        .font(.subheadline).foregroundStyle(.secondary)
                                    Spacer()
                                }
                                Text(next.dateText)
                                    .font(.caption).foregroundStyle(.tertiary)
                                Button {
                                    store.markInspectionDone()
                                } label: {
                                    HStack {
                                        Image(systemName: "checkmark.circle.fill")
                                        Text("标记本次年检已完成")
                                            .font(.subheadline.bold())
                                    }
                                    .frame(maxWidth: .infinity).padding()
                                    .background(AppleDesign.positive)
                                    .foregroundStyle(.white)
                                    .clipShape(RoundedRectangle(cornerRadius: 10))
                                }
                                .buttonStyle(.plain)
                                .padding(.top, 4)
                            }
                            .padding(.vertical, 8)
                        }
                    }
                }
                if records.isEmpty {
                    Section {
                        VStack(spacing: 10) {
                            Image(systemName: type.icon).font(.system(size: 36)).foregroundStyle(.secondary)
                            Text("暂无\(type.rawValue)记录").font(.subheadline).foregroundStyle(.secondary)
                        }
                        .frame(maxWidth: .infinity).padding(.vertical, 40)
                        .listRowBackground(Color.clear)
                    }
                } else {
                    ForEach(records) { record in
                        Button {
                            selectedRecord = record
                        } label: {
                            VStack(alignment: .leading, spacing: 4) {
                                HStack {
                                    Text(record.dateText).font(.subheadline.bold()).foregroundStyle(.primary)
                                    Spacer()
                                    let color: Color = record.statusLevel == 2 ? .red : (record.statusLevel == 1 ? .orange : .green)
                                    Text(record.isOverdue ? "超期\(-record.daysRemaining)天" : "周期\(record.intervalDays)天")
                                        .font(.caption).foregroundStyle(color)
                                }
                                HStack(spacing: 6) {
                                    Text("已过去\(record.daysSince)天").font(.caption).foregroundStyle(.secondary).monospacedDigit()
                                    if !record.note.isEmpty {
                                        Text("·").font(.caption).foregroundStyle(.tertiary)
                                        Text(record.note).font(.caption).foregroundStyle(.secondary).lineLimit(1)
                                    }
                                }
                            }
                            .padding(.vertical, 2)
                        }
                        .buttonStyle(.plain)
                        .swipeActions(edge: .trailing) {
                            Button(role: .destructive) { store.deleteMaintenanceRecord(record) } label: {
                                Label("删除", systemImage: "trash")
                            }
                        }
                    }
                }
            }.proGroupedRows()
            .navigationTitle("\(type.rawValue)记录").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItemGroup(placement: .topBarLeading) { Button("关闭") { dismiss() } }
                ToolbarItemGroup(placement: .topBarTrailing) {
                    Button { showAdd = true } label: { Image(systemName: "plus") }
                }
            }
            .sheet(isPresented: $showAdd) {
                AddMaintenanceView(store: store, preselectedType: type)
            }
            .sheet(item: $selectedRecord) { record in
                MaintenanceDetailView(store: store, record: record) {
                    store.deleteMaintenanceRecord(record)
                    selectedRecord = nil
                }
            }
        }
    }
}

// MARK: - 添加保养记录
