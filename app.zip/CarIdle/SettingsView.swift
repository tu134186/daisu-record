import SwiftUI
import UIKit
import Charts
import UniformTypeIdentifiers

struct SettingsView: View {
    @ObservedObject var store: IdleStore
    let onImport: (Int) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var showFileImporter = false
    @State private var showClearConfirm = false
    @State private var showExportFormat = false
    @State private var exportText = ""
    @State private var showActivityView = false

    private var vehicleAgeText: String {
        guard let regDate = store.vehicleRegistrationDate else { return "—" }
        let years = Calendar.current.dateComponents([.year], from: regDate, to: Date()).year ?? 0
        return "\(years)年"
    }

    @ViewBuilder
    private func versionHistoryRow(_ version: String, _ summary: String) -> some View {
        HStack(alignment: .top, spacing: 10) {
            Text(version)
                .font(.caption.bold())
                .foregroundStyle(.blue)
                .frame(width: 58, alignment: .leading)
            Text(summary)
                .font(.caption)
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("怠速倒计时") {
                    HStack {
                        Text("目标时长"); Spacer()
                        Picker("", selection: $store.countdownMinutes) {
                            Text("10分钟").tag(10); Text("15分钟").tag(15); Text("20分钟").tag(20)
                            Text("30分钟").tag(30); Text("45分钟").tag(45); Text("60分钟").tag(60)
                        }.pickerStyle(.menu)
                    }
                    Text("启动后达到目标时长会震动提醒").font(.caption).foregroundStyle(.secondary)
                }
                Section("启动提醒") {
                    Toggle("开启提醒", isOn: $store.reminderEnabled)
                    if store.reminderEnabled {
                        HStack {
                            Text("间隔天数"); Spacer()
                            Picker("", selection: $store.reminderIntervalDays) {
                                Text("5天").tag(5); Text("7天").tag(7); Text("10天").tag(10); Text("14天").tag(14)
                            }.pickerStyle(.menu)
                        }
                        Text("熄火后\(store.reminderIntervalDays)天会推送通知提醒启动车辆").font(.caption).foregroundStyle(.secondary)
                    }
                }
                Section("数据管理") {
                    Button {
                        showExportFormat = true
                    } label: {
                        HStack {
                            Image(systemName: "square.and.arrow.up").foregroundStyle(.green)
                            Text("导出备份（JSON/CSV）"); Spacer()
                            Image(systemName: "chevron.right").font(.caption).foregroundStyle(.tertiary)
                        }
                    }
                    Button {
                        showFileImporter = true
                    } label: {
                        HStack {
                            Image(systemName: "doc.badge.plus").foregroundStyle(.green)
                            Text("从文件导入（JSON/CSV）"); Spacer()
                            Image(systemName: "chevron.right").font(.caption).foregroundStyle(.tertiary)
                        }
                    }
                    Button(role: .destructive) {
                        showClearConfirm = true
                    } label: {
                        HStack {
                            Image(systemName: "trash")
                            Text("清空全部怠速记录")
                        }
                    }
                    Text("从文件导入支持JSON和CSV格式，重复数据（相同启动+熄火时间）不会重复导入").font(.caption).foregroundStyle(.secondary)
                }
                Section("车辆信息") {
                    if let regDate = store.vehicleRegistrationDate {
                        DatePicker("注册日期", selection: Binding(
                            get: { regDate },
                            set: { store.vehicleRegistrationDate = $0 }
                        ), displayedComponents: .date)
                        HStack {
                            Text("车龄")
                            Spacer()
                            Text(vehicleAgeText)
                                .foregroundStyle(.secondary)
                        }
                        if let next = store.nextInspection {
                            HStack {
                                Text("下次年检")
                                Spacer()
                                VStack(alignment: .trailing, spacing: 2) {
                                    Text(next.dateText)
                                        .foregroundStyle(.secondary)
                                    Text(next.type.title)
                                        .font(.caption)
                                        .foregroundStyle(next.type == .online ? .red : .blue)
                                }
                            }
                        }
                    } else {
                        Button {
                            store.vehicleRegistrationDate = Date()
                        } label: {
                            HStack {
                                Text("设置注册日期")
                                    .foregroundStyle(.blue)
                                Spacer()
                                Image(systemName: "chevron.right").font(.caption).foregroundStyle(.tertiary)
                            }
                        }
                    }
                    Text("设置后自动计算年检倒计时：第6/10年上线检测，第2/4/8年手机申领，满10年后每年检测")
                        .font(.caption).foregroundStyle(.secondary)
                }
                Section("关于") {
                    HStack {
                        Text("当前版本")
                        Spacer()
                        Text(Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "2.2.12")
                            .foregroundStyle(.secondary)
                    }

                    VStack(alignment: .leading, spacing: 12) {
                        Text("历史更新")
                            .font(.subheadline.bold())

                        versionHistoryRow("v2.2.12", "关于页整合完整历史更新；记录 Widget 添加后需注销才首次显示的问题")
                        versionHistoryRow("v2.2.11", "开发说明重新整理；关于页加入历史版本更新记录")
                        versionHistoryRow("v2.2.10", "清理旧 Widget 残留，只保留一个 Widget Extension 和唯一 kind")
                        versionHistoryRow("v2.2.9", "小组件改为固定白底黑字硬诊断，继续排查空白问题")
                        versionHistoryRow("v2.2.8", "Widget 完全断开 App Group/业务数据，进行纯启动隔离测试")
                        versionHistoryRow("v2.2.5", "针对“有阴影但内容空白”进行 Widget 渲染专项诊断")
                        versionHistoryRow("v2.2.4", "修复 Widget Entry 漏传 sharedDataConnected 导致的编译失败")
                        versionHistoryRow("v2.2.3", "回退到 V2.2.0 可显示架构，移除高风险跨沙盒方案")
                        versionHistoryRow("v2.2.0", "新增中号桌面小组件与共享摘要数据")
                        versionHistoryRow("v2.1.0", "精修首页信息层级、启动建议和保养提醒展示")
                        versionHistoryRow("v2.0.0", "V2 首页重构并拆分大型 ContentView，保留旧数据兼容")
                        versionHistoryRow("v1.10.4", "设置页数据管理移除导入内置历史数据按钮")
                        versionHistoryRow("v1.10.3", "快捷功能移除重复导出/导入入口，统一到设置页")
                        versionHistoryRow("v1.10.2", "设置页数据管理新增导出备份入口")
                        versionHistoryRow("v1.10.1", "导出备份直接选择格式并调起系统分享")
                        versionHistoryRow("v1.10.0", "导出支持 JSON/CSV；新增文件导入、去重和清空记录")
                        versionHistoryRow("v1.9.1", "更新日志页面改为全屏显示")
                        versionHistoryRow("v1.9.0", "曾移除桌面小组件及相关共享功能")
                        versionHistoryRow("v1.8.0", "重写桌面小组件渲染与点击跳转")
                        versionHistoryRow("v1.7.1", "修复桌面小组件空白显示问题")
                        versionHistoryRow("v1.7.0", "小组件增加多种显示模式与设置项")
                        versionHistoryRow("v1.6.0", "新增年检提醒和车辆注册日期计算")
                        versionHistoryRow("v1.5.4", "整理更新日志文字并随源码包发布")
                        versionHistoryRow("v1.5.3", "设置 → 关于新增更新日志入口和完整版本历史")
                        versionHistoryRow("v1.5.2", "优化主页/快捷功能并修复保养相关点击问题")
                        versionHistoryRow("v1.5.1", "简化图表 API，修复 iOS 16 构建兼容")
                        versionHistoryRow("v1.5.0", "保养提醒、趋势图和桌面 Widget 功能扩展")
                        versionHistoryRow("v1.4.1", "新增下次启动倒计时卡片")
                        versionHistoryRow("v1.4.0", "新增电池管理、周/月/年报表与快捷功能")
                        versionHistoryRow("v1.3.1", "完善计时、历史、导入导出、提醒和统计")
                        versionHistoryRow("v1.3.0", "新增启动提醒、JSON 备份、历史数据导入和统计")
                        versionHistoryRow("v1.2", "新增统计卡片、目标时长设置和备注")
                        versionHistoryRow("v1.1", "新增历史记录列表和记录详情")
                        versionHistoryRow("v1.0", "最初版本：启动/熄火按钮与基础计时")
                    }
                    .padding(.vertical, 4)

                    Text("怠速记录 · 保养提醒 · 报表趋势 · 年检提醒")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            .navigationTitle("设置").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItemGroup(placement: .topBarLeading) { Button("返回") { dismiss() } } }
            .confirmationDialog("选择导出格式", isPresented: $showExportFormat) {
                Button("JSON格式") {
                    exportText = store.exportJSON() ?? ""
                    showActivityView = true
                }
                Button("CSV表格格式（可用Excel打开）") {
                    exportText = store.exportCSV() ?? ""
                    showActivityView = true
                }
                Button("取消", role: .cancel) {}
            } message: {
                Text("选择要导出的文件格式")
            }
            .sheet(isPresented: $showActivityView) {
                ActivityView(activityItems: [exportText])
            }
            .fileImporter(isPresented: $showFileImporter, allowedContentTypes: [.json, .commaSeparatedText, .plainText]) { result in
                switch result {
                case .success(let url):
                    guard url.startAccessingSecurityScopedResource() else { return }
                    defer { url.stopAccessingSecurityScopedResource() }
                    guard let content = try? String(contentsOf: url, encoding: .utf8) else { return }
                    let count: Int
                    if url.pathExtension.lowercased() == "csv" || content.hasPrefix("日期,") {
                        count = store.importRecords(fromCSV: content)
                    } else {
                        count = store.importRecords(fromJSON: content)
                    }
                    onImport(count)
                case .failure:
                    break
                }
            }
            .alert("确认清空", isPresented: $showClearConfirm) {
                Button("取消", role: .cancel) {}
                Button("清空全部", role: .destructive) {
                    store.clearAll()
                }
            } message: {
                Text("将删除全部\(store.records.count)条怠速记录，此操作不可恢复。建议先导出备份。")
            }
        }
    }
}

// MARK: - 更新日志
