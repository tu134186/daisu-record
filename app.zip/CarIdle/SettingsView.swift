import SwiftUI
import UIKit
import Charts
import UniformTypeIdentifiers
import WidgetKit

struct SettingsView: View {
    @ObservedObject var store: IdleStore
    let onImport: (Int) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var showFileImporter = false
    @State private var showClearConfirm = false
    @State private var showExportFormat = false
    @State private var exportText = ""
    @State private var showActivityView = false
    @State private var showVersionHistory = false
    @State private var widgetRegistrationText = "检测中…"
    @State private var widgetRegistrationDetail = "正在读取系统当前已登记的小组件配置"

    private var vehicleAgeText: String {
        guard let regDate = store.vehicleRegistrationDate else { return "—" }
        let years = Calendar.current.dateComponents([.year], from: regDate, to: Date()).year ?? 0
        return "\(years)年"
    }


    var body: some View {
        NavigationStack {
            Form {
                Section("怠速倒计时") {
                    HStack {
                        Text("目标时长"); Spacer()
                        Picker("", selection: $store.countdownMinutes) {
                            Text("10分钟").tag(10); Text("15分钟").tag(15); Text("20分钟").tag(20)
                            Text("30分钟").tag(30); Text("45分钟").tag(45); Text("60分钟").tag(60)
                        }.pickerStyle(.menu)
                    }
                    Text("启动后达到目标时长会震动提醒").font(.caption).foregroundStyle(.secondary)
                }
                Section("启动提醒") {
                    Toggle("开启提醒", isOn: $store.reminderEnabled)
                    if store.reminderEnabled {
                        HStack {
                            Text("间隔天数"); Spacer()
                            Picker("", selection: $store.reminderIntervalDays) {
                                Text("5天").tag(5); Text("7天").tag(7); Text("10天").tag(10); Text("14天").tag(14)
                            }.pickerStyle(.menu)
                        }
                        Text("熄火后\(store.reminderIntervalDays)天会推送通知提醒启动车辆").font(.caption).foregroundStyle(.secondary)
                    }
                }
                Section("数据管理") {
                    Button {
                        showExportFormat = true
                    } label: {
                        HStack {
                            Image(systemName: "square.and.arrow.up").foregroundStyle(.green)
                            Text("导出备份（JSON/CSV）"); Spacer()
                            Image(systemName: "chevron.right").font(.caption).foregroundStyle(.tertiary)
                        }
                    }
                    Button {
                        showFileImporter = true
                    } label: {
                        HStack {
                            Image(systemName: "doc.badge.plus").foregroundStyle(.green)
                            Text("从文件导入（JSON/CSV）"); Spacer()
                            Image(systemName: "chevron.right").font(.caption).foregroundStyle(.tertiary)
                        }
                    }
                    Button(role: .destructive) {
                        showClearConfirm = true
                    } label: {
                        HStack {
                            Image(systemName: "trash")
                            Text("清空全部怠速记录")
                        }
                    }
                    Text("从文件导入支持JSON和CSV格式，重复数据（相同启动+熄火时间）不会重复导入").font(.caption).foregroundStyle(.secondary)
                }
                Section("车辆信息") {
                    if let regDate = store.vehicleRegistrationDate {
                        DatePicker("注册日期", selection: Binding(
                            get: { regDate },
                            set: { store.vehicleRegistrationDate = $0 }
                        ), displayedComponents: .date)
                        HStack {
                            Text("车龄")
                            Spacer()
                            Text(vehicleAgeText)
                                .foregroundStyle(.secondary)
                        }
                        if let next = store.nextInspection {
                            HStack {
                                Text("下次年检")
                                Spacer()
                                VStack(alignment: .trailing, spacing: 2) {
                                    Text(next.dateText)
                                        .foregroundStyle(.secondary)
                                    Text(next.type.title)
                                        .font(.caption)
                                        .foregroundStyle(next.type == .online ? .red : .blue)
                                }
                            }
                        }
                    } else {
                        Button {
                            store.vehicleRegistrationDate = Date()
                        } label: {
                            HStack {
                                Text("设置注册日期")
                                    .foregroundStyle(.blue)
                                Spacer()
                                Image(systemName: "chevron.right").font(.caption).foregroundStyle(.tertiary)
                            }
                        }
                    }
                    Text("设置后自动计算年检倒计时：第6/10年上线检测，第2/4/8年手机申领，满10年后每年检测")
                        .font(.caption).foregroundStyle(.secondary)
                }
                Section("小组件诊断") {
                    HStack {
                        Text("系统登记状态")
                        Spacer()
                        Text(widgetRegistrationText)
                            .foregroundStyle((widgetRegistrationText == "已登记" || widgetRegistrationText == "已运行") ? .green : .orange)
                    }
                    Text(widgetRegistrationDetail)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    Button {
                        widgetRegistrationText = "检测中…"
                        widgetRegistrationDetail = "正在重新读取系统 Widget 配置…"
                        checkWidgetRegistration()
                    } label: {
                        HStack {
                            Text("重新检测")
                            Spacer()
                            Image(systemName: "arrow.clockwise")
                        }
                        .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    .foregroundStyle(.blue)
                }

                Section("关于") {
                    HStack {
                        Text("当前版本")
                        Spacer()
                        Text(Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "2.2.26")
                            .foregroundStyle(.secondary)
                    }

                    Button {
                        showVersionHistory = true
                    } label: {
                        HStack {
                            Text("历史更新")
                                .foregroundStyle(.primary)
                            Spacer()
                            Text("查看全部")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                            Image(systemName: "chevron.right")
                                .font(.caption)
                                .foregroundStyle(.tertiary)
                        }
                    }


                    Text("怠速记录 · 保养提醒 · 报表趋势 · 年检提醒")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            .navigationTitle("设置").navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItemGroup(placement: .topBarLeading) { Button("返回") { dismiss() } } }
            .task { checkWidgetRegistration() }
            .confirmationDialog("选择导出格式", isPresented: $showExportFormat) {
                Button("JSON格式") {
                    exportText = store.exportJSON() ?? ""
                    showActivityView = true
                }
                Button("CSV表格格式（可用Excel打开）") {
                    exportText = store.exportCSV() ?? ""
                    showActivityView = true
                }
                Button("取消", role: .cancel) {}
            } message: {
                Text("选择要导出的文件格式")
            }
            .sheet(isPresented: $showActivityView) {
                ActivityView(activityItems: [exportText])
            }
            .fullScreenCover(isPresented: $showVersionHistory) {
                VersionHistoryView()
            }
            .fileImporter(isPresented: $showFileImporter, allowedContentTypes: [.json, .commaSeparatedText, .plainText]) { result in
                switch result {
                case .success(let url):
                    guard url.startAccessingSecurityScopedResource() else { return }
                    defer { url.stopAccessingSecurityScopedResource() }
                    guard let content = try? String(contentsOf: url, encoding: .utf8) else { return }
                    let count: Int
                    if url.pathExtension.lowercased() == "csv" || content.hasPrefix("日期,") {
                        count = store.importRecords(fromCSV: content)
                    } else {
                        count = store.importRecords(fromJSON: content)
                    }
                    onImport(count)
                case .failure:
                    break
                }
            }
            .alert("确认清空", isPresented: $showClearConfirm) {
                Button("取消", role: .cancel) {}
                Button("清空全部", role: .destructive) {
                    store.clearAll()
                }
            } message: {
                Text("将删除全部\(store.records.count)条怠速记录，此操作不可恢复。建议先导出备份。")
            }
        }
    }
    private func checkWidgetRegistration() {
        let heartbeat = CarIdleWidgetShared.widgetHeartbeatDate()
        WidgetCenter.shared.getCurrentConfigurations { result in
            DispatchQueue.main.async {
                let formatter = DateFormatter()
                formatter.dateFormat = "HH:mm:ss"

                switch result {
                case .success(let widgets):
                    let matching = widgets.filter { $0.kind == CarIdleWidgetShared.widgetKind }
                    if let heartbeat {
                        widgetRegistrationText = "已运行"
                        let systemPart = matching.isEmpty
                            ? "WidgetCenter 没有返回配置，但这不能代表未登记。"
                            : "WidgetCenter 同时返回了 \(matching.count) 个配置。"
                        widgetRegistrationDetail = "Widget Extension 已实际启动并写入心跳（\(formatter.string(from: heartbeat))）。\(systemPart) 以 Extension 实际运行结果为准。"
                    } else if !matching.isEmpty {
                        widgetRegistrationText = "已登记"
                        widgetRegistrationDetail = "系统返回 \(matching.count) 个 CarIdleMediumWidget 配置，但暂未收到 Extension 运行心跳。把小组件放到桌面/负一屏并显示一次后再检测。"
                    } else {
                        widgetRegistrationText = "尚未确认"
                        widgetRegistrationDetail = "WidgetCenter 暂未返回配置，也还没有 Extension 运行心跳。V2.2.26 不再把这一结果直接判定为‘未登记’，因为实测 TrollStore 环境可能出现系统列表为空但小组件已经正常显示。"
                    }
                case .failure(let error):
                    if let heartbeat {
                        widgetRegistrationText = "已运行"
                        widgetRegistrationDetail = "Widget Extension 已实际启动并写入心跳（\(formatter.string(from: heartbeat))）；系统配置读取失败：\(error.localizedDescription)"
                    } else {
                        widgetRegistrationText = "检测失败"
                        widgetRegistrationDetail = "WidgetCenter 读取失败：\(error.localizedDescription)"
                    }
                }
            }
        }
    }

}

// MARK: - 更新日志
