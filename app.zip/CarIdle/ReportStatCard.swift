import SwiftUI
import UIKit
import Charts
import UniformTypeIdentifiers

struct ReportStatCard: View {
    let value: String, label: String, icon: String, color: Color
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 6) {
                Image(systemName: icon).font(.system(size: 14)).foregroundStyle(color)
                Text(label).font(.caption).foregroundStyle(.secondary)
            }
            Text(value).font(.title2.bold()).foregroundStyle(color)
                .lineLimit(1).minimumScaleFactor(0.6).monospacedDigit()
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(14).background(color.opacity(0.08))
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }
}

// MARK: - 历史记录页
