import SwiftUI
import UIKit
import Charts
import UniformTypeIdentifiers

struct ExportView: View {
    let store: IdleStore
    @Environment(\.dismiss) private var dismiss
    @State private var format: Int = 0 // 0=JSON, 1=CSV

    private var exportText: String {
        if format == 0 {
            return store.exportJSON() ?? ""
        } else {
            return store.exportCSV() ?? ""
        }
    }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                Picker("导出格式", selection: $format) {
                    Text("JSON").tag(0)
                    Text("CSV表格").tag(1)
                }
                .pickerStyle(.segmented)
                .padding(.horizontal, 16)
                .padding(.vertical, 10)

                if exportText.isEmpty {
                    VStack(spacing: 12) {
                        Image(systemName: "tray").font(.system(size: 40)).foregroundStyle(.secondary)
                        Text("没有可导出的数据").font(.headline).foregroundStyle(.secondary)
                    }.frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    ScrollView {
                        Text(exportText)
                            .font(.system(.caption, design: .monospaced))
                            .padding()
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                }
            }
            .navigationTitle("导出备份").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItemGroup(placement: .topBarLeading) { Button("返回") { dismiss() } }
                ToolbarItemGroup(placement: .topBarTrailing) {
                    ShareLink(item: exportText) { Image(systemName: "square.and.arrow.up") }
                        .disabled(exportText.isEmpty)
                }
            }
        }
    }
}

// MARK: - 系统分享面板
