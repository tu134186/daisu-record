CarIdle V2.3.6 / Build 41
Added ActivityKit lock screen and Dynamic Island live activity with Widget Extension.
Added Settings toggle. Ends live activity on save/cancel.
Disabled timer Text implicit animation (visual fix pending device verification).
Original data models, history, reports, maintenance and backups unchanged.
IMPORTANT: Uncompiled source; test with Codemagic/TrollStore.
