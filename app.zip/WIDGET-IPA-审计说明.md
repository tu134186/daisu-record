# Widget / TrollStore 最终 IPA 审计说明（V2.2.16，继承 V2.2.14 成功基线）

本版目的不是再给 Widget 加刷新补丁，而是把“源码问题”和“安装后 Extension 注册问题”彻底分开。

## 本版关键修正

1. Widget kind 永久固定为 `CarIdleMediumWidget`。kind 是 WidgetKit 保存桌面配置的身份，不应跟版本号一起变化。
2. 主 App 不再主动调用 `reloadTimelines` 做延迟补丁。
3. Widget 仍是最小静态内容，只显示 `WIDGET V2.2.14`。
4. 编译完成后必须检查最终 IPA，而不是只看源码。

## 编译完成后检查

在 macOS/GitHub runner 上运行：

```bash
bash tools/check-built-ipa.sh path/to/app.ipa 2.2.16 45
```

脚本必须确认：
- 主 App：`com.trollbox.caridle`，版本 2.2.14 / build 44；
- Widget：`com.trollbox.caridle.widget`，版本 2.2.14 / build 44；
- `Payload/*.app/PlugIns/*.appex` 确实存在；
- `NSExtensionPointIdentifier = com.apple.widgetkit-extension`；
- `.appex` 的可执行文件存在；
- 输出实际签名和 entitlements 供排查。

## 真机测试判定

如果最终 IPA 审计全部通过，但 TrollStore 覆盖安装后桌面仍显示 V2.2.12/V2.2.13，而注销 SpringBoard 后立即变成 V2.2.14，则不要再修改 TimelineProvider/SwiftUI。此时现象已经指向 TrollStore/iOS 对 App Extension 的注册、缓存或 sandbox 生命周期。

TrollStore 官方仓库目前也存在与 Widget sandbox 分配有关的公开 issue（#873），以及扩展残留导致系统认为旧 App Extension 仍已安装的历史 issue（#752）。因此这类现象不能简单等同于 Widget SwiftUI 代码错误。

## V2.2.14 真机成功案例

用户此前覆盖安装后，桌面 Widget 会继续显示旧版 V2.2.12，只有注销 SpringBoard 后才切换。V2.2.14 固定 `kind = CarIdleMediumWidget`、移除延迟 `reloadTimelines` 补丁后，真机确认：**无需注销 SpringBoard，覆盖安装后桌面 Widget 秒级更新为 `WIDGET V2.2.14`。**

因此 V2.2.14 的 Widget Extension 结构、Bundle ID 和 kind 作为成功基线锁定。后续若再次出现“升级后仍显示旧版本”，第一件事是对比是否有人改了 kind/target/Bundle ID，而不是继续增加刷新补丁。


## V2.2.16 连续升级验证目标
V2.2.16 不改变 V2.2.14 已验证成功的 Extension 身份结构，仅更新版本/build 和 Widget 可见文字。覆盖安装后若桌面现有 Widget 无需注销直接显示 `WIDGET V2.2.16`，即可确认固定 kind 路线连续两版稳定。
