# V2.2.4

- 修复 Widget 编译失败：`CarIdleWidgetEntry` 新增 `sharedDataConnected` 后，placeholder 与 timeline 构造处漏传该必填参数。
- `placeholder` 补齐 `sharedDataConnected: true`；`getTimeline` 按实际 App Group 连通状态传值。
- 不修改主 App 数据键、历史记录格式、Bundle ID、App Group 或 Widget 架构。
- 版本同步为 2.2.4 / build 34。

# V2.2.3

- 回退到 V2.2.0 已验证能显示的 Widget 架构。
- 移除跨沙盒读取、私有权限和额外 ldid 重签方案。
- 保留标准 App Group。
- Widget 能运行但共享数据读不到时，明确显示“组件运行正常 · 数据共享未连接”。
- 不修改主 App 历史数据格式。

# V2.2.0

- 新增唯一一个「中号」桌面小组件，不提供小号/大号。
- 小组件显示：当前运行状态、距上次启动、上次时长、总次数、下次启动建议。
- 主 App 与 Widget 使用 `group.com.trollbox.caridle` App Group 共享摘要数据。
- 主 App 的历史记录仍保留在原 `UserDefaults.standard`，不迁移、不破坏 V2.1.0 数据。
- 每次启动/熄火/取消/修改提醒间隔时，同步摘要并刷新 Widget Timeline。
- Widget Extension: `com.trollbox.caridle.widget`，仅支持 `.systemMedium`。

# V2.1.0

- 首页精修：压缩顶部车辆状态卡片与整体纵向间距，减少首屏拥挤。
- “距上次”不再显示生硬的 `0.0天`，改为“刚刚 / 今天 / 1天 / N天”。
- “当前已闲置”按小时/天自然显示。
- 超期很久的保养提醒弱化为“已到期 · 建议尽快检查”，避免大号红色数字喧宾夺主。
- 首页移除重复的“设置”快捷入口，设置统一使用右上角齿轮；常用功能保留历史、报表、保养。
- “最近一次”卡片压缩为两行，提高首屏信息密度。
- 不修改 V2.0.2 已验证的数据存储、历史记录格式和 Bundle ID。
- 版本同步为 2.1.0 / build 29。

# V2.0.2

- App 对外显示名称统一为「怠速记录」。
- 保持原 Bundle ID `com.trollbox.caridle`，避免覆盖安装后丢失旧数据。
- GitHub 构建方式统一为“仓库只维护 app.zip + 一份固定工作流”，以后升级只替换 app.zip。
- 版本同步为 2.0.2 / build 28。

# V2.0.1

- 修复 GitHub Actions 编译工作流：旧工作流在真正编译前先执行 `test -f app.zip`，导致 5 秒内直接退出，实际上并未进入 Xcode 编译。
- 新工作流顺序：checkout → 安装 xcodegen → 生成工程 → xcodebuild → 定位 .app → 打包 Payload/app.zip → 上传 artifact。
- 增加构建产物存在性检查和 Info.plist 检查，失败时输出实际 Products 目录，便于排查。
- 版本同步为 2.0.1 / build 27。

# 更新日志

## v2.0.0 - 2026-09-01
- 首页重做为“车辆状态”中心，启动/熄火成为第一视觉和第一操作。
- 运行中突出计时、目标剩余时间与熄火保存。
- 新增更清晰的总次数、总时长、距上次统计区。
- 首页直接显示最紧急保养提醒、下次启动建议和最近一次记录。
- 常用功能缩成四个清晰入口：历史、报表、保养、设置。
- 将原 1500+ 行 ContentView.swift 中多个页面拆成独立 Swift 文件。
- 设置页版本号改为读取 Bundle 版本。
- 保留 V1.10.4 原有数据键与历史数据格式，减少升级丢数据风险。

## v1.10.4
- 原版基线，完整历史见源码内 `#U66f4#U65b0#U65e5#U5fd7.txt`。

## V2.2.5 (build 35)
- 修复桌面小组件“有切换阴影但内容整块空白”的问题定位版本。
- 小组件预览阶段不再访问共享数据，始终使用可渲染的示例 Entry。
- 正常时间线在 App Group 尚未产生数据时显示明确的“打开一次主 App 同步数据”占位内容，而不是空白。
- 为 iOS 16 / iOS 17 分别使用安全背景实现，避免 WidgetKit 背景渲染差异。
- 暂时移除小组件中的动态 timer 文本，降低 iOS 16 真机 WidgetKit 渲染异常风险。
- 保持原 App Group、Bundle ID、历史数据格式不变。

## V2.2.6 (build 36)
- 针对“Widget 有占位阴影但内容整块空白”继续做 Extension 生命周期隔离。
- Widget 改为最小静态 TimelineProvider，不读取 App Group、不解码数据、不调用 WidgetCenter、不使用 iOS 17 API。
- `@main` 直接由唯一 Widget 承担，移除不必要的 WidgetBundle 层。
- 本诊断版 Widget target 暂时不签 App Group entitlement，主 App entitlement 和历史数据完全不动。
- 若本版能显示“V2.2.6 · 小组件渲染测试”，即可确认此前空白来自共享权限/Extension 环境；下一版再恢复数据同步。
- 若本版仍只有系统骨架阴影，则可确定问题在 appex 嵌入/签名/系统启动 Extension，而非 SwiftUI 和业务数据。
