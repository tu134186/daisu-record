
## V2.2.25 / Build 55（2026-09-02）
- 实测发现：TrollStore 安装后，`WidgetCenter.getCurrentConfigurations` 可能返回空数组，但负一屏小组件实际上已经能够显示。
- 因此“系统列表为空 = 未登记”的诊断结论是错误的，V2.2.25 废除这一单一判断。
- Widget Extension 在 `getSnapshot/getTimeline` 真正执行时向 App Group 写入运行心跳；设置页优先以该心跳确认 Extension 已实际运行。
- 若系统配置列表为空但存在心跳，显示“已运行”，明确提示 WidgetCenter 列表结果不可靠。
- 不新增 reloadTimelines 强刷补丁。

# V2.2.25
- 修复 Widget Extension 缺失 App Group entitlement / CODE_SIGN_ENTITLEMENTS 的打包配置。
- Shared 模型加入 Widget Extension target。
- 设置页“重新检测”改为整行可点击并增加即时状态反馈。
- 版本同步为 2.2.25 / build 55。

# V2.2.23
- 真机确认 V2.2.22 仍为：安装后空白，点击空白 Widget 拉起 App 后仍空白，注销 SpringBoard 后立即正常。
- 停止继续把 WidgetCenter reload 当成 Extension 注册手段；Apple 文档定义它只负责重新载入已配置 Widget 的时间线。
- 设置新增“小组件诊断”，通过 `getCurrentConfigurations` 只读判断系统是否已经返回固定 kind `CarIdleMediumWidget`。
- 下一步测试转到 TrollStore 2.1+ 的 `Refresh App Registrations`，验证是否能在不注销 SpringBoard 的情况下刷新安装后的 Extension 注册。
- 修正 `tools/check-built-ipa.sh` 默认版本/build 同步错误；主 App/Widget 统一 2.2.23 / build 53。

# V2.2.22
- **关键漏项修复。** 真机再次确认：安装后 Widget 空白，注销 SpringBoard 后立即正常显示。
- 复查 V2.2.21 源码发现：虽然 `App.swift` 已经没有 WidgetCenter 刷新，但 `CarIdle/Store.swift` 仍然 `import WidgetKit`，且 `syncWidgetSnapshot()` 末尾残留 `WidgetCenter.shared.reloadTimelines(ofKind:)`。`IdleStore.init()` 又会调用 `syncWidgetSnapshot()`，因此只要 App 初始化，仍会触发主动 Timeline 刷新。V2.2.21 实际并不是文档所写的“零 WidgetCenter”版本。
- V2.2.22 删除 Store.swift 的 WidgetKit 导入和 `reloadTimelines`；保留共享摘要写入，不改业务数据格式。
- Widget 继续固定 `kind = CarIdleMediumWidget`、单一 Extension、静态白底黑字、`.never` Timeline，不更换 Bundle ID，不加第二 Extension。
- 测试：覆盖安装后先直接看桌面，再打开 App 后返回桌面。目标文字 `WIDGET V2.2.22 / BUILD 52 · 真正零 WidgetCenter 测试`。如果这版仍必须注销后才显示，才能更有把握归因于 TrollStore/iOS 16.5 的 Extension 注册/缓存生命周期，而不是 App 自己的 reload 干扰。
- 主 App / Widget 同步为 2.2.22 / build 52。

# V2.2.21
- **V2.2.20 失败回退版。** 真机确认：覆盖安装 V2.2.20 后，桌面 Widget 会马上从原状态变成整块空白。该现象说明在 TrollStore 覆盖安装阶段，主 App 主动调用 `WidgetCenter.reloadAllTimelines()` / `reloadTimelines` 可能先清掉旧快照，但新 Widget Extension 此时还没有完成可用注册，结果就是“越刷新越空白”。
- 撤销 V2.2.20 新增的所有主 App 启动/回前台 WidgetCenter 刷新代码，`App.swift` 恢复纯 SwiftUI 最小启动路径。
- Widget Timeline 从 5 分钟 `.after(...)` 恢复 `.never`，与 V2.2.14/V2.2.19 已验证的最小静态基线保持一致。
- 保持唯一 Extension、固定 Bundle ID `com.trollbox.caridle.widget`、固定 `kind = CarIdleMediumWidget`，不换 kind、不加第二 Extension、不碰私有注册 API。
- 测试标准：覆盖安装 V2.2.21 后**先不要打开主 App、也不要注销**，直接观察桌面 Widget；随后再打开主 App观察。若仍必须注销才出现，则记录为 TrollStore/系统 Extension 重载限制，不再重复主动 reload 方案。
- 主 App 与 Widget 同步为 2.2.21 / build 51；App 内历史更新及开发文档同步记录 V2.2.20 失败结果。

# V2.2.20
- **安装后首次空白专项版。** 真机最新结果：V2.2.19 安装完成后桌面 Widget 为空白，注销 SpringBoard 后立即可以显示。该结果继续证明 Widget Extension/静态 SwiftUI 本身能运行，故障集中在安装后的首次注册/唤醒阶段。
- 主 App 在首次进入界面和每次重新进入前台时，通过 Apple 公开 `WidgetCenter` API 先 `reloadAllTimelines()`，再调用 `getCurrentConfigurations` 真实读取系统当前桌面 Widget 配置；若发现固定 kind `CarIdleMediumWidget`，再请求该 kind 刷新。
- 本版**不恢复**历史失败的 0.8s/2.5s 延迟循环，不更换 Widget kind，不增加第二 Extension，不使用私有注册 API。
- Widget Timeline 从 `.never` 改为 5 分钟后的 `.after(...)`，避免首次安装时如果系统错过第一次时间线请求就永久停在空白快照；5 分钟符合 Apple 对 Widget 时间线应使用较大刷新间隔的建议。
- 目标测试：覆盖/安装 V2.2.20 后先打开一次主 App，再回桌面观察 Widget 是否无需注销直接出现 `WIDGET V2.2.20 / BUILD 50 · 首次启动唤醒测试`。若仍空白但注销后正常，则应记录为 TrollStore/系统 Extension 注册层问题，不能继续把 `reloadTimelines` 当成可强制注册 Extension 的 API。
- 主 App 与 Widget 同步为 2.2.20 / build 50；App 内历史更新与开发文档同步。

# V2.2.19
- **TrollStore Widget 注销更新基线版。** 不再继续堆叠“安装后强制即时刷新”的试验补丁。
- 将 V2.2.18 真机结果写入长期开发记录：覆盖安装后桌面 Widget 曾继续显示 V2.2.12；注销 SpringBoard 后立即正确显示 V2.2.18。
- 结论：V2.2.18 的主 App / Widget Extension 版本同步和打包本身有效；旧显示来自覆盖安装后系统仍使用旧 Extension/快照/注册状态。
- TrollStore 的覆盖安装与 App Store 正式更新生命周期不能视为 100% 等价，因此以后不再承诺“覆盖安装后绝对无需注销就立即切换 Widget”。
- 稳定处理：覆盖安装后若 Widget 仍停留旧版，注销 SpringBoard 一次；若注销后仍不更新，才继续排查最终 IPA 的 appex、版本、签名与注册。
- 禁止重复失败路线：不再为了清缓存更换 Widget kind；不重新加入 0.8s/2.5s 延迟 reload；不增加第二 Widget target；不引入跨沙盒/私有 entitlement/额外重签。
- 主 App 与 Widget 同步为 2.2.19 / build 49；唯一 kind 继续固定 `CarIdleMediumWidget`。
- App 内历史更新补齐 V2.2.18 与 V2.2.19；源码包开发文档同步记录成功/失败/未解决结论。

# V2.2.18
- 主 App 与 Widget 同步为 2.2.18 / build 48，Widget 可见标记为 `WIDGET V2.2.18 / BUILD 48 · 真包校验`。
- 真机结果：覆盖安装后旧桌面 Widget 仍显示 V2.2.12；注销 SpringBoard 后立即变为 V2.2.18。
- **成功验证：** 新 Widget Extension 确实已经随安装包更新，注销后系统能够加载到 V2.2.18。
- **未实现：** TrollStore 覆盖安装后不注销立即切换 Widget，不能作为当前稳定可保证行为。
- 该结果推翻“包里仍混有 2212 导致显示旧版”的判断；后续首先区分“包内容错误”和“系统未重载扩展”。

# V2.2.17
- **2214 原版克隆验证版：直接从已真机成功的 V2.2.14 success-case 源码包复制生成，不继承 V2.2.15/V2.2.16。**
- 仅同步主 App / Widget 为 2.2.17 / build 47。
- Widget 仅把可见文字改为 `WIDGET V2.2.17` 和 `2214 原版克隆验证`；Provider、Timeline、StaticConfiguration、`kind = CarIdleMediumWidget`、Bundle ID、Extension 结构全部保持 V2.2.14 原样。
- 为保证 A/B 测试只有最少变量，本版故意不修改 V2.2.14 中现存但当前 App 启动流程未调用的 `Shared/WidgetSnapshot.swift` 旧 widgetKind 常量。
- 测试标准：直接覆盖安装、不注销、不删除桌面 Widget；若立刻显示 `WIDGET V2.2.17`，则证明 V2.2.14 克隆升级链正常。

# V2.2.14
- **真机成功案例：用户确认无需注销 SpringBoard，覆盖安装 V2.2.14 后，桌面 Widget 秒级从旧版切换为 `WIDGET V2.2.14`。该结构确认为后续稳定基线。**
- 停止继续叠加 WidgetKit 刷新补丁，改为标准 Widget Extension 结构验证。
- 关键修正：Widget `kind` 固定为 `CarIdleMediumWidget`，从本版开始禁止跟随版本号变化。此前 V2.2.12/V2.2.13 每版更换 kind，会让桌面上已经添加的小组件继续绑定旧配置，干扰覆盖安装测试。
- 主 App 删除启动后 0.8 秒/2.5 秒 `reloadTimelines` 强制刷新，恢复最小标准启动路径。
- Widget 继续采用静态白底黑字，只显示 `WIDGET V2.2.14`，不读取 App Group/业务数据，用来验证 Extension 注册是否切到新版本。
- `tools/check-built-ipa.sh` 升级：同时校验主 App 与 Widget 的版本号、build、Bundle ID、Widget extension point、可执行文件、签名与 entitlements。
- 版本同步为 2.2.14 / build 44。

# V2.2.13
- 设置 → 关于恢复简洁结构：只保留“当前版本”和“历史更新”入口，不再在设置页直接展开几十个版本。
- 点击“历史更新”弹出独立全屏更新日志，完整历史继续按新 → 旧排列并显示每版详细更新内容。
- Widget 使用全新唯一 kind `CarIdleMediumWidgetV2213Fresh`，用于排除 V2.2.12 已注销后留下的旧快照/缓存，重新验证“新装后首次添加能否立即显示”。
- 主 App 启动后仅针对当前 kind 在 0.8 秒和 2.5 秒各请求一次轻量 Timeline 刷新，覆盖 Extension 注册稍慢的情况；不访问 App Group，不改业务数据。
- Widget Timeline 从 `.never` 改为 15 分钟后 `.after(...)`，避免永久时间线；仍保持纯静态白底黑字诊断，不恢复复杂业务 UI。
- 版本同步为 2.2.13 / build 43。

# V2.2.12
- 设置 → 关于重新整合：顶部仅显示当前版本，下面直接连续显示完整历史更新，不再只列少量摘要。
- 将 V2.2.x 后续版本记录与早期历史统一按“新 → 旧”排列，方便直接在关于页查看。
- 真机新结论：Widget 安装并添加后可能首次不立即显示；注销 SpringBoard 后可以正常显示。后续排查重点改为“首次注册/刷新时机”，不再把问题定义为永久空白。
- 保持当前单 Widget Extension、唯一 kind 和静态诊断渲染架构，不因本次关于页调整改动高风险 Widget 核心。
- 版本同步为 2.2.12 / build 42。

# V2.2.11
- 重新整理 `DEVELOPMENT.md`，补齐项目目标、稳定基线、已知 Bug、高风险区域、最小改动原则、Widget 排查顺序、版本同步、ZIP/编译规范、测试要求和下一步建议。
- 重写 `AI接手开发说明.md`，明确当前 Widget 空白排查结论和禁止重复尝试的失败路线。
- 设置 → 关于：版本号下方直接显示历史版本更新摘要，并保留“查看完整更新日志”入口。
- App 内完整更新日志补齐 V2.1.0、V2.2.0、V2.2.3、V2.2.4、V2.2.5、V2.2.8、V2.2.9、V2.2.10、V2.2.11。
- 不改 V2.2.10 的单 Widget Extension / 静态诊断架构，避免引入新的空白变量。
- 版本同步为 2.2.11 / build 41。

# V2.2.10
- 清理“旧 Widget 残留”疑点：工程只保留一个实际 Widget Extension target 和一份 Widget 源码。
- 删除误打包的乱码重复开发说明文件；历史版本仅保留在 CHANGELOG/开发规范中，不参与编译。
- 当前唯一 Widget kind 统一为 `CarIdleMediumWidgetV2210Single`，主 App 的刷新 kind 同步更新，避免继续刷新旧 `CarIdleMediumWidget`。
- Widget 仍为纯静态白底黑字诊断，不读取 App Group 或业务数据。
- 版本同步为 2.2.10 / build 40。

# V2.2.9
- 用户真机确认 V2.2.8 仍为“内容全空白，但长按/切换能看到组件区域阴影”。这已经基本排除业务数据、App Group 和复杂 SwiftUI 内容。
- Widget 再缩为绝对静态渲染：白底 + 黑色三行文字；不使用 SF Symbol、不使用动态日期、不读取 UserDefaults/App Group、不引用 Shared。
- Widget kind 改为 `CarIdleMediumWidgetV229Static`，强制生成全新 WidgetKit 配置，避免沿用 V2.2.8 旧快照。
- Widget target 显式锁定 iPhoneOS / iOS 16.0，并关闭自动 Info.plist 生成与 base entitlement 注入，减少 TrollStore/无签名构建环境中的扩展差异。
- 主 App 启动 1 秒后调用 `WidgetCenter.shared.reloadAllTimelines()`，覆盖安装后主动请求系统丢弃旧时间线。
- 若本版仍只有阴影且连 `WIDGET V2.2.9` 都不显示，结论应转向最终 IPA 内 `.appex` 的签名/注册/实际最低系统版本，禁止继续改业务 Widget View。
- 版本同步为 2.2.9 / build 39。

# V2.2.8
- TrollStore / iOS 16.5 Widget Extension 纯启动隔离测试版。
- Widget target 不再链接 Shared，不读取 App Group，不读取 UserDefaults，不使用业务模型。
- Widget Extension 不携带 App Group entitlement，排除共享容器 entitlement 导致扩展启动失败。
- 改为单个 `@main Widget`，不再使用 WidgetBundle。
- Widget kind 改为全新 `CarIdleMediumWidgetV228Diagnostic`，避免旧 WidgetKit 配置/缓存复用。
- 正常时必须显示“V2.2.8 · 纯 WidgetKit 启动测试”。若仍整块空白，优先检查最终 IPA 的 appex 注册/签名与 TrollStore 安装环境。
- 版本同步为 2.2.8 / build 38。

# V2.2.4

- 修复 Widget 编译失败：`CarIdleWidgetEntry` 新增 `sharedDataConnected` 后，placeholder 与 timeline 构造处漏传该必填参数。
- `placeholder` 补齐 `sharedDataConnected: true`；`getTimeline` 按实际 App Group 连通状态传值。
- 不修改主 App 数据键、历史记录格式、Bundle ID、App Group 或 Widget 架构。
- 版本同步为 2.2.4 / build 34。

# V2.2.3

- 回退到 V2.2.0 已验证能显示的 Widget 架构。
- 移除跨沙盒读取、私有权限和额外 ldid 重签方案。
- 保留标准 App Group。
- Widget 能运行但共享数据读不到时，明确显示“组件运行正常 · 数据共享未连接”。
- 不修改主 App 历史数据格式。

# V2.2.0

- 新增唯一一个「中号」桌面小组件，不提供小号/大号。
- 小组件显示：当前运行状态、距上次启动、上次时长、总次数、下次启动建议。
- 主 App 与 Widget 使用 `group.com.trollbox.caridle` App Group 共享摘要数据。
- 主 App 的历史记录仍保留在原 `UserDefaults.standard`，不迁移、不破坏 V2.1.0 数据。
- 每次启动/熄火/取消/修改提醒间隔时，同步摘要并刷新 Widget Timeline。
- Widget Extension: `com.trollbox.caridle.widget`，仅支持 `.systemMedium`。

# V2.1.0

- 首页精修：压缩顶部车辆状态卡片与整体纵向间距，减少首屏拥挤。
- “距上次”不再显示生硬的 `0.0天`，改为“刚刚 / 今天 / 1天 / N天”。
- “当前已闲置”按小时/天自然显示。
- 超期很久的保养提醒弱化为“已到期 · 建议尽快检查”，避免大号红色数字喧宾夺主。
- 首页移除重复的“设置”快捷入口，设置统一使用右上角齿轮；常用功能保留历史、报表、保养。
- “最近一次”卡片压缩为两行，提高首屏信息密度。
- 不修改 V2.0.2 已验证的数据存储、历史记录格式和 Bundle ID。
- 版本同步为 2.1.0 / build 29。

# V2.0.2

- App 对外显示名称统一为「怠速记录」。
- 保持原 Bundle ID `com.trollbox.caridle`，避免覆盖安装后丢失旧数据。
- GitHub 构建方式统一为“仓库只维护 app.zip + 一份固定工作流”，以后升级只替换 app.zip。
- 版本同步为 2.0.2 / build 28。

# V2.0.1

- 修复 GitHub Actions 编译工作流：旧工作流在真正编译前先执行 `test -f app.zip`，导致 5 秒内直接退出，实际上并未进入 Xcode 编译。
- 新工作流顺序：checkout → 安装 xcodegen → 生成工程 → xcodebuild → 定位 .app → 打包 Payload/app.zip → 上传 artifact。
- 增加构建产物存在性检查和 Info.plist 检查，失败时输出实际 Products 目录，便于排查。
- 版本同步为 2.0.1 / build 27。

# 更新日志

## v2.0.0 - 2026-09-01
- 首页重做为“车辆状态”中心，启动/熄火成为第一视觉和第一操作。
- 运行中突出计时、目标剩余时间与熄火保存。
- 新增更清晰的总次数、总时长、距上次统计区。
- 首页直接显示最紧急保养提醒、下次启动建议和最近一次记录。
- 常用功能缩成四个清晰入口：历史、报表、保养、设置。
- 将原 1500+ 行 ContentView.swift 中多个页面拆成独立 Swift 文件。
- 设置页版本号改为读取 Bundle 版本。
- 保留 V1.10.4 原有数据键与历史数据格式，减少升级丢数据风险。

## v1.10.4
- 原版基线，完整历史见源码内 `#U66f4#U65b0#U65e5#U5fd7.txt`。

## V2.2.5 (build 35)
- 修复桌面小组件“有切换阴影但内容整块空白”的问题定位版本。
- 小组件预览阶段不再访问共享数据，始终使用可渲染的示例 Entry。
- 正常时间线在 App Group 尚未产生数据时显示明确的“打开一次主 App 同步数据”占位内容，而不是空白。
- 为 iOS 16 / iOS 17 分别使用安全背景实现，避免 WidgetKit 背景渲染差异。
- 暂时移除小组件中的动态 timer 文本，降低 iOS 16 真机 WidgetKit 渲染异常风险。
- 保持原 App Group、Bundle ID、历史数据格式不变。
