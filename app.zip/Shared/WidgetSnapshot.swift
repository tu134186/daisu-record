import Foundation

enum CarIdleWidgetShared {
    static let appGroupID = "group.com.trollbox.caridle"
    static let snapshotKey = "widgetSnapshotV1"
    static let widgetKind = "CarIdleMediumWidget"
}

struct CarIdleWidgetSnapshot: Codable, Equatable {
    var isRunning: Bool
    var currentStartTime: Date?
    var lastStartTime: Date?
    var lastDuration: TimeInterval?
    var totalCount: Int
    var totalDuration: TimeInterval
    var reminderIntervalDays: Int
    var updatedAt: Date

    static let empty = CarIdleWidgetSnapshot(
        isRunning: false,
        currentStartTime: nil,
        lastStartTime: nil,
        lastDuration: nil,
        totalCount: 0,
        totalDuration: 0,
        reminderIntervalDays: 7,
        updatedAt: Date()
    )

    static func loadFromSharedDefaults() -> CarIdleWidgetSnapshot {
        guard let defaults = UserDefaults(suiteName: CarIdleWidgetShared.appGroupID),
              let data = defaults.data(forKey: CarIdleWidgetShared.snapshotKey),
              let value = try? JSONDecoder().decode(CarIdleWidgetSnapshot.self, from: data) else {
            return .empty
        }
        return value
    }

    func saveToSharedDefaults() {
        guard let defaults = UserDefaults(suiteName: CarIdleWidgetShared.appGroupID),
              let data = try? JSONEncoder().encode(self) else { return }
        defaults.set(data, forKey: CarIdleWidgetShared.snapshotKey)
        defaults.synchronize()
    }
    static func sharedDataIsConnected() -> Bool {
        guard let defaults = UserDefaults(suiteName: CarIdleWidgetShared.appGroupID) else { return false }
        return defaults.data(forKey: CarIdleWidgetShared.snapshotKey) != nil
    }

}
