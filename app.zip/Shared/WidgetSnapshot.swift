import Foundation

enum CarIdleWidgetShared {
    static let appGroupID = "group.com.trollbox.caridle"
    static let snapshotKey = "widgetSnapshotV1"
    static let widgetKind = "CarIdleMediumWidget"
    static let fallbackFileName = "CarIdleWidgetSnapshot.json"
    static let mainBundleID = "com.trollbox.caridle"
}

struct CarIdleWidgetSnapshot: Codable, Equatable {
    var isRunning: Bool
    var currentStartTime: Date?
    var lastStartTime: Date?
    var lastDuration: TimeInterval?
    var totalCount: Int
    var totalDuration: TimeInterval
    var reminderIntervalDays: Int
    var updatedAt: Date

    static let empty = CarIdleWidgetSnapshot(
        isRunning: false,
        currentStartTime: nil,
        lastStartTime: nil,
        lastDuration: nil,
        totalCount: 0,
        totalDuration: 0,
        reminderIntervalDays: 7,
        updatedAt: Date(timeIntervalSince1970: 0)
    )

    var hasRealData: Bool {
        isRunning || lastStartTime != nil || totalCount > 0 || updatedAt.timeIntervalSince1970 > 1
    }

    // MARK: - 读取
    static func loadForWidget() -> CarIdleWidgetSnapshot {
        // 1. 标准 App Group：官方签名/正常 App Group 环境优先走这里。
        let groupValue = loadFromSharedDefaults()
        if groupValue.hasRealData {
            return groupValue
        }

        // 2. TrollStore / iOS 16 兜底：
        // Widget Extension 在部分 TrollStore+iOS16 环境下 App Group 容器可能注册异常，
        // 因此从主 App 自己的数据容器读取一份只读 JSON 摘要。
        if let fallback = loadFromMainAppContainer(), fallback.hasRealData {
            return fallback
        }

        return groupValue
    }

    static func loadFromSharedDefaults() -> CarIdleWidgetSnapshot {
        guard let defaults = UserDefaults(suiteName: CarIdleWidgetShared.appGroupID),
              let data = defaults.data(forKey: CarIdleWidgetShared.snapshotKey),
              let value = try? JSONDecoder().decode(CarIdleWidgetSnapshot.self, from: data) else {
            return .empty
        }
        return value
    }

    private static func loadFromMainAppContainer() -> CarIdleWidgetSnapshot? {
        let fm = FileManager.default
        let root = URL(fileURLWithPath: "/var/mobile/Containers/Data/Application", isDirectory: true)

        guard let containers = try? fm.contentsOfDirectory(
            at: root,
            includingPropertiesForKeys: [.isDirectoryKey],
            options: [.skipsHiddenFiles]
        ) else {
            return nil
        }

        for container in containers {
            let metadataURL = container.appendingPathComponent(".com.apple.mobile_container_manager.metadata.plist")
            guard let dict = NSDictionary(contentsOf: metadataURL),
                  let identifier = dict["MCMMetadataIdentifier"] as? String,
                  identifier == CarIdleWidgetShared.mainBundleID else {
                continue
            }

            let snapshotURL = container
                .appendingPathComponent("Library", isDirectory: true)
                .appendingPathComponent("Application Support", isDirectory: true)
                .appendingPathComponent(CarIdleWidgetShared.fallbackFileName)

            guard let data = try? Data(contentsOf: snapshotURL),
                  let value = try? JSONDecoder().decode(CarIdleWidgetSnapshot.self, from: data) else {
                continue
            }
            return value
        }

        return nil
    }

    // MARK: - 主 App 写入
    func saveForMainApp() {
        saveToSharedDefaults()
        saveToMainAppContainer()
    }

    func saveToSharedDefaults() {
        guard let defaults = UserDefaults(suiteName: CarIdleWidgetShared.appGroupID),
              let data = try? JSONEncoder().encode(self) else { return }
        defaults.set(data, forKey: CarIdleWidgetShared.snapshotKey)
        defaults.synchronize()
    }

    private func saveToMainAppContainer() {
        guard let data = try? JSONEncoder().encode(self) else { return }

        let fm = FileManager.default
        guard let base = fm.urls(for: .applicationSupportDirectory, in: .userDomainMask).first else {
            return
        }

        do {
            try fm.createDirectory(at: base, withIntermediateDirectories: true)
            let url = base.appendingPathComponent(CarIdleWidgetShared.fallbackFileName)
            try data.write(to: url, options: [.atomic])
        } catch {
            // 小组件同步失败不能影响主 App 正常记录。
        }
    }
}
