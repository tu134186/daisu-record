import Foundation

enum CarIdleWidgetShared {
    static let appGroupID = "group.com.trollbox.caridle"
    static let snapshotKey = "widgetSnapshotV1"
    static let widgetKind = "CarIdleMediumWidget"
    static let widgetHeartbeatKey = "widgetHeartbeatV1"
}

struct CarIdleWidgetSnapshot: Codable, Equatable {
    var isRunning: Bool
    var currentStartTime: Date?
    var lastStartTime: Date?
    var lastDuration: TimeInterval?
    var totalCount: Int
    var totalDuration: TimeInterval
    var reminderIntervalDays: Int
    var updatedAt: Date

    static let empty = CarIdleWidgetSnapshot(
        isRunning: false,
        currentStartTime: nil,
        lastStartTime: nil,
        lastDuration: nil,
        totalCount: 0,
        totalDuration: 0,
        reminderIntervalDays: 7,
        updatedAt: Date()
    )

    static func loadFromSharedDefaults() -> CarIdleWidgetSnapshot {
        guard let defaults = UserDefaults(suiteName: CarIdleWidgetShared.appGroupID),
              let data = defaults.data(forKey: CarIdleWidgetShared.snapshotKey),
              let value = try? JSONDecoder().decode(CarIdleWidgetSnapshot.self, from: data) else {
            return .empty
        }
        return value
    }

    func saveToSharedDefaults() {
        guard let defaults = UserDefaults(suiteName: CarIdleWidgetShared.appGroupID),
              let data = try? JSONEncoder().encode(self) else { return }
        defaults.set(data, forKey: CarIdleWidgetShared.snapshotKey)
        defaults.synchronize()
    }
    static func markWidgetHeartbeat() {
        guard let defaults = UserDefaults(suiteName: CarIdleWidgetShared.appGroupID) else { return }
        defaults.set(Date().timeIntervalSince1970, forKey: CarIdleWidgetShared.widgetHeartbeatKey)
        defaults.synchronize()
    }

    static func widgetHeartbeatDate() -> Date? {
        guard let defaults = UserDefaults(suiteName: CarIdleWidgetShared.appGroupID) else { return nil }
        let value = defaults.double(forKey: CarIdleWidgetShared.widgetHeartbeatKey)
        guard value > 0 else { return nil }
        return Date(timeIntervalSince1970: value)
    }

    static func sharedDataIsConnected() -> Bool {
        guard let defaults = UserDefaults(suiteName: CarIdleWidgetShared.appGroupID) else { return false }
        return defaults.data(forKey: CarIdleWidgetShared.snapshotKey) != nil
    }

}
