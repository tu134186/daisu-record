# V2.2.20 验证计划

- V2.2.19 实测：安装后空白；注销 SpringBoard 后正常显示。
- V2.2.20 测试：安装后打开主 App 一次，主 App 使用公开 WidgetCenter 查询系统当前配置并刷新 `CarIdleMediumWidget`；Widget 自身 5 分钟后请求下一条 Timeline。
- 成功标准：无需注销即可出现 `WIDGET V2.2.20`。
- 若失败但注销后显示：记录为 Extension 首次注册/系统缓存层仍未被公开 WidgetKit API唤醒，不继续重复 reload 补丁。

# Widget / TrollStore 真机验证记录

## 最重要的 V2.2.18 实测

环境：iOS 16.x，TrollStore 类安装。

步骤：在保留桌面原有 Widget 的情况下覆盖安装 V2.2.18。

结果 1：安装完成后，桌面 Widget 仍显示 V2.2.12。

结果 2：注销 SpringBoard 后，不重新编译、不重新安装，桌面 Widget 立即正确显示 V2.2.18。

判定：V2.2.18 包内的新 Widget Extension 已正确安装；否则单纯注销不会把内容从 V2.2.12 变为 V2.2.18。旧显示属于系统在注销前仍保留旧 Extension/Widget 状态。

## 项目现在接受的稳定行为

TrollStore 覆盖安装后，不能把“无需注销立即更新 Widget”作为 100% 保证目标。若覆盖安装后仍显示旧版本，注销 SpringBoard 一次属于当前稳定升级步骤。

注销后显示新版本：判定升级成功，不继续打补丁。

注销后仍显示旧版本：才进入真正故障排查，依次检查最终 IPA 的 `PlugIns/CarIdleWidget.appex`、主 App/Widget 版本号、Info.plist 的 NSExtension、可执行文件、签名/entitlements 和系统注册状态。

## 历史成功与失败记录

### 成功
- V2.2.14 曾出现覆盖安装后无需注销即可秒级切换，这是“可以发生”的成功案例，但不能据此承诺每次 TrollStore 覆盖安装都与 App Store 一样即时重载。
- V2.2.18 已确定“注销后从 2212 正确切到 2218”，证明新 appex 能安装和工作。

### 失败或不能稳定保证
- V2.2.15 / V2.2.16 / V2.2.17 一系列为了即时更新做的尝试没有形成可重复保证。
- 每版修改 kind 清缓存不可持续，会破坏桌面现有 Widget 配置身份。
- reloadTimelines 只能请求 WidgetKit 刷新时间线，不能保证 TrollStore 覆盖安装后系统立即重启/重新注册旧 Extension 进程。

## 永久规则

唯一 Widget kind 固定为 `CarIdleMediumWidget`，以后不得把版本号写入 kind。

工程只允许一个 Widget Extension target。

不要再为了“安装后立即变版本”反复改 TimelineProvider、定时器、App Group 或复杂 SwiftUI。先看“注销后是否正确”。
