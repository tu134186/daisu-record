# V2.2.23 最新验证补充

- 真机确认 V2.2.22：安装后 Widget 空白；点击空白 Widget 可以拉起主 App，但打开 App 后 Widget 依旧空白；注销 SpringBoard 后立即显示。
- 这已经把“必须先打开一次 App”排除掉，也再次排除静态 Widget View 本身永久崩溃。
- Apple 的 `WidgetCenter.reloadTimelines` / `reloadAllTimelines` 是“重新加载已配置 Widget 的时间线”，不是“注册/重注册 Extension”的 API；因此此前继续强刷没有理论依据。
- TrollStore 2.1 起官方提供 **Refresh App Registrations**。下一步优先验证该安装侧注册刷新能否代替注销，而不是继续堆 WidgetKit reload 补丁。
- V2.2.23 设置页新增只读“小组件诊断”：调用 `getCurrentConfigurations` 查看系统当前是否能返回固定 kind `CarIdleMediumWidget`，不触发 reload，不修改桌面快照。
- 当前版本：V2.2.23 / build 53。

# V2.2.22 最新验证补充

- 真机现象：安装后空白，注销 SpringBoard 后正常。
- V2.2.21 复查发现 `Store.swift` 仍残留 `WidgetCenter.shared.reloadTimelines(ofKind:)`，且 `IdleStore.init()` 会触发它；所以此前所谓“被动注册”并不彻底。
- V2.2.22 已删除主 App 中最后一条 WidgetCenter 刷新路径以及 Store.swift 的 WidgetKit import，仅保留共享摘要写入。
- 本版是“真正零 WidgetCenter”A/B 测试。若仍只有注销后恢复，下一步不再重复 reload/换 kind，而转向 TrollStore 安装后的 Extension 注册缓存结论与安装侧处理。
- 当前版本：V2.2.22 / build 52。

# V2.2.21 TrollStore Widget 真机验证记录

## 已验证结果
- V2.2.19：安装后 Widget 空白；注销 SpringBoard 后可以正常显示。
- V2.2.20：为了尝试免注销，在主 App 首次进入/回前台主动调用 WidgetCenter 刷新，并把 Timeline 改成 5 分钟 `.after`。真机结果：**安装完成后 Widget 马上变成空白**。
- 该结果表明主动 reload 不是“注册 Extension”的 API；在 TrollStore 覆盖安装的注册窗口里，它可能先让系统丢弃旧快照，而新 Extension 还没准备好，从而造成空白。

## V2.2.21 方案
- 完全撤销 V2.2.20 的主动 WidgetCenter 刷新。
- 主 App 不导入 WidgetKit，不在启动和回前台做任何 Widget 操作。
- Widget 恢复 `.never` Timeline。
- 保持固定 kind `CarIdleMediumWidget`、唯一 Widget Extension、固定 Bundle ID。
- 这是回到 V2.2.14 / V2.2.19 被动注册架构的最小改动 A/B 测试。

## 测试步骤
1. 直接覆盖安装 V2.2.21。
2. 安装完成后先不要打开 App，不要注销，直接看桌面 Widget 是否仍显示/是否自行切换到 `WIDGET V2.2.21`。
3. 再打开一次主 App，返回桌面继续观察，但主 App不会主动 reload Widget。
4. 最后才执行注销；若注销后立刻正常，则继续确认问题在 TrollStore/系统 Extension 重载生命周期。

## 禁止重复的失败路线
- 禁止再次在 App 启动时调用 `reloadAllTimelines()` 强刷。
- 禁止用 0.8 秒/2.5 秒循环 reload。
- 禁止为了清缓存频繁更换 Widget kind。
- 禁止增加第二 Widget Extension。
- 禁止为了这个问题碰私有 entitlement/私有注册 API。
