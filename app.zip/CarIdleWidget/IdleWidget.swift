import SwiftUI
import WidgetKit
import ActivityKit

// V2.3.10：提高灵动岛倒计时对比度，并为紧凑区域预留数字宽度。
// - 锁屏活动：暂停按钮 + 关闭按钮 + “计时器”标题 + 右侧大号剩余时间（倒计时）
// - 灵动岛长按展开：左上“计时器”标题、右侧暂停/关闭按钮、下方大号剩余时间（倒计时）
// - 灵动岛紧凑（退出后台）：左侧计时器图标，右侧剩余时间倒计时
// - 灵动岛极简：仅计时器图标
// 剩余时间 = 目标分钟数 - 已计时长，到 0 后停在 00:00（与系统计时器一致）。
struct IdleActivityAttributes: ActivityAttributes {
    public struct ContentState: Codable, Hashable {
        var startTime: Date
        var targetMinutes: Int
    }
    var title: String
}

@available(iOS 16.2, *)
struct IdleWidget: Widget {
    private let white = Color.white
    private let islandTimerColor = Color(red: 1.0, green: 0.70, blue: 0.27)

    // 剩余时间计算：startTime + targetMinutes 为结束时刻
    private func remainingInterval(_ start: Date, _ targetMinutes: Int) -> ClosedRange<Date> {
        let end = start.addingTimeInterval(Double(targetMinutes) * 60)
        return start...end
    }

    // 紧凑/极简用的小号倒计时
    private func compactTimer(_ start: Date, _ targetMinutes: Int, size: CGFloat) -> some View {
        Text(timerInterval: remainingInterval(start, targetMinutes), countsDown: true)
            .font(.system(size: size, weight: .semibold, design: .rounded))
            .monospacedDigit()
            .foregroundColor(islandTimerColor)
            .lineLimit(1)
            .minimumScaleFactor(0.65)
    }

    // 展开/锁屏用的大号倒计时
    private func largeTimer(_ start: Date, _ targetMinutes: Int, size: CGFloat, color: Color = .white) -> some View {
        Text(timerInterval: remainingInterval(start, targetMinutes), countsDown: true)
            .font(.system(size: size, weight: .semibold, design: .rounded))
            .monospacedDigit()
            .foregroundColor(color)
            .lineLimit(1)
            .minimumScaleFactor(0.6)
    }

    // 暂停按钮（橙色实心圆，同系统计时器）
    private func pauseButton() -> some View {
        Button { } label: {
            Image(systemName: "pause.fill")
                .font(.system(size: 15, weight: .semibold))
                .foregroundColor(.white)
                .frame(width: 34, height: 34)
                .background(Color.orange)
                .clipShape(Circle())
        }
        .buttonStyle(.plain)
    }

    // 关闭按钮（半透明白描边圆）
    private func closeButton() -> some View {
        Button { } label: {
            Image(systemName: "xmark")
                .font(.system(size: 15, weight: .semibold))
                .foregroundColor(.white)
                .frame(width: 34, height: 34)
                .background(white.opacity(0.2))
                .clipShape(Circle())
        }
        .buttonStyle(.plain)
    }

    var body: some WidgetConfiguration {
        ActivityConfiguration(for: IdleActivityAttributes.self) { context in
            // ===== 锁屏 / 横幅：与系统计时器一致的布局 =====
            HStack(spacing: 14) {
                pauseButton()
                closeButton()
                Text("怠速记录")
                    .font(.system(size: 17, weight: .semibold))
                    .foregroundColor(white)
                    .lineLimit(1)
                Spacer(minLength: 8)
                largeTimer(context.state.startTime, context.state.targetMinutes, size: 34)
            }
            .padding(.horizontal, 18)
            .padding(.vertical, 12)
            .frame(maxWidth: .infinity)
            .activityBackgroundTint(.black)
            .activitySystemActionForegroundColor(white)
            .widgetURL(URL(string: "caridle://record"))
        } dynamicIsland: { context in
            DynamicIsland {
                // ===== 灵动岛展开（长按大药丸）：同系统计时器 =====
                DynamicIslandExpandedRegion(.leading) {
                    HStack(spacing: 6) {
                        Image(systemName: "car.side.fill")
                            .font(.system(size: 15, weight: .semibold))
                            .foregroundColor(.green)
                        Text("怠速记录")
                            .font(.system(size: 15, weight: .semibold))
                            .lineLimit(1)
                    }
                    .foregroundColor(white)
                }
                DynamicIslandExpandedRegion(.trailing) {
                    HStack(spacing: 8) {
                        Button { } label: {
                            Image(systemName: "pause.fill")
                                .font(.system(size: 13, weight: .semibold))
                                .foregroundColor(.white)
                                .frame(width: 30, height: 30)
                                .background(Color.orange)
                                .clipShape(Circle())
                        }
                        .buttonStyle(.plain)
                        Button { } label: {
                            Image(systemName: "xmark")
                                .font(.system(size: 13, weight: .semibold))
                                .foregroundColor(.white)
                                .frame(width: 30, height: 30)
                                .background(white.opacity(0.2))
                                .clipShape(Circle())
                        }
                        .buttonStyle(.plain)
                    }
                }
                DynamicIslandExpandedRegion(.bottom) {
                    largeTimer(context.state.startTime, context.state.targetMinutes, size: 44, color: islandTimerColor)
                        .frame(maxWidth: .infinity)
                        .padding(.bottom, 4)
                }
            } compactLeading: {
                // ===== 灵动岛紧凑：左侧计时器图标 =====
                Image(systemName: "car.side.fill")
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundColor(.green)
                    .fixedSize()
            } compactTrailing: {
                // ===== 灵动岛紧凑：右侧剩余时间倒计时 =====
                compactTimer(context.state.startTime, context.state.targetMinutes, size: 14)
                    .frame(width: 54, alignment: .trailing)
                    .accessibilityLabel("怠速剩余时间")
            } minimal: {
                // ===== 灵动岛极简：仅计时器图标 =====
                Image(systemName: "car.side.fill")
                    .foregroundColor(.green)
            }
            .contentMargins(.all, 0, for: .compactTrailing)
        }
    }
}

@main
struct IdleWidgetBundle: WidgetBundle {
    var body: some Widget { IdleWidget() }
}
