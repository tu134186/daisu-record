import SwiftUI
import WidgetKit

struct CarIdleWidgetEntry: TimelineEntry {
    let date: Date
    let snapshot: CarIdleWidgetSnapshot
    let sharedDataConnected: Bool
}

struct CarIdleWidgetProvider: TimelineProvider {
    func placeholder(in context: Context) -> CarIdleWidgetEntry {
        sampleEntry()
    }

    func getSnapshot(in context: Context, completion: @escaping (CarIdleWidgetEntry) -> Void) {
        // 小组件编辑器/预览阶段优先保证一定有内容可画，避免因为共享容器状态异常出现整块空白。
        if context.isPreview {
            completion(sampleEntry())
            return
        }
        completion(currentEntry())
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<CarIdleWidgetEntry>) -> Void) {
        let entry = currentEntry()
        let interval: TimeInterval = entry.snapshot.isRunning ? 15 * 60 : 60 * 60
        completion(Timeline(entries: [entry], policy: .after(Date().addingTimeInterval(interval))))
    }

    private func currentEntry() -> CarIdleWidgetEntry {
        let connected = CarIdleWidgetSnapshot.sharedDataIsConnected()
        let snapshot = connected ? CarIdleWidgetSnapshot.loadFromSharedDefaults() : .empty
        return CarIdleWidgetEntry(date: Date(), snapshot: snapshot, sharedDataConnected: connected)
    }

    private func sampleEntry() -> CarIdleWidgetEntry {
        CarIdleWidgetEntry(
            date: Date(),
            snapshot: CarIdleWidgetSnapshot(
                isRunning: false,
                currentStartTime: nil,
                lastStartTime: Calendar.current.date(byAdding: .day, value: -2, to: Date()),
                lastDuration: 46 * 60 + 13,
                totalCount: 135,
                totalDuration: 88 * 3600 + 10 * 60,
                reminderIntervalDays: 5,
                updatedAt: Date()
            ),
            sharedDataConnected: true
        )
    }
}

struct CarIdleMediumWidgetView: View {
    let entry: CarIdleWidgetEntry

    private var snapshot: CarIdleWidgetSnapshot { entry.snapshot }

    var body: some View {
        content
            .widgetSafeBackground()
    }

    private var content: some View {
        VStack(alignment: .leading, spacing: 11) {
            HStack(spacing: 10) {
                ZStack {
                    RoundedRectangle(cornerRadius: 11, style: .continuous)
                        .fill(Color.green.opacity(0.16))
                    Image(systemName: "car.fill")
                        .font(.system(size: 19, weight: .semibold))
                        .foregroundColor(.green)
                }
                .frame(width: 40, height: 40)

                VStack(alignment: .leading, spacing: 2) {
                    Text("怠速记录")
                        .font(.headline)
                        .foregroundColor(.primary)

                    Text(statusText)
                        .font(.caption)
                        .foregroundColor(statusColor)
                        .lineLimit(1)
                }

                Spacer(minLength: 4)

                Circle()
                    .fill(snapshot.isRunning ? Color.green : Color.secondary.opacity(0.28))
                    .frame(width: 10, height: 10)
            }

            Divider()

            HStack(spacing: 0) {
                metric(title: "距上次", value: sinceLastText)
                metricDivider
                metric(title: "上次时长", value: lastDurationText)
                metricDivider
                metric(title: "总次数", value: "\(snapshot.totalCount)次")
            }
        }
        .padding(16)
    }

    private var statusText: String {
        if !entry.sharedDataConnected {
            return "小组件已启动 · 打开一次主 App 同步数据"
        }
        if snapshot.isRunning {
            return "车辆运行中"
        }
        return nextSuggestionText
    }

    private var statusColor: Color {
        if !entry.sharedDataConnected { return .orange }
        return snapshot.isRunning ? .green : .secondary
    }

    private var metricDivider: some View {
        Rectangle()
            .fill(Color.secondary.opacity(0.18))
            .frame(width: 1, height: 36)
            .padding(.horizontal, 9)
    }

    private func metric(title: String, value: String) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title)
                .font(.caption2)
                .foregroundColor(.secondary)
            Text(value)
                .font(.system(size: 15, weight: .semibold, design: .rounded))
                .foregroundColor(.primary)
                .lineLimit(1)
                .minimumScaleFactor(0.7)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var sinceLastText: String {
        guard let last = snapshot.lastStartTime else { return "暂无" }
        let seconds = max(0, entry.date.timeIntervalSince(last))
        if seconds < 3600 { return "不到1小时" }
        if seconds < 86400 { return "\(max(1, Int(seconds / 3600)))小时" }
        return "\(Int(seconds / 86400))天"
    }

    private var lastDurationText: String {
        guard let duration = snapshot.lastDuration else { return "暂无" }
        let total = max(0, Int(duration))
        let hours = total / 3600
        let minutes = (total % 3600) / 60
        if hours > 0 { return "\(hours)时\(minutes)分" }
        if minutes > 0 { return "\(minutes)分" }
        return "\(total)秒"
    }

    private var nextSuggestionText: String {
        guard let last = snapshot.lastStartTime else { return "还没有怠速记录" }
        let interval = max(1, snapshot.reminderIntervalDays)
        let elapsedDays = Int(max(0, entry.date.timeIntervalSince(last)) / 86400)
        let remaining = interval - elapsedDays
        if remaining <= 0 { return "建议今天启动一次" }
        if remaining == 1 { return "建议明天启动" }
        return "建议 \(remaining) 天后启动"
    }
}

private extension View {
    @ViewBuilder
    func widgetSafeBackground() -> some View {
        if #available(iOSApplicationExtension 17.0, *) {
            self.containerBackground(Color(.systemBackground), for: .widget)
        } else {
            self.background(Color(.systemBackground))
        }
    }
}

struct CarIdleMediumWidget: Widget {
    let kind = CarIdleWidgetShared.widgetKind

    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: CarIdleWidgetProvider()) { entry in
            CarIdleMediumWidgetView(entry: entry)
        }
        .configurationDisplayName("怠速记录")
        .description("查看距上次启动、上次时长和总记录次数。")
        .supportedFamilies([.systemMedium])
    }
}

@main
struct CarIdleWidgetBundle: WidgetBundle {
    var body: some Widget {
        CarIdleMediumWidget()
    }
}
