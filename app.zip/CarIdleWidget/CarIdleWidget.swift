import SwiftUI
import WidgetKit

// V2.2.6：iOS 16 / TrollStore 空白小组件专项。
// 本版故意把 Widget Extension 缩到最小可运行结构：不访问 App Group、
// 不读取主 App 数据、不使用 iOS 17 API。先确认 Extension 本身能够被系统真正拉起并渲染。
struct CarIdleWidgetEntry: TimelineEntry {
    let date: Date
}

struct CarIdleWidgetProvider: TimelineProvider {
    func placeholder(in context: Context) -> CarIdleWidgetEntry {
        CarIdleWidgetEntry(date: Date())
    }

    func getSnapshot(in context: Context, completion: @escaping (CarIdleWidgetEntry) -> Void) {
        completion(CarIdleWidgetEntry(date: Date()))
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<CarIdleWidgetEntry>) -> Void) {
        let entry = CarIdleWidgetEntry(date: Date())
        completion(Timeline(entries: [entry], policy: .never))
    }
}

struct CarIdleMediumWidgetView: View {
    let entry: CarIdleWidgetEntry

    var body: some View {
        VStack(alignment: .leading, spacing: 11) {
            HStack(spacing: 10) {
                ZStack {
                    RoundedRectangle(cornerRadius: 11, style: .continuous)
                        .fill(Color.green.opacity(0.16))
                    Image(systemName: "car.fill")
                        .font(.system(size: 19, weight: .semibold))
                        .foregroundColor(.green)
                }
                .frame(width: 40, height: 40)

                VStack(alignment: .leading, spacing: 2) {
                    Text("怠速记录")
                        .font(.headline)
                    Text("V2.2.6 · 小组件渲染测试")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }

                Spacer()

                Circle()
                    .fill(Color.green)
                    .frame(width: 10, height: 10)
            }

            Divider()

            HStack(spacing: 0) {
                testMetric("距上次", "等待同步")
                divider
                testMetric("上次时长", "--")
                divider
                testMetric("总次数", "--")
            }
        }
        .padding(16)
        .background(Color.white)
    }

    private var divider: some View {
        Rectangle()
            .fill(Color.secondary.opacity(0.18))
            .frame(width: 1, height: 36)
            .padding(.horizontal, 9)
    }

    private func testMetric(_ title: String, _ value: String) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title)
                .font(.caption2)
                .foregroundColor(.secondary)
            Text(value)
                .font(.system(size: 15, weight: .semibold, design: .rounded))
                .lineLimit(1)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

@main
struct CarIdleMediumWidget: Widget {
    let kind = "CarIdleMediumWidget"

    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: CarIdleWidgetProvider()) { entry in
            CarIdleMediumWidgetView(entry: entry)
        }
        .configurationDisplayName("怠速记录")
        .description("查看车辆怠速记录。")
        .supportedFamilies([.systemMedium])
    }
}
