import SwiftUI
import WidgetKit

struct CarIdleV2210Entry: TimelineEntry {
    let date: Date
}

struct CarIdleV2210Provider: TimelineProvider {
    func placeholder(in context: Context) -> CarIdleV2210Entry {
        CarIdleV2210Entry(date: Date())
    }

    func getSnapshot(in context: Context, completion: @escaping (CarIdleV2210Entry) -> Void) {
        completion(CarIdleV2210Entry(date: Date()))
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<CarIdleV2210Entry>) -> Void) {
        completion(Timeline(entries: [CarIdleV2210Entry(date: Date())], policy: .never))
    }
}

struct CarIdleV2210View: View {
    var body: some View {
        ZStack {
            Rectangle()
                .fill(Color.white)

            VStack(spacing: 8) {
                Text("怠速记录")
                    .font(.system(size: 22, weight: .bold))
                    .foregroundColor(.black)

                Text("WIDGET V2.2.11")
                    .font(.system(size: 18, weight: .bold, design: .monospaced))
                    .foregroundColor(.black)

                Text("如果你看到这三行，扩展已经正常启动")
                    .font(.system(size: 12, weight: .regular))
                    .foregroundColor(.black)
            }
            .padding(12)
        }
        .unredacted()
    }
}

@main
struct CarIdleMediumWidget: Widget {
    // 每个诊断版本使用全新 kind，避免 WidgetKit 继续复用旧快照。
    let kind = "CarIdleMediumWidgetV2210Single"

    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: CarIdleV2210Provider()) { _ in
            CarIdleV2210View()
        }
        .configurationDisplayName("怠速记录 V2.2.11")
        .description("纯静态 WidgetKit 启动诊断，不读取任何共享数据。")
        .supportedFamilies([.systemMedium])
    }
}
