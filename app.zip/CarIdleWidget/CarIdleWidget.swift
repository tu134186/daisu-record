import SwiftUI
import WidgetKit

struct CarIdleEntry: TimelineEntry {
    let date: Date
}

struct CarIdleProvider: TimelineProvider {
    func placeholder(in context: Context) -> CarIdleEntry {
        CarIdleEntry(date: Date())
    }

    func getSnapshot(in context: Context, completion: @escaping (CarIdleEntry) -> Void) {
        completion(CarIdleEntry(date: Date()))
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<CarIdleEntry>) -> Void) {
        completion(Timeline(entries: [CarIdleEntry(date: Date())], policy: .never))
    }
}

struct CarIdleWidgetView: View {
    var body: some View {
        ZStack {
            Color.white
            VStack(spacing: 8) {
                Text("怠速记录")
                    .font(.system(size: 22, weight: .bold))
                Text("WIDGET V2.2.19")
                    .font(.system(size: 18, weight: .bold, design: .monospaced))
                Text("BUILD 49 · 注销更新基线")
                    .font(.system(size: 12))
            }
            .foregroundColor(.black)
            .padding(12)
        }
        .unredacted()
    }
}

@main
struct CarIdleMediumWidget: Widget {
    // 重要：kind 是系统保存桌面 Widget 配置的稳定身份。
    // 从本版开始禁止再把版本号写进 kind，否则覆盖安装后旧桌面组件仍会绑定旧 kind。
    let kind = "CarIdleMediumWidget"

    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: CarIdleProvider()) { _ in
            CarIdleWidgetView()
        }
        .configurationDisplayName("怠速记录")
        .description("怠速记录桌面小组件")
        .supportedFamilies([.systemMedium])
    }
}
