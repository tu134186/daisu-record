import SwiftUI
import WidgetKit

struct CarIdleWidgetEntry: TimelineEntry {
    let date: Date
    let snapshot: CarIdleWidgetSnapshot
    let sharedDataConnected: Bool
}

struct CarIdleWidgetProvider: TimelineProvider {
    func placeholder(in context: Context) -> CarIdleWidgetEntry {
        CarIdleWidgetEntry(
            date: Date(),
            snapshot: CarIdleWidgetSnapshot(
                isRunning: false,
                currentStartTime: nil,
                lastStartTime: Calendar.current.date(byAdding: .day, value: -2, to: Date()),
                lastDuration: 46 * 60 + 13,
                totalCount: 135,
                totalDuration: 88 * 3600 + 10 * 60,
                reminderIntervalDays: 5,
                updatedAt: Date()
            ),
            sharedDataConnected: true
        )
    }

    func getSnapshot(in context: Context, completion: @escaping (CarIdleWidgetEntry) -> Void) {
        completion(CarIdleWidgetEntry(date: Date(), snapshot: CarIdleWidgetSnapshot.loadFromSharedDefaults(),
            sharedDataConnected: CarIdleWidgetSnapshot.sharedDataIsConnected()))
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<CarIdleWidgetEntry>) -> Void) {
        let now = Date()
        let snapshot = CarIdleWidgetSnapshot.loadFromSharedDefaults()
        let entry = CarIdleWidgetEntry(
            date: now,
            snapshot: snapshot,
            sharedDataConnected: CarIdleWidgetSnapshot.sharedDataIsConnected()
        )
        let refresh = Calendar.current.date(byAdding: .minute, value: snapshot.isRunning ? 15 : 60, to: now) ?? now.addingTimeInterval(3600)
        completion(Timeline(entries: [entry], policy: .after(refresh)))
    }
}

struct CarIdleMediumWidgetView: View {
    let entry: CarIdleWidgetEntry

    private var snapshot: CarIdleWidgetSnapshot { entry.snapshot }

    var body: some View {
        ZStack {
            Color(.systemBackground)

            VStack(alignment: .leading, spacing: 12) {
                HStack(spacing: 10) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 12, style: .continuous)
                            .fill(Color.green.opacity(0.14))
                        Image(systemName: "car.fill")
                            .font(.system(size: 20, weight: .semibold))
                            .foregroundColor(.green)
                    }
                    .frame(width: 42, height: 42)

                    VStack(alignment: .leading, spacing: 2) {
                        Text("怠速记录")
                            .font(.headline)
                        Text(snapshot.isRunning ? "车辆运行中" : nextSuggestionText)
                            .font(.caption)
                            .foregroundColor(snapshot.isRunning ? .green : .secondary)
                            .lineLimit(1)
                    }

                    Spacer()

                    if snapshot.isRunning, let start = snapshot.currentStartTime {
                        VStack(alignment: .trailing, spacing: 2) {
                            Text("已运行")
                                .font(.caption2)
                                .foregroundColor(.secondary)
                            Text(start, style: .timer)
                                .font(.system(.body, design: .rounded).weight(.semibold))
                                .monospacedDigit()
                        }
                    } else {
                        Circle()
                            .fill(Color.secondary.opacity(0.25))
                            .frame(width: 10, height: 10)
                    }
                }

                Divider()

                HStack(spacing: 0) {
                    metric(title: "距上次", value: sinceLastText)
                    divider
                    metric(title: "上次时长", value: lastDurationText)
                    divider
                    metric(title: "总次数", value: "\(snapshot.totalCount)次")
                }
            }
            .padding(16)
        }
    }

    private var divider: some View {
        Rectangle()
            .fill(Color.secondary.opacity(0.18))
            .frame(width: 1, height: 38)
            .padding(.horizontal, 10)
    }

    private func metric(title: String, value: String) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title)
                .font(.caption2)
                .foregroundColor(.secondary)
            Text(value)
                .font(.system(size: 15, weight: .semibold, design: .rounded))
                .lineLimit(1)
                .minimumScaleFactor(0.75)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var sinceLastText: String {
        guard let last = snapshot.lastStartTime else { return "暂无" }
        let seconds = max(0, entry.date.timeIntervalSince(last))
        if seconds < 3600 { return "不到1小时" }
        if seconds < 86400 { return "\(max(1, Int(seconds / 3600)))小时" }
        let days = Int(seconds / 86400)
        return "\(days)天"
    }

    private var lastDurationText: String {
        guard let duration = snapshot.lastDuration else { return "暂无" }
        let total = max(0, Int(duration))
        let hours = total / 3600
        let minutes = (total % 3600) / 60
        if hours > 0 { return "\(hours)时\(minutes)分" }
        if minutes > 0 { return "\(minutes)分" }
        return "\(total)秒"
    }

    private var nextSuggestionText: String {
        guard let last = snapshot.lastStartTime else { return "还没有怠速记录" }
        let interval = max(1, snapshot.reminderIntervalDays)
        let elapsed = max(0, entry.date.timeIntervalSince(last))
        let elapsedDays = Int(elapsed / 86400)
        let remaining = interval - elapsedDays
        if remaining <= 0 { return "建议今天启动一次" }
        if remaining == 1 { return "建议明天启动" }
        return "建议 \(remaining) 天后启动"
    }
}

struct CarIdleMediumWidget: Widget {
    let kind = CarIdleWidgetShared.widgetKind

    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: CarIdleWidgetProvider()) { entry in
            CarIdleMediumWidgetView(entry: entry)
        }
        .configurationDisplayName("怠速记录")
        .description("查看距上次启动、上次时长和总记录次数。")
        .supportedFamilies([.systemMedium])
    }
}

@main
struct CarIdleWidgetBundle: WidgetBundle {
    var body: some Widget {
        CarIdleMediumWidget()
    }
}
