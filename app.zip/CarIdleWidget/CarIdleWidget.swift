import WidgetKit
import SwiftUI

struct CarIdleWidgetEntry: TimelineEntry {
    let date: Date
    let snapshot: CarIdleWidgetSnapshot
}

struct CarIdleWidgetProvider: TimelineProvider {
    func placeholder(in context: Context) -> CarIdleWidgetEntry {
        CarIdleWidgetEntry(date: Date(), snapshot: .empty)
    }

    func getSnapshot(in context: Context, completion: @escaping (CarIdleWidgetEntry) -> Void) {
        CarIdleWidgetShared.markWidgetHeartbeat()
        completion(CarIdleWidgetEntry(date: Date(), snapshot: .loadFromSharedDefaults()))
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<CarIdleWidgetEntry>) -> Void) {
        CarIdleWidgetShared.markWidgetHeartbeat()
        let entry = CarIdleWidgetEntry(date: Date(), snapshot: .loadFromSharedDefaults())
        let next = Calendar.current.date(byAdding: .minute, value: 15, to: Date()) ?? Date().addingTimeInterval(900)
        completion(Timeline(entries: [entry], policy: .after(next)))
    }
}

struct CarIdleWidgetView: View {
    let entry: CarIdleWidgetEntry

    private var totalText: String {
        let minutes = Int(entry.snapshot.totalDuration / 60)
        if minutes >= 60 {
            return String(format: "%d小时%d分", minutes / 60, minutes % 60)
        }
        return "\(minutes)分钟"
    }

    private var lastText: String {
        guard let duration = entry.snapshot.lastDuration else { return "暂无记录" }
        let minutes = max(1, Int(duration / 60))
        return "上次怠速 \(minutes) 分钟"
    }

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 18)
                .fill(Color(.secondarySystemBackground))
            HStack(spacing: 14) {
                ZStack {
                    Circle().fill(entry.snapshot.isRunning ? Color.green.opacity(0.18) : Color.orange.opacity(0.18))
                    Image(systemName: entry.snapshot.isRunning ? "car.fill" : "car")
                        .font(.system(size: 28, weight: .semibold))
                        .foregroundColor(entry.snapshot.isRunning ? .green : .orange)
                }
                .frame(width: 58, height: 58)

                VStack(alignment: .leading, spacing: 5) {
                    Text(entry.snapshot.isRunning ? "正在怠速" : "怠速记录")
                        .font(.headline)
                    Text(lastText)
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    Text("累计 \(entry.snapshot.totalCount) 次 · \(totalText)")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                Spacer(minLength: 0)
            }
            .padding(16)
        }
    }
}

@main
struct CarIdleMediumWidget: Widget {
    let kind = CarIdleWidgetShared.widgetKind

    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: CarIdleWidgetProvider()) { entry in
            CarIdleWidgetView(entry: entry)
        }
        .configurationDisplayName("怠速记录")
        .description("快速查看怠速状态和累计记录")
        .supportedFamilies([.systemMedium])
    }
}
