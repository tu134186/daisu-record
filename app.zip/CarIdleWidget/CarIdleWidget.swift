import SwiftUI
import WidgetKit

struct CarIdleV2213Entry: TimelineEntry {
    let date: Date
}

struct CarIdleV2213Provider: TimelineProvider {
    func placeholder(in context: Context) -> CarIdleV2213Entry {
        CarIdleV2213Entry(date: Date())
    }

    func getSnapshot(in context: Context, completion: @escaping (CarIdleV2213Entry) -> Void) {
        completion(CarIdleV2213Entry(date: Date()))
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<CarIdleV2213Entry>) -> Void) {
        let now = Date()
        let entry = CarIdleV2213Entry(date: now)
        // 不再使用 .never，给系统一个明确的下一次时间线刷新点。
        let nextRefresh = Calendar.current.date(byAdding: .minute, value: 15, to: now) ?? now.addingTimeInterval(900)
        completion(Timeline(entries: [entry], policy: .after(nextRefresh)))
    }
}

struct CarIdleV2213View: View {
    var body: some View {
        ZStack {
            Rectangle()
                .fill(Color.white)

            VStack(spacing: 8) {
                Text("怠速记录")
                    .font(.system(size: 22, weight: .bold))
                    .foregroundColor(.black)

                Text("WIDGET V2.2.13")
                    .font(.system(size: 18, weight: .bold, design: .monospaced))
                    .foregroundColor(.black)

                Text("首次添加显示测试 · 无需注销")
                    .font(.system(size: 12, weight: .regular))
                    .foregroundColor(.black)
            }
            .padding(12)
        }
        .unredacted()
    }
}

@main
struct CarIdleMediumWidget: Widget {
    // V2.2.13 使用新 kind，专门排除 V2.2.12 注销后留下的旧快照/缓存。
    let kind = "CarIdleMediumWidgetV2213Fresh"

    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: CarIdleV2213Provider()) { _ in
            CarIdleV2213View()
        }
        .configurationDisplayName("怠速记录 V2.2.13")
        .description("首次添加显示验证版；纯静态 WidgetKit，不读取共享数据。")
        .supportedFamilies([.systemMedium])
    }
}
