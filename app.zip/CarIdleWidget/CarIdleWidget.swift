import SwiftUI
import WidgetKit

struct CarIdleDiagnosticEntry: TimelineEntry {
    let date: Date
}

struct CarIdleDiagnosticProvider: TimelineProvider {
    func placeholder(in context: Context) -> CarIdleDiagnosticEntry {
        CarIdleDiagnosticEntry(date: Date())
    }

    func getSnapshot(in context: Context, completion: @escaping (CarIdleDiagnosticEntry) -> Void) {
        completion(CarIdleDiagnosticEntry(date: Date()))
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<CarIdleDiagnosticEntry>) -> Void) {
        let entry = CarIdleDiagnosticEntry(date: Date())
        completion(Timeline(entries: [entry], policy: .never))
    }
}

struct CarIdleDiagnosticView: View {
    let entry: CarIdleDiagnosticEntry

    var body: some View {
        ZStack {
            Color(.systemBackground)
            VStack(alignment: .leading, spacing: 10) {
                HStack {
                    Image(systemName: "car.fill")
                        .font(.system(size: 24, weight: .bold))
                    Text("怠速记录")
                        .font(.title3.bold())
                    Spacer()
                    Circle()
                        .frame(width: 10, height: 10)
                }

                Text("V2.2.8 · 纯 WidgetKit 启动测试")
                    .font(.headline)

                Text("无 App Group · 无共享数据 · 无业务代码")
                    .font(.caption)
                    .foregroundColor(.secondary)

                Spacer(minLength: 0)

                Text(entry.date, style: .time)
                    .font(.caption.monospacedDigit())
            }
            .padding(16)
        }
    }
}

@main
struct CarIdleMediumWidget: Widget {
    let kind = "CarIdleMediumWidgetV228Diagnostic"

    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: CarIdleDiagnosticProvider()) { entry in
            CarIdleDiagnosticView(entry: entry)
        }
        .configurationDisplayName("怠速记录 V2.2.8")
        .description("用于检查 TrollStore / Widget Extension 是否能正常启动。")
        .supportedFamilies([.systemMedium])
    }
}
