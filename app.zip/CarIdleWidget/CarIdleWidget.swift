import WidgetKit
import SwiftUI

struct CarIdleEntry: TimelineEntry {
    let date: Date
}

struct CarIdleProvider: TimelineProvider {
    func placeholder(in context: Context) -> CarIdleEntry { CarIdleEntry(date: Date()) }
    func getSnapshot(in context: Context, completion: @escaping (CarIdleEntry) -> Void) {
        completion(CarIdleEntry(date: Date()))
    }
    func getTimeline(in context: Context, completion: @escaping (Timeline<CarIdleEntry>) -> Void) {
        completion(Timeline(entries: [CarIdleEntry(date: Date())], policy: .after(Date().addingTimeInterval(3600))))
    }
}

struct CarIdleWidgetView: View {
    var entry: CarIdleProvider.Entry
    var body: some View {
        VStack(spacing: 6) {
            Image(systemName: "car.fill")
                .font(.title2)
            Text("怠速记录")
                .font(.headline)
            Text("V2.0.2")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .padding()
    }
}

@main
struct CarIdleWidget: Widget {
    let kind = "CarIdleWidget"
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: CarIdleProvider()) { entry in
            CarIdleWidgetView(entry: entry)
        }
        .configurationDisplayName("怠速记录")
        .description("怠速记录小组件")
        .supportedFamilies([.systemSmall])
    }
}
