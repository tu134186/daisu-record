import SwiftUI
import WidgetKit

struct CarIdleWidgetEntry: TimelineEntry {
    let date: Date
}

struct CarIdleWidgetProvider: TimelineProvider {
    func placeholder(in context: Context) -> CarIdleWidgetEntry {
        CarIdleWidgetEntry(date: Date())
    }

    func getSnapshot(in context: Context, completion: @escaping (CarIdleWidgetEntry) -> Void) {
        completion(CarIdleWidgetEntry(date: Date()))
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<CarIdleWidgetEntry>) -> Void) {
        let entry = CarIdleWidgetEntry(date: Date())
        completion(Timeline(entries: [entry], policy: .after(Date().addingTimeInterval(3600))))
    }
}

struct CarIdleMediumWidgetView: View {
    let entry: CarIdleWidgetEntry

    var body: some View {
        ZStack {
            Color(.systemBackground)

            VStack(alignment: .leading, spacing: 12) {
                HStack(spacing: 10) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 11, style: .continuous)
                            .fill(Color.green.opacity(0.16))
                        Image(systemName: "car.fill")
                            .font(.system(size: 19, weight: .semibold))
                            .foregroundColor(.green)
                    }
                    .frame(width: 40, height: 40)

                    VStack(alignment: .leading, spacing: 2) {
                        Text("怠速记录")
                            .font(.headline)
                        Text("V2.2.7 · Widget Extension 已启动")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }

                    Spacer()

                    Circle()
                        .fill(Color.green)
                        .frame(width: 10, height: 10)
                }

                Divider()

                HStack(spacing: 0) {
                    testMetric("扩展", "正常")
                    Divider().frame(height: 34).padding(.horizontal, 12)
                    testMetric("渲染", "正常")
                    Divider().frame(height: 34).padding(.horizontal, 12)
                    testMetric("版本", "2.2.7")
                }
            }
            .padding(16)
        }
    }

    private func testMetric(_ title: String, _ value: String) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title)
                .font(.caption2)
                .foregroundColor(.secondary)
            Text(value)
                .font(.system(size: 15, weight: .semibold, design: .rounded))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

@main
struct CarIdleMediumWidget: Widget {
    let kind = "com.trollbox.caridle.widget.medium"

    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: CarIdleWidgetProvider()) { entry in
            CarIdleMediumWidgetView(entry: entry)
        }
        .configurationDisplayName("怠速记录")
        .description("V2.2.7 TrollStore / iOS 16 Widget Extension 启动测试。")
        .supportedFamilies([.systemMedium])
    }
}
