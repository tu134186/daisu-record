import SwiftUI
import WidgetKit

struct CarIdleEntry: TimelineEntry {
    let date: Date
    let snapshot: CarIdleWidgetSnapshot
}

struct CarIdleProvider: TimelineProvider {
    func placeholder(in context: Context) -> CarIdleEntry {
        CarIdleEntry(date: Date(), snapshot: CarIdleWidgetSnapshot(
            isRunning: false,
            currentStartTime: nil,
            lastStartTime: Calendar.current.date(byAdding: .hour, value: -6, to: Date()),
            lastDuration: 32 * 60,
            totalCount: 18,
            totalDuration: 9 * 3600 + 26 * 60,
            reminderIntervalDays: 7,
            updatedAt: Date()
        ))
    }

    func getSnapshot(in context: Context, completion: @escaping (CarIdleEntry) -> Void) {
        CarIdleWidgetShared.markWidgetHeartbeat()
        let snapshot = context.isPreview ? placeholder(in: context).snapshot : CarIdleWidgetSnapshot.loadFromSharedDefaults()
        completion(CarIdleEntry(date: Date(), snapshot: snapshot))
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<CarIdleEntry>) -> Void) {
        CarIdleWidgetShared.markWidgetHeartbeat()
        let entry = CarIdleEntry(date: Date(), snapshot: CarIdleWidgetSnapshot.loadFromSharedDefaults())
        completion(Timeline(entries: [entry], policy: .never))
    }
}

struct CarIdleWidgetView: View {
    let entry: CarIdleEntry

    var body: some View {
        ZStack {
            Color(.systemBackground)
            VStack(alignment: .leading, spacing: 10) {
                HStack(spacing: 8) {
                    Image(systemName: entry.snapshot.isRunning ? "bolt.car.fill" : "car.fill")
                        .foregroundStyle(entry.snapshot.isRunning ? .green : .secondary)
                    Text(entry.snapshot.isRunning ? "发动机运行中" : "当前已熄火")
                        .font(.headline)
                    Spacer()
                    Circle()
                        .fill(entry.snapshot.isRunning ? Color.green : Color.secondary.opacity(0.35))
                        .frame(width: 9, height: 9)
                }

                HStack(spacing: 0) {
                    metric(title: "距上次", value: idleText)
                    Divider().frame(height: 34)
                    metric(title: "上次时长", value: durationText(entry.snapshot.lastDuration))
                    Divider().frame(height: 34)
                    metric(title: "总次数", value: "\(entry.snapshot.totalCount)次")
                }

                HStack {
                    Label(nextStartText, systemImage: "calendar.badge.clock")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    Spacer()
                    Text("V2.2.27")
                        .font(.caption2.monospacedDigit())
                        .foregroundStyle(.tertiary)
                }
            }
            .padding(15)
        }
        .unredacted()
    }

    private func metric(title: String, value: String) -> some View {
        VStack(spacing: 3) {
            Text(value)
                .font(.subheadline.bold())
                .monospacedDigit()
                .lineLimit(1)
                .minimumScaleFactor(0.7)
            Text(title)
                .font(.caption2)
                .foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
    }

    private var idleText: String {
        guard let last = entry.snapshot.lastStartTime else { return "暂无" }
        let seconds = max(0, entry.date.timeIntervalSince(last))
        if seconds < 3600 { return "刚刚" }
        if seconds < 86400 { return "\(max(1, Int(seconds / 3600)))小时" }
        return "\(max(1, Int(seconds / 86400)))天"
    }

    private var nextStartText: String {
        guard let last = entry.snapshot.lastStartTime else { return "打开 App 开始记录" }
        let target = last.addingTimeInterval(TimeInterval(max(1, entry.snapshot.reminderIntervalDays)) * 86400)
        let remaining = target.timeIntervalSince(entry.date)
        if remaining <= 0 { return "已到建议启动时间" }
        let days = max(1, Int(ceil(remaining / 86400)))
        return "建议约 \(days) 天后再次启动"
    }

    private func durationText(_ duration: TimeInterval?) -> String {
        guard let duration else { return "暂无" }
        let total = max(0, Int(duration))
        let minutes = total / 60
        if minutes < 60 { return "\(minutes)分钟" }
        return "\(minutes / 60)时\(minutes % 60)分"
    }
}

@main
struct CarIdleMediumWidget: Widget {
    let kind = "CarIdleMediumWidget"

    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: CarIdleProvider()) { entry in
            CarIdleWidgetView(entry: entry)
        }
        .configurationDisplayName("怠速记录")
        .description("查看车辆状态、上次怠速、累计次数和下次启动建议")
        .supportedFamilies([.systemMedium])
    }
}
